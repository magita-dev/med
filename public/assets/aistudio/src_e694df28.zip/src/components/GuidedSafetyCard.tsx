import { Download, ClipboardList } from 'lucide-react';
import type { RemediationPlan, VerificationReport } from '../types/medguard.ts';
import { sourceLink } from './EvidencePassport.tsx';

export function GuidedSafetyCard({ plan, report }: { plan: RemediationPlan; report: VerificationReport }) {
  const review = [...new Set([
    ...plan.todoSteps.map((step) => step.title.trim()),
    ...plan.safetyMeasures.map((measure) => measure.title.trim()),
  ].filter(Boolean))];
  const questions = [...new Set(plan.safetyMeasures.map((measure) => measure.clinicianQuestion.trim()).filter(Boolean))];
  const sources = [...plan.sources.map((source) => ({ title: source.title, url: source.url })),
    ...(report.validationSources ?? []).filter((source) =>
      source.category === 'FDA DailyMed Label' || source.category === 'Regulatory / Formulary'),
    ...report.packChecks.filter((pack) => pack.sourceUrl).map((pack) => ({ title: pack.productName + ' · catalog reference', url: pack.sourceUrl! }))]
    .flatMap((source) => {
      const url = sourceLink(source.url);
      return url ? [{ title: source.title, url }] : [];
    }).filter((source, index, items) => items.findIndex((item) => item.url === source.url) === index);
  const limitation = 'Review aid only. Findings depend on entered details and loaded references. Confirm batches, missing information and any medication changes with your pharmacist or prescriber.';
  const findings = [...report.packChecks.filter((pack) => pack.tier !== 'Not found')
    .map((pack) => pack.productName + ' · ' + (pack.tier === 'Confirmed' ? 'Batch criterion matched' : pack.tier) + ' in the app catalog (notice provenance unverified)'),
    ...report.regimenFindings.map((finding) => finding.title),
    ...report.dosageAudits.filter((entry) => entry.status !== 'Appropriate').map((entry) => entry.brandName + ' · ' + entry.status),
    ...report.diseaseAudits.filter((entry) => entry.status !== 'Matches Condition').map((entry) => entry.brandName + ' · ' + entry.status),
    ...report.ragMatches.filter((entry) => entry.triggeredUnsafeRecord).map((entry) => entry.brandName + ' · ' + entry.warningSummary)];
  const sections = [
    { title: 'What was found', lines: findings.length ? findings : ['No findings in the loaded checks. This does not establish medication safety.'] },
    { title: 'What needs professional review', lines: review.length ? review : ['Confirm the prescription, dose and batch against the original.'] },
    { title: 'Questions to ask the pharmacist', lines: questions.length ? questions : ['Which findings apply to my exact medicine, strength and batch?'] },
  ];

  function download() {
    const body = ['MedGuard pharmacist review summary', limitation,
      ...sections.flatMap(({ title, lines }) => [title, ...lines.map((line) => '• ' + line)]),
      'References', ...sources.map(({ title, url }) => title + ' — ' + url)].join('\n\n');
    const url = URL.createObjectURL(new Blob([body], { type: 'text/plain;charset=utf-8' }));
    const link = document.createElement('a');
    link.href = url;
    link.download = 'medguard-pharmacist-review.txt';
    link.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  return <section className="organelle-panel rounded-xl p-5 space-y-4">
    <div className="flex flex-wrap justify-between gap-3">
      <h2 className="font-display text-xl font-semibold text-[#1E221D] flex items-center gap-2">
        <ClipboardList className="w-5 h-5 text-[#556B22]" /> Guided Safety Action
      </h2>
      <button type="button" onClick={download} className="inline-flex items-center gap-2 rounded-lg border border-[#C6B69E] bg-[#EFE7DA] px-3 py-2 text-xs font-semibold text-[#1E221D]">
        <Download className="w-3.5 h-3.5" /> Download review summary
      </button>
    </div>
    <p className="text-xs text-[#555A50]">{limitation}</p>
    <div className="grid gap-3 lg:grid-cols-3">
      {sections.map(({ title, lines }) => <section key={title} className="organelle-subpanel rounded-lg p-3.5">
        <h3 className="font-semibold text-sm text-[#1E221D]">{title}</h3>
        <ul className="mt-2 list-disc space-y-1 pl-4 text-xs text-[#3C4138]">
          {lines.map((line, i) => <li key={i}>{line}</li>)}
        </ul>
      </section>)}
    </div>
    {sources.length > 0 && <div className="flex flex-wrap gap-3 text-xs">
      {sources.map((source) => <a key={source.url} href={source.url} target="_blank" rel="noreferrer" className="text-[#29659B] underline">{source.title}</a>)}
    </div>}
  </section>;
}
