import { useState } from 'react';
import { BellRing, PackageCheck } from 'lucide-react';

const notices = [
  { id: 'DEMO-01', product: 'Demo Tablet A', batches: ['A-001', 'A-002'] },
  { id: 'DEMO-02', product: 'Demo Tablet B', batches: ['B-015'] },
];

const stock = [
  { product: 'Demo Tablet A', batch: 'A-001', shelf: 'Rack A-01', packs: 24 },
  { product: 'Demo Tablet A', batch: 'A-002', shelf: 'Rack C-03', packs: 16 },
  { product: 'Demo Tablet A', batch: 'A-003', shelf: 'Rack A-02', packs: 12 },
  { product: 'Demo Tablet B', batch: 'B-015', shelf: 'Rack B-01', packs: 32 },
];

export function AlertRipple() {
  const [selected, setSelected] = useState(notices[0].id);
  const notice = notices.find((entry) => entry.id === selected) ?? notices[0];
  const hits = stock.filter((lot) => lot.product === notice.product && notice.batches.includes(lot.batch));
  const packs = hits.reduce((sum, lot) => sum + lot.packs, 0);
  return <section className="organelle-panel rounded-xl p-5 space-y-4">
    <div className="flex flex-wrap justify-between items-end gap-3">
      <div>
        <h3 className="flex items-center gap-2 font-display text-lg font-semibold text-[#1E221D]">
          <BellRing className="w-4 h-4 text-[#B8841E]" /> Alert Ripple
        </h3>
        <p className="text-xs text-[#555A50]">Demonstration only · Simulated notices and synthetic stock</p>
      </div>
      <label className="text-xs font-semibold text-[#3C4138]">Sample regulatory notice
        <select className="block mt-1 rounded-lg border border-[#C6B69E] bg-[#FCF9F4] px-3 py-2"
          value={selected} onChange={(event) => setSelected(event.target.value)}>
          {notices.map((entry) => <option key={entry.id} value={entry.id}>{entry.id} · {entry.product}</option>)}
        </select>
      </label>
    </div>
    <p className="text-xs text-[#3C4138]">Simulated quality notice · Demo Labs · Batches {notice.batches.join(', ')}</p>
    <div className="grid grid-cols-3 gap-2 text-center" aria-live="polite">
      {[[hits.length, 'Matching lots'], [packs, 'Affected packs'], [hits.length, 'Reviews required']].map(([value, label]) =>
        <div key={label} className="rounded-lg border border-[#D5C8B4] bg-[#EFE7DA] p-2">
          <p className="font-display text-lg font-semibold text-[#1E221D]">{value}</p>
          <p className="text-xs text-[#3C4138]">{label}</p>
        </div>)}
    </div>
    <ul className="grid gap-2 border-l-2 border-[#DEC595] pl-3">
      {hits.map((lot) => <li key={lot.shelf} className="organelle-subpanel rounded-lg px-3 py-2 flex flex-wrap justify-between gap-2 text-xs">
        <span className="flex items-center gap-2 text-[#1E221D]"><PackageCheck className="w-4 h-4 text-[#556B22]" />
          <strong>{lot.product} · {lot.batch}</strong> · {lot.shelf} · {lot.packs} packs
        </span>
        <span className="text-[#875E0D] font-semibold">Pharmacist review required</span>
      </li>)}
    </ul>
  </section>;
}
