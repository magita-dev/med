import { ExternalLink, ShieldCheck } from 'lucide-react';

export function sourceLink(value?: string) {
  if (!value) return undefined;
  try {
    const url = new URL(value);
    return url.protocol === 'https:' || url.protocol === 'http:' ? url.href : undefined;
  } catch {
    return undefined;
  }
}

interface PassportProps {
  authority: string;
  medicine: string;
  batch: string;
  source?: string;
  publication?: string;
  limitation: string;
}

export function EvidencePassport({ authority, medicine, batch, source, publication, limitation }: PassportProps) {
  const href = sourceLink(source);
  return (
    <section aria-label="Evidence Passport" className="rounded-lg border border-[#D5C8B4] bg-[#FCF9F4] p-3 space-y-2 text-xs text-[#3C4138]">
      <h5 className="flex items-center gap-1.5 font-semibold text-[#556B22]">
        <ShieldCheck className="w-3.5 h-3.5" /> Evidence Passport
      </h5>
      <dl className="grid grid-cols-2 gap-x-3 gap-y-2">
        <div><dt className="font-semibold">Authority or reference</dt><dd className="break-words">{authority}</dd></div>
        <div><dt className="font-semibold">Medicine</dt><dd className="break-words">{medicine}</dd></div>
        <div><dt className="font-semibold">Batch match</dt><dd>{batch}</dd></div>
        <div><dt className="font-semibold">Published</dt><dd>{publication || 'Unavailable'}</dd></div>
      </dl>
      <p>{limitation}</p>
      {href ? <a href={href} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-[#29659B] underline">Open source <ExternalLink className="w-3 h-3" /></a> : <p>Direct source link unavailable.</p>}
    </section>
  );
}
