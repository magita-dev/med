import asyncio
import json
import logging
import os
import re
from collections import defaultdict
from contextlib import asynccontextmanager
from datetime import date, datetime, timedelta, timezone
from hashlib import sha256
from pathlib import Path
from typing import Annotated, Literal
from uuid import uuid4

import httpx
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError
from cryptography.fernet import Fernet, MultiFernet
from fastapi import Depends, FastAPI, Form, HTTPException, Request, Response, UploadFile
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from fastapi.staticfiles import StaticFiles
from pydantic import ValidationError

from .candidates import CandidateKeys
from .core import assess, composition, ingredient, latest, name, screen
from .documents import extract, inspect_page
from .identity import IdentityCatalog
from .models import Approval, Notice, Pack, Regimen, Resolution, Stock
from .ocr import propose_fields, recognize
from .sources import observe, official_url
from .store import Evidence, Memory, Mongo
from .auth import PERMISSIONS, SessionStore, can
from .governance import ClinicalRegistry
from .groundtruth import GroundTruthLibrary
from .ledger import Ledger
from .molecular import PROTEINS, MolecularCatalog, protein_view
from .outbox import Notification, Outbox
from .ocrlib import ModelRegistry, compare_baselines
from .registry import ReviewedIdentityRegistry
from .verification import verify_action_scope

FIXTURES = Path(__file__).resolve().parents[2] / "fixtures"
CLINICAL = json.loads((FIXTURES / "clinical.json").read_text(encoding="utf-8"))
clinical = ClinicalRegistry(CLINICAL)
LIMIT = 8 * 1024 * 1024
PASSWORDS = PasswordHasher()
BASIC = HTTPBasic(auto_error=False)
LOG = logging.getLogger(__name__)


def now():
    return datetime.now(timezone.utc).isoformat()


async def file_bytes(upload, limit=LIMIT):
    data = await upload.read(limit + 1)
    if not data or len(data) > limit:
        raise HTTPException(413, "Upload is empty or exceeds the sample size limit")
    return data


def create_app(store=None, accounts=None, evidence_dir=None, *, worker_only=False):
    demo = os.getenv("MEDGUARD_DEMO") == "1"
    if store is None:
        uri = os.getenv("MEDGUARD_MONGO_URI")
        if not uri and not demo:
            raise RuntimeError("Set MEDGUARD_MONGO_URI or explicitly enable synthetic demo mode")
        store = Mongo(uri) if uri else Memory()
    key = os.getenv("MEDGUARD_ENCRYPTION_KEY")
    if isinstance(store, Mongo) and not key:
        raise RuntimeError("Persistent storage requires MEDGUARD_ENCRYPTION_KEY")
    if isinstance(store, Mongo) and demo:
        raise RuntimeError("Demo accounts and fixtures require in-memory storage")
    encryption_key = key.encode() if key else Fernet.generate_key()
    previous_keys = os.getenv("MEDGUARD_PREVIOUS_ENCRYPTION_KEYS", "").split()
    cipher = MultiFernet([Fernet(encryption_key), *(Fernet(value.encode()) for value in previous_keys)])
    evidence = Evidence(cipher, evidence_dir or os.getenv("MEDGUARD_EVIDENCE_DIR"))
    catalog_path = os.getenv("MEDGUARD_IDENTITY_CATALOG")
    catalog_text = Path(catalog_path).read_text(encoding="utf-8") if catalog_path else "[]"
    catalog = IdentityCatalog(json.loads(catalog_text))
    index_secret = os.getenv("MEDGUARD_INDEX_KEY")
    if index_secret and len(index_secret.encode()) < 32:
        raise RuntimeError("MEDGUARD_INDEX_KEY must contain at least 32 bytes")
    keys = CandidateKeys(index_secret.encode() if index_secret else encryption_key, catalog_text)
    if demo:
        evidence.bucket = None
    source_urls = list(dict.fromkeys(os.getenv("MEDGUARD_SOURCE_URLS", "").split()))
    if not all(official_url(url) for url in source_urls):
        raise RuntimeError("Source monitoring requires official HTTPS URLs")

    if accounts is None:
        if demo:
            accounts = {
                user: {"hash": PASSWORDS.hash("medguard-demo"), "tenant": tenant, "role": role}
                for user, tenant, role in (
                    ("reviewer", "demo", "publisher"), ("second-reviewer", "demo", "publisher"),
                    ("household", "demo", "member"),
                    ("pharmacy", "pharmacy", "member"),
                )
            }
        else:
            accounts = json.loads(Path(os.environ["MEDGUARD_ACCOUNTS"]).read_text(encoding="utf-8"))
    dummy = PASSWORDS.hash(uuid4().hex)
    for account in accounts.values():
        tenant = account["tenant"]
        if not re.fullmatch(r"[a-zA-Z0-9_-]{1,80}", tenant):
            raise RuntimeError("Invalid account tenant")
        if account["role"] not in {"publisher", "member"} or not account["hash"].startswith("$argon2id$"):
            raise RuntimeError("Invalid account role or password hash")

    sessions = SessionStore(encryption_key)
    ground_truth = GroundTruthLibrary()
    outbox = Outbox()
    ledger = Ledger()
    molecular = MolecularCatalog()
    identity_registry = ReviewedIdentityRegistry(json.loads(catalog_text))
    ocr_registry = ModelRegistry()

    @asynccontextmanager
    async def lifecycle(_app):
        if isinstance(store, Mongo):
            await store.start()
        if demo:
            for notice in json.loads((FIXTURES / "regulatory.json").read_text(encoding="utf-8")):
                await store.add("notices", notice)
        background = worker_only or os.getenv("MEDGUARD_WORKER_MODE", "embedded") == "embedded"
        tasks = [asyncio.create_task(surveillance_worker())] if background else []
        if background and source_urls:
            tasks.append(asyncio.create_task(source_worker()))
        try:
            yield
        finally:
            for task in tasks:
                task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
            if isinstance(store, Mongo):
                await store.client.close()

    app = FastAPI(title="MedGuard", lifespan=lifecycle,
                  docs_url="/api/docs", openapi_url="/api/openapi.json")

    @app.middleware("http")
    async def protect_response(request, call_next):
        response = await call_next(request)
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
        return response

    async def identity(request: Request, credentials: Annotated[HTTPBasicCredentials | None, Depends(BASIC)]):
        header = request.headers.get("authorization", "")
        if header[:7].lower() == "bearer ":
            actor = sessions.verify(header[7:].strip())
            if actor is None:
                raise HTTPException(401, "Invalid or expired session")
            return actor
        if credentials is None or len(credentials.password) > 256:
            raise HTTPException(401, "Sign in with your MedGuard account")
        account = accounts.get(credentials.username)
        try:
            await asyncio.to_thread(PASSWORDS.verify, account["hash"] if account else dummy,
                                    credentials.password)
        except VerifyMismatchError:
            raise HTTPException(401, "Invalid sign-in") from None
        if account is None:
            raise HTTPException(401, "Invalid sign-in")
        return {**account, "user": credentials.username}

    SignedIn = Annotated[dict, Depends(identity)]

    async def publisher(actor: SignedIn):
        if actor["role"] != "publisher":
            raise HTTPException(403, "Publisher role required")
        return actor

    Publisher = Annotated[dict, Depends(publisher)]

    async def active_notices():
        trusted = {"independently_verified", "human_reviewed_unverified_extraction"}
        if demo:
            trusted.update({"historical_fixture", "synthetic"})
        eligible = [row for row in await store.find("notices") if row.get("evidence_status") in trusted]
        return [row for row in latest(eligible, date.today().isoformat())
                if row.get("row_validation") != "manual_scope_review"]

    def index_notices(notices):
        index = defaultdict(list)
        for notice in notices:
            key = (("fdc", composition(notice["ingredients"])) if notice["kind"] == "prohibition"
                   else ("product", name(catalog.resolve(notice)["product"])))
            index[key].append(notice)
        return index

    def matches(pack, index):
        candidates = (index.get(("product", name(catalog.resolve(pack)["product"])), []) +
                      index.get(("fdc", composition(pack["ingredients"])), []))
        return [result for notice in candidates if (result := compare(pack, notice)) is not None]

    def compare(pack, notice):
        result = assess(catalog.resolve(pack), catalog.resolve(notice))
        if result:
            result["notice"] = notice
            if (notice.get("evidence_status") == "human_reviewed_unverified_extraction"
                    and result["status"] == "exact"):
                result["status"] = "uncertain"
        return result

    def reveal(row):
        return json.loads(cipher.decrypt(row["ciphertext"]).decode("utf-8"))

    def stock_index(pack):
        return {"index_version": keys.version, "candidate_keys": keys.stock(catalog.resolve(pack))}

    async def register_impacts(stock, notices):
        tenant = stock["tenant"]
        for match in matches(reveal(stock), notices):
            if match["status"] == "different_batch":
                continue
            revision = match["notice"]["_id"]
            event = f'{tenant}:{stock["_id"]}:{revision}'
            await store.add("impacts", {"_id": event, "tenant": tenant, "stock_id": stock["_id"],
                                        "revision": revision, "created": now()})

    async def reconcile():
        for notice in await active_notices():
            key = notice["_id"] + ":" + keys.version
            await store.add("surveillance_jobs", {"_id": key, "after": "", "lease_until": "", "completed": False})
            token = uuid4().hex
            lease = lambda: (datetime.now(timezone.utc) + timedelta(minutes=2)).isoformat()
            job = await store.claim_job(key, token, now(), lease())
            if not job:
                continue
            index = index_notices([notice])
            token_key = keys.notice(catalog.resolve(notice))
            async for stock in store.candidate_stock(job["after"], keys.version, token_key):
                await register_impacts(stock, index)
                if not await store.advance_job(key, token, after=stock["_id"], lease_until=lease()):
                    break
            else:
                await store.advance_job(key, token, completed=True, completed_at=now())
        pending = await store.pending_stock(keys.version)
        index = index_notices(await active_notices()) if pending else {}
        for stock in pending:
            await register_impacts(stock, index)
            await store.mark_stock_checked(stock["_id"], **stock_index(reveal(stock)))

    async def surveillance_worker():
        while True:
            try:
                await reconcile()
                await store.replace("worker_status", {"_id": "surveillance", "last_success_at": now()})
            except Exception:
                LOG.error("Surveillance reconciliation failed; will retry")
            await asyncio.sleep(60)

    async def source_worker():
        async with httpx.AsyncClient(timeout=15, trust_env=False) as client:
            while True:
                try:
                    await observe(store, source_urls, now, client, evidence)
                except Exception:
                    LOG.error("Official source monitoring failed; will retry")
                await asyncio.sleep(3600)

    @app.get("/api/source-status")
    async def source_status(actor: Publisher):
        ingestion = await store.find("ingestion")
        skipped = [{"source": item.get("source"), "sha256": item.get("sha256"),
                    "status": item.get("status"), "error": item.get("extraction_error"),
                    "page_limit": item.get("page_limit")}
                   for item in ingestion
                   if item.get("status") in {"manual_review", "image_only_manual_review"}
                   or item.get("extraction_error")]
        return {"sources": await store.find("source_status"),
                "observed_versions": await store.find("source_versions"),
                "ingestion": ingestion, "skipped_documents": skipped}

    @app.get("/api/notice-drafts")
    async def notice_drafts(actor: Publisher):
        approved = {row["_id"] for row in await store.find("notices")}
        return [draft for draft in await store.find("notice_drafts") if draft["_id"] not in approved]

    @app.get("/api/ingestion/{digest}/document")
    async def captured_document(digest: str, actor: Publisher):
        if not re.fullmatch(r"[0-9a-f]{64}", digest) or not await store.find("ingestion", sha256=digest):
            raise HTTPException(404, "Captured document unavailable")
        try:
            data = await evidence.get(digest)
        except Exception:
            raise HTTPException(409, "Could not retrieve the captured document") from None
        if sha256(data).hexdigest() != digest:
            raise HTTPException(409, "Captured document failed integrity verification")
        return Response(data, media_type="application/pdf",
                        headers={"Content-Disposition": 'attachment; filename="captured-notice.pdf"'})

    async def queue(tenant):
        reviews = {row["_id"]: row for row in await store.find("reviews", tenant=tenant)}
        resolutions = {row["_id"]: row for row in await store.find("resolutions", tenant=tenant)}
        notices = {row["_id"]: row for row in await active_notices()}
        stock = {row["_id"]: row for row in await store.find("stock", tenant=tenant)}
        result = []
        for impact in await store.find("impacts", tenant=tenant):
            notice = notices.get(impact["revision"])
            if notice is None or impact["stock_id"] not in stock:
                continue
            pack = reveal(stock[impact["stock_id"]])
            match = compare(pack, notice)
            if match and match["status"] != "different_batch":
                event = impact["_id"]
                result.append({"id": event, "stock_id": impact["stock_id"], "product": pack["product"],
                               "created": impact["created"], **match,
                               "acknowledgement": reviews.get(event),
                               "resolution": public_resolution(resolutions.get(event))})
        return result

    def public_resolution(row):
        return {key: value for key, value in row.items() if key != "note_ciphertext"} if row else None

    @app.get("/api/health")
    async def health():
        if isinstance(store, Mongo):
            try:
                await store.client.admin.command("ping")
            except Exception:
                raise HTTPException(503, "Database unavailable") from None
        heartbeats = await store.find("worker_status", _id="surveillance")
        last_success = heartbeats[0]["last_success_at"] if heartbeats else None
        cutoff = (datetime.now(timezone.utc) - timedelta(minutes=5)).isoformat()
        return {"status": "ok", "database": "mongo" if isinstance(store, Mongo) else "memory",
                "surveillance": {"last_success_at": last_success,
                                 "stale": not last_success or last_success < cutoff}}

    async def freshness():
        statuses = {row["source"]: row for row in await store.find("source_status")}
        cutoff = (datetime.now(timezone.utc) - timedelta(hours=2)).isoformat()
        result = []
        monitored = set(source_urls)
        for url in sorted(monitored | {row["source"] for row in statuses.values()
                                      if row.get("discovered_from") in monitored}):
            entry = statuses.get(url, {})
            success = entry.get("last_success_at")
            result.append({"source": url, "checked_at": entry.get("checked_at"),
                           "last_success_at": success, "stale": not success or success < cutoff,
                           "error": entry.get("error"), "document_limit_reached": entry.get("document_limit_reached", False)})
        return {"sources": result, "freshness_window_hours": 2, "coverage": "configured_sources_only",
                "review_pending_possible": True}

    @app.get("/api/me")
    async def me(actor: SignedIn):
        return {**{field: actor[field] for field in ("user", "role", "tenant")}, "demo": demo}

    @app.post("/api/check")
    async def check(pack: Pack, actor: SignedIn):
        data = pack.model_dump()
        return {"matches": [{**match, "tier": "verified"}
                            for match in matches(data, index_notices(await active_notices()))],
                "identity_candidates": catalog.candidates(data), "limited_coverage": True,
                "not_found_as_of": date.today().isoformat(),
                "regulatory_freshness": await freshness()}

    @app.post("/api/regimen")
    async def regimen(payload: Regimen, actor: SignedIn):
        packs = [pack.model_dump() for pack in payload.packs]
        notices = index_notices(await active_notices())
        ingredients = {ingredient(value) for pack in packs for value in pack["ingredients"]}
        known_pairs = {tuple(sorted(rule["ingredients"])) for rule in CLINICAL if rule["kind"] == "interaction"}
        pair_count = len(ingredients) * (len(ingredients) - 1) // 2
        covered = sum(set(pair).issubset(ingredients) for pair in known_pairs)
        return {"findings": screen(packs, payload.age, CLINICAL),
                "matches": [{**match, "tier": "verified"} for pack in packs for match in matches(pack, notices)],
                "clinical_coverage": {"jurisdiction": "US", "scope": "Selected label rules",
                                      "unassessed_interactions_possible": True,
                                      "unassessed_pair_count": pair_count - covered,
                                      "packs_missing_ingredients": sum(not pack["ingredients"] for pack in packs)},
                "limited_coverage": True, "not_found_as_of": date.today().isoformat(),
                "regulatory_freshness": await freshness()}

    @app.get("/api/stock")
    async def stock(actor: SignedIn):
        return [{"id": row["_id"], **Stock.model_validate(reveal(row)).model_dump()}
                for row in await store.find("stock", tenant=actor["tenant"])]

    @app.put("/api/stock/{item_id}")
    async def save_stock(item_id: str, pack: Stock, actor: SignedIn):
        if not re.fullmatch(r"[0-9a-f-]{36}", item_id):
            raise HTTPException(422, "Provide a UUID for retry-safe stock registration")
        tenant = actor["tenant"]
        identifier = f"{tenant}:{item_id}"
        row = {"_id": identifier, "tenant": tenant, "actor": actor["user"], "created": now(),
               "ciphertext": cipher.encrypt(pack.model_dump_json().encode()).decode("ascii"),
               **stock_index(pack.model_dump())}
        if not await store.add("stock", row):
            existing = (await store.find("stock", _id=identifier, tenant=tenant))[0]
            if Stock.model_validate(reveal(existing)) != pack:
                raise HTTPException(409, "Stock ID already represents a different confirmed pack")
            row = existing
        await register_impacts(row, index_notices(await active_notices()))
        await store.mark_stock_checked(row["_id"], **stock_index(pack.model_dump()))
        return {"id": identifier}

    @app.get("/api/reviews")
    async def reviews(actor: SignedIn):
        return await queue(actor["tenant"])

    @app.get("/api/notifications")
    async def notifications(actor: SignedIn):
        return [item for item in await queue(actor["tenant"]) if not item["acknowledgement"]]

    @app.put("/api/reviews/{event}/ack")
    async def acknowledge(event: str, actor: SignedIn):
        tenant = actor["tenant"]
        existing = await store.find("reviews", _id=event, tenant=tenant)
        if existing:
            return existing[0]
        match = next((item for item in await queue(tenant) if item["id"] == event), None)
        if match is None:
            raise HTTPException(404, "Review item unavailable")
        row = {"_id": event, "tenant": tenant, "actor": actor["user"], "at": now(),
               "notice": match["notice"]["_id"], "status_at_acknowledgement": match["status"]}
        await store.add("reviews", row)
        return (await store.find("reviews", _id=event, tenant=tenant))[0]

    @app.get("/api/audit")
    async def audit(actor: SignedIn):
        tenant = actor["tenant"]
        return sorted(await store.find("reviews", tenant=tenant) +
                      [public_resolution(row) for row in await store.find("resolutions", tenant=tenant)],
                      key=lambda event: event["at"])

    @app.put("/api/reviews/{event}/resolution")
    async def resolve(event: str, resolution: Resolution, actor: SignedIn):
        tenant = actor["tenant"]
        existing = await store.find("resolutions", _id=event, tenant=tenant)
        if not existing:
            match = next((item for item in await queue(tenant) if item["id"] == event), None)
            if match is None:
                raise HTTPException(404, "Review item unavailable")
            if not match["acknowledgement"]:
                raise HTTPException(409, "Acknowledge the inventory impact first")
            row = {"_id": event, "tenant": tenant, "actor": actor["user"], "at": now(),
                   "type": "resolution", "outcome": resolution.outcome,
                   "note_ciphertext": cipher.encrypt(resolution.note.encode()).decode("ascii")}
            await store.add("resolutions", row)
            existing = await store.find("resolutions", _id=event, tenant=tenant)
        row = existing[0]
        if row["outcome"] != resolution.outcome or cipher.decrypt(row["note_ciphertext"]).decode() != resolution.note:
            raise HTTPException(409, "A response has already been recorded")
        return public_resolution(row)

    @app.get("/api/notices")
    async def notices(actor: SignedIn):
        return await store.find("notices")

    @app.get("/api/notice-schema")
    async def notice_schema(actor: Publisher):
        return Notice.model_json_schema()

    @app.get("/api/evidence/{digest}")
    async def download_evidence(digest: str, actor: SignedIn):
        if not re.fullmatch(r"[0-9a-f]{64}", digest) or not await store.find("notices", sha256=digest):
            raise HTTPException(404, "Evidence unavailable")
        try:
            data = await evidence.get(digest)
        except Exception:
            LOG.error("Evidence object retrieval or decryption failed")
            raise HTTPException(500, "Evidence could not be retrieved or decrypted") from None
        if sha256(data).hexdigest() != digest:
            LOG.error("Evidence digest verification failed")
            raise HTTPException(500, "Evidence integrity verification failed")
        return Response(data, media_type="application/pdf",
                        headers={"Content-Disposition": 'attachment; filename="notice.pdf"'})

    @app.post("/api/evidence/extract")
    async def extract_notice(file: UploadFile, actor: Publisher,
                             engine: Literal["pdfplumber", "pymupdf"] = "pdfplumber"):
        data = await file_bytes(file)
        if not data.startswith(b"%PDF-"):
            raise HTTPException(422, "Provide a notice PDF")
        try:
            pages = await asyncio.to_thread(extract, data, engine)
        except ImportError:
            raise HTTPException(503, "Selected parser is unavailable") from None
        except Exception:
            LOG.warning("Regulatory PDF parser failed")
            raise HTTPException(422, "Document could not be parsed") from None
        return {"sha256": sha256(data).hexdigest(), "pages": pages, "confirmed": False}

    @app.post("/api/notices")
    async def publish(file: UploadFile, metadata: Annotated[str, Form()],
                      verified: Annotated[bool, Form()], actor: Publisher):
        if not verified:
            raise HTTPException(422, "Confirm source provenance and scope before publishing")
        try:
            notice = Notice.model_validate_json(metadata).model_dump(mode="json")
        except ValidationError:
            raise HTTPException(422, "Invalid notice metadata") from None
        data = await file_bytes(file)
        if not data.startswith(b"%PDF-"):
            raise HTTPException(422, "Provide a notice PDF")
        digest = sha256(data).hexdigest()
        await evidence.put(digest, data)
        return await submit_draft(notice, digest, actor)

    @app.post("/api/ingestion/{digest}/draft")
    async def draft_capture(digest: str, notice: Notice, actor: Publisher):
        data = notice.model_dump(mode="json")
        if not re.fullmatch(r"[0-9a-f]{64}", digest) or not await store.find(
                "ingestion", _id=notice.source + "|" + digest):
            raise HTTPException(404, "Capture does not match this official source")
        return await submit_draft(data, digest, actor)

    async def submit_draft(notice, digest, actor):
        identifier = f'{notice["key"]}:{notice["version"]}'
        observed = await store.find("source_versions", _id=notice["source"] + "|" + digest, pdf=True)
        row = {"_id": identifier, **notice, "sha256": digest, "submitted_by": actor["user"],
               "submitted_at": now(), "evidence_status": "source_observed" if observed else "publisher_attested",
               "origin_bytes_matched": bool(observed)}
        if not await store.add("notice_drafts", row):
            existing = (await store.find("notice_drafts", _id=identifier))[0]
            if any(existing.get(field) != value for field, value in {**notice, "sha256": digest}.items()):
                raise HTTPException(409, "This notice revision is immutable")
            row = existing
        return row

    @app.put("/api/notice-drafts/{identifier}/approve")
    async def approve_notice(identifier: str, actor: Publisher, approval: Approval | None = None):
        drafts = await store.find("notice_drafts", _id=identifier)
        if not drafts:
            raise HTTPException(404, "Notice draft unavailable")
        draft = drafts[0]
        if draft["submitted_by"] == actor["user"]:
            raise HTTPException(403, "A different publisher must review the source and scope")
        if draft.get("source_page") is None:
            raise HTTPException(409, "A numbered source page is required for approval")
        digest = draft["sha256"]
        observed = await store.find("source_versions", _id=draft["source"] + "|" + digest, pdf=True)
        if not observed:
            raise HTTPException(409, "Official source bytes have not been observed")
        try:
            data = await evidence.get(digest)
            authentic = sha256(data).hexdigest() == digest
        except Exception:
            authentic = False
        if not authentic:
            raise HTTPException(409, "Stored evidence failed verification")
        captures = await store.find("ingestion", _id=draft["source"] + "|" + digest)
        candidates = captures[0].get("rows", []) if captures else []
        validation = "human_reviewed_unverified_extraction"
        status = validation
        if draft["active"] and draft["kind"] == "nsq" and candidates:
            cited = [row for row in candidates if row["locator"] == draft["locator"]]
            if len(cited) != 1:
                raise HTTPException(409, "The cited NSQ row is missing or ambiguous")
            if not any(all(row.get(field) == draft.get(field) for field in ("source_page", "product", "manufacturer", "batch"))
                       for row in cited):
                raise HTTPException(409, "Notice fields differ from the cited extracted NSQ row")
            validation = "extracted_row_verified"
            status = "independently_verified"
        try:
            span_text = await asyncio.to_thread(inspect_page, data, draft["source_page"], draft.get("evidence_span"))
        except Exception:
            raise HTTPException(409, "The cited PDF page or evidence span could not be read") from None
        if status == "human_reviewed_unverified_extraction":
            if not draft.get("evidence_span") or not draft.get("submitter_attests_span") or not approval:
                raise HTTPException(409, "Manual review requires an evidence span and both reviewer attestations")
            if span_text and draft["active"]:
                # Compare the printed batch case-sensitively. A blank text layer still requires visual review.
                if draft.get("batch") and not re.search(
                        r"(?<![\w./-])" + re.escape(draft["batch"]) + r"(?![\w./-])", span_text):
                    raise HTTPException(409, "The batch is absent from the selected evidence span")
                normalized = name(span_text)
                for field in ("product", "manufacturer"):
                    if draft.get(field) and not re.search(
                            r"(?<!\w)" + re.escape(name(draft[field])) + r"(?!\w)", normalized):
                        raise HTTPException(409, f"The {field} is absent from the selected evidence span")
        row = {**draft, "evidence_status": status, "origin_bytes_matched": True,
               "reviewer_attests_span": bool(approval),
               "reviewer": actor["user"], "reviewed_at": now(), "row_validation": validation,
               "verification": {"source_bytes": "official_capture_digest_match",
                                "transcription": validation,
                                "scope": "reviewer_attested"}}
        if not await store.add("notices", row):
            row = (await store.find("notices", _id=identifier))[0]
            if row.get("sha256") != digest or row.get("evidence_status") != status:
                raise HTTPException(409, "Notice revision already exists")
        if not isinstance(store, Mongo) or os.getenv("MEDGUARD_WORKER_MODE", "embedded") == "embedded":
            await reconcile()
        return row

    @app.post("/api/ocr")
    async def ocr(file: UploadFile, actor: SignedIn, language: Literal["en", "hi", "ta"] = "en"):
        data = await file_bytes(file)
        if not os.getenv("MEDGUARD_OCR_DETECTOR"):
            raise HTTPException(503, "Local OCR models are unavailable. Enter the fields manually.")
        try:
            lines = await asyncio.to_thread(recognize, data, language)
        except (ImportError, KeyError, OSError):
            raise HTTPException(503, "Local OCR configuration is incomplete") from None
        except Exception:
            LOG.warning("Local OCR inference failed")
            raise HTTPException(422, "Image recognition failed. Review the original manually.") from None
        return {"confirmed": False, "lines": lines, "proposals": propose_fields(lines)}

    # ---- additive modules: clinical governance, ground-truth, outbox, ledger, molecular, identity ----
    @app.get("/api/clinical/rules")
    async def clinical_rules(actor: SignedIn):
        return {"rules": clinical.report(), "governed": len(clinical.governed),
                "total": len(clinical.rules),
                "not_governed": len(clinical.not_governed)}

    @app.get("/api/permissions")
    async def permissions(actor: SignedIn):
        return {"role": actor["role"], "permissions": sorted(PERMISSIONS.get(actor["role"], set()))}

    @app.post("/api/session")
    async def issue_session(actor: SignedIn):
        return {"token": sessions.issue(
            {"user": actor["user"], "role": actor["role"], "tenant": actor["tenant"], "demo": demo})}

    @app.get("/api/ground-truth")
    async def ground_truth_list(actor: SignedIn):
        return {"entries": ground_truth.entries(), "disagreements": ground_truth.disagreements()}

    @app.post("/api/ground-truth")
    async def ground_truth_add(payload: dict, actor: Publisher):
        try:
            return ground_truth.add(payload)
        except Exception:
            raise HTTPException(422, "Invalid ground-truth entry") from None

    @app.get("/api/outbox")
    async def outbox_list(actor: SignedIn):
        return [m.model_dump() for m in outbox.entries(actor["tenant"])]

    @app.post("/api/outbox")
    async def outbox_enqueue(payload: dict, actor: Publisher):
        try:
            msg = outbox.enqueue(Notification(**{"tenant": actor["tenant"], **payload}))
        except Exception:
            raise HTTPException(422, "Invalid notification") from None
        return msg.model_dump()

    @app.post("/api/outbox/deliver")
    async def outbox_deliver(actor: SignedIn):
        return {"delivered": await outbox.deliver_pending(actor["tenant"])}

    @app.put("/api/outbox/{message_id}/ack")
    async def outbox_ack(message_id: str, actor: SignedIn):
        msg = outbox.acknowledge(message_id, actor["tenant"])
        if msg is None:
            raise HTTPException(404, "Notification unavailable")
        return msg.model_dump()

    @app.get("/api/stock/{item_id}/transactions")
    async def stock_transactions(item_id: str, actor: SignedIn):
        ref = item_id if ":" in item_id else f'{actor["tenant"]}:{item_id}'
        return [t.model_dump() for t in ledger.for_stock(ref, actor["tenant"])]

    @app.post("/api/stock/{item_id}/movements")
    async def stock_movement(item_id: str, payload: dict, actor: SignedIn):
        ref = item_id if ":" in item_id else f'{actor["tenant"]}:{item_id}'
        try:
            return ledger.append({"stock_id": ref, "tenant": actor["tenant"],
                                  "actor": actor["user"], "id": payload.get("id"),
                                  "kind": payload.get("kind"),
                                  "quantity_delta": payload.get("quantity_delta", 0),
                                  "note": payload.get("note", ""),
                                  "verified": bool(payload.get("verified", False))}).model_dump()
        except Exception:
            raise HTTPException(422, "Invalid stock movement") from None

    @app.get("/api/stock/{item_id}/reconcile")
    async def stock_reconcile(item_id: str, actor: SignedIn):
        ref = item_id if ":" in item_id else f'{actor["tenant"]}:{item_id}'
        rows = await store.find("stock", _id=ref, tenant=actor["tenant"])
        if not rows:
            raise HTTPException(404, "Stock item unavailable")
        quantity = Stock.model_validate(reveal(rows[0])).quantity
        return ledger.reconcile(ref, actor["tenant"], quantity)

    @app.get("/api/molecular/evidence")
    async def molecular_evidence(actor: SignedIn):
        return molecular.evidence()

    @app.post("/api/molecular/evidence")
    async def molecular_add_evidence(payload: dict, actor: Publisher):
        try:
            return molecular.add_evidence(payload)
        except Exception:
            raise HTTPException(422, "Invalid molecular evidence entry") from None

    @app.get("/api/molecular/proteins")
    async def molecular_proteins(actor: SignedIn):
        return [protein_view(target) for target in PROTEINS]

    @app.get("/api/molecular/proteins/{target}")
    async def molecular_protein(target: str, actor: SignedIn):
        view = protein_view(target)
        if view is None:
            raise HTTPException(404, "Protein not in the library")
        return view

    def pharmacist_only(actor: dict) -> None:
        # Structure-based hypotheses are reviewer-facing; patients and households never see them.
        if not can(actor, "review_molecular"):
            raise HTTPException(403, "Pharmacist review role required")

    @app.get("/api/molecular/hypotheses")
    async def molecular_hypotheses(actor: SignedIn):
        pharmacist_only(actor)
        return molecular.public_hypotheses()

    @app.get("/api/molecular/queue")
    async def molecular_queue(actor: SignedIn):
        pharmacist_only(actor)
        return molecular.queue()

    @app.post("/api/molecular/hypotheses")
    async def molecular_propose(payload: dict, actor: Publisher):
        try:
            return molecular.propose({**payload, "id": payload.get("id", uuid4().hex),
                                      "proposed_by": actor["user"], "tier": "predicted"})
        except Exception:
            raise HTTPException(422, "Invalid hypothesis proposal") from None

    @app.put("/api/molecular/hypotheses/{hypothesis_id}/review")
    async def molecular_review(hypothesis_id: str, payload: dict, actor: Publisher):
        pharmacist_only(actor)
        try:
            return molecular.review(hypothesis_id, actor["user"], bool(payload.get("accept")))
        except PermissionError as error:
            raise HTTPException(403, str(error)) from None
        except KeyError:
            raise HTTPException(404, "Hypothesis unavailable") from None
        except Exception:
            raise HTTPException(422, "Hypothesis review failed") from None

    @app.get("/api/identity/registry")
    async def identity_registry_report(actor: SignedIn):
        return {"entries": identity_registry.report(), "valid": identity_registry.valid,
                "errors": identity_registry.errors}

    @app.get("/api/notices/{notice_id}/verification")
    async def notice_verification(notice_id: str, actor: Publisher):
        rows = await store.find("notices", _id=notice_id) or await store.find("notice_drafts", _id=notice_id)
        if not rows:
            raise HTTPException(404, "Notice unavailable")
        return verify_action_scope(rows[0])

    @app.get("/api/ocr/models")
    async def ocr_models(actor: SignedIn):
        return ocr_registry.entries()

    @app.post("/api/ocr/models")
    async def ocr_models_add(payload: dict, actor: Publisher):
        try:
            return ocr_registry.add(payload)
        except Exception:
            raise HTTPException(422, "Invalid model record") from None

    @app.post("/api/ocr/compare")
    async def ocr_compare(payload: dict, actor: SignedIn):
        try:
            return compare_baselines(payload.get("results", []))
        except Exception:
            raise HTTPException(422, "Invalid evaluation results") from None

    if os.getenv("MEDGUARD_STATIC") == "1":
        app.mount("/", StaticFiles(directory=FIXTURES.parent / "frontend" / "dist", html=True))
    return app
