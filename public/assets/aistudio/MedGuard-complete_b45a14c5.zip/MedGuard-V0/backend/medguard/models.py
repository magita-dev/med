from datetime import date
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, StringConstraints, field_validator, model_validator

from .sources import official_url

Label = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=200)]
OptionalLabel = Annotated[str, StringConstraints(strip_whitespace=True, max_length=200)]
Key = Annotated[str, StringConstraints(pattern=r"^[a-z0-9][a-z0-9_-]{0,79}$")]


class Input(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class Pack(Input):
    product: Label
    manufacturer: OptionalLabel = ""
    batch: OptionalLabel = ""
    ingredients: list[Label] = Field(default_factory=list, max_length=20)
    form: OptionalLabel = ""
    strength: OptionalLabel = ""
    confirmed: Literal[True]


class Notice(Input):
    key: Key
    version: int = Field(ge=1, le=10000)
    kind: Literal["nsq", "spurious", "recall", "prohibition"]
    finding: OptionalLabel = ""
    action_type: OptionalLabel = ""
    authority: OptionalLabel = ""
    scope: OptionalLabel = ""
    product: OptionalLabel = ""
    manufacturer: OptionalLabel = ""
    batch: OptionalLabel = ""
    ingredients: list[Label] = Field(default_factory=list, max_length=20)
    form: OptionalLabel = ""
    strength: OptionalLabel = ""
    source: str = Field(max_length=1600)
    locator: Label
    source_page: int | None = Field(default=None, ge=1, le=10000)
    evidence_span: tuple[float, float, float, float] | None = None
    submitter_attests_span: bool = False
    published: date
    effective: date
    active: bool = True
    all_formulations: bool = False

    @field_validator("source")
    @classmethod
    def official_source(cls, value):
        if not official_url(value):
            raise ValueError("Provide a direct HTTPS CDSCO or eGazette URL")
        return value

    @model_validator(mode="after")
    def require_scope(self):
        if self.evidence_span:
            left, top, right, bottom = self.evidence_span
            if not (0 <= left < right <= 1 and 0 <= top < bottom <= 1):
                raise ValueError("Evidence span must be a nonempty normalized rectangle")
        if not self.active:
            return self
        if self.kind == "prohibition":
            if len({ingredient.casefold() for ingredient in self.ingredients}) < 2:
                raise ValueError("FDC prohibitions require distinct confirmed ingredients")
            if self.all_formulations and (self.form or self.strength):
                raise ValueError("Broad FDC scope cannot specify a form or strength")
        elif not self.product:
            raise ValueError("Batch notices require a product")
        return self


class Approval(Input):
    reviewer_attests_span: Literal[True]


class Regimen(Input):
    packs: list[Pack] = Field(min_length=1, max_length=40)
    age: int | None = Field(default=None, ge=0, le=125)


class Stock(Pack):
    quantity: int = Field(default=1, ge=1, le=1_000_000)
    location: OptionalLabel = ""


class Resolution(Input):
    outcome: Literal["quarantined", "returned", "record_corrected", "escalated"]
    note: Label
