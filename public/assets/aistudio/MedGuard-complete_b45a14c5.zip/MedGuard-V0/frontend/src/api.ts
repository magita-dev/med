/* Typed API client for the additive modules. New views use this typed surface;
 * the original app shell keeps its own fetch helper. Auth is HTTP-Basic by token,
 * with an optional Bearer session token (see /api/session). */

export type ClinicalRuleReport = {
  kind: string; ingredients: string[]; jurisdiction: string | null;
  governed: boolean; missing: string[]; expired: boolean | null;
  reviewed_by: string | null; re_review_at: string; source: string | null;
};
export type ClinicalRulesResponse = {
  rules: ClinicalRuleReport[]; governed: number; total: number; not_governed: number;
};
export type PermissionsResponse = { role: string; permissions: string[] };
export type OutboxMessage = {
  id: string; tenant: string; channel: string; recipient: string; subject: string;
  body: string; review_id: string | null; status: string; attempts: number;
  last_error: string | null; created_at: string; last_attempt_at: string; delivered_at: string;
};
export type LedgerTransaction = {
  id: string; stock_id: string; tenant: string; kind: string; quantity_delta: number;
  actor: string; at: string; note: string; reported: boolean; verified: boolean;
};
export type ReconcileResponse = {
  stock_id: string; expected_quantity: number; ledger_quantity: number;
  matches_record: boolean; verified_movements: number;
  reported_unverified_movements: number; all_verified: boolean;
};
export type GroundTruthEntry = {
  doc_id: string; source: string; sha256: string; version: number; pages: number;
  kind: string; finding: string; authority: string; scope: string;
  rows: unknown[]; reviewers: unknown[];
};
export type GroundTruthResponse = { entries: GroundTruthEntry[]; disagreements: unknown[] };
export type MolecularStructure = {
  accession: string; kind: 'experimental' | 'predicted'; method: string;
  source: string; confidence: string | null;
};
export type MolecularEvidence = {
  target: string; drug: string; relationship: string; structures: MolecularStructure[];
  evidence: unknown[]; limitation: string; reviewed_by: string; reviewed_at: string | null;
};
export type MolecularHypothesis = {
  id: string; drug: string; target: string; mechanism: string; evidence: unknown[];
  status: string; tier: 'predicted'; proposed_by: string; reviewer: string; reviewed_at: string | null;
};
export type ProteinStructure = {
  kind: 'experimental' | 'predicted'; accession: string; method: string; label: string;
  source: string; confidence: string | null; trust: string;
};
export type ProteinView = {
  target: string; name: string; role: string; limitation: string; structures: ProteinStructure[];
};
export type EvidenceTier = 'verified' | 'curated' | 'predicted';

export class ApiError extends Error {}

let bearer: string | null = null;
export function setBearer(token: string | null) { bearer = token; }

export async function api<T>(path: string, init: RequestInit = {}, basic?: string): Promise<T> {
  const headers = new Headers(init.headers);
  if (bearer) headers.set('Authorization', 'Bearer ' + bearer);
  else if (basic) headers.set('Authorization', 'Basic ' + basic);
  if (typeof init.body === 'string') headers.set('Content-Type', 'application/json');
  const response = await fetch('/api' + path, { ...init, headers, cache: 'no-store' });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) throw new ApiError(typeof result.detail === 'string' ? result.detail : 'Request failed');
  return result as T;
}

export const get = <T>(path: string, basic?: string) => api<T>(path, {}, basic);
export const post = <T>(path: string, body: unknown, basic?: string) =>
  api<T>(path, { method: 'POST', body: JSON.stringify(body) }, basic);
export const put = <T>(path: string, body?: unknown, basic?: string) =>
  api<T>(path, { method: 'PUT', body: body === undefined ? undefined : JSON.stringify(body) }, basic);
