from datetime import date

import pytest

from medguard.auth import SessionStore, can, redact
from medguard.governance import ClinicalRegistry, assess_rule
from medguard.groundtruth import GroundTruthLibrary, validate_manifest
from medguard.ledger import Ledger
from medguard.molecular import MolecularCatalog
from medguard.outbox import InAppProvider, Notification, Outbox


# --------------------------- clinical governance ----------------------------
def test_governed_rule_passes_and_incomplete_rule_reports_missing():
    governed = {
        "kind": "interaction", "ingredients": ["clarithromycin", "simvastatin"],
        "severity": "contraindication", "source": "https://example/label",
        "locator": "Section 4.3", "jurisdiction": "US", "license": "DailyMed public label",
        "evidence": [{"source": "https://example/label", "locator": "4.3"}],
        "reviewed_by": "fixture pharmacist", "reviewed_at": "2025-01-01",
        "re_review_at": "2030-12-31",
    }
    report = assess_rule(governed)
    assert report["governed"] is True
    assert report["missing"] == []
    assert report["expired"] is False

    incomplete = {"kind": "interaction", "ingredients": ["a", "b"],
                   "source": "https://example/label", "locator": "4.3", "jurisdiction": "US"}
    report = assess_rule(incomplete)
    assert report["governed"] is False
    assert {"license", "evidence", "reviewed_by", "reviewed_at", "re_review_at"} <= set(report["missing"])


def test_registry_screens_and_reports_coverage():
    rule = {"kind": "geriatric", "ingredients": ["hydroxyzine hydrochloride"],
            "form": "tablet", "min_age": 65, "source": "https://example", "locator": "Geriatric Use",
            "jurisdiction": "US"}
    registry = ClinicalRegistry([rule])
    pack = {"ingredients": ["hydroxyzine hydrochloride"], "form": "tablet"}
    assert registry.screen([pack], 65) == [{**rule, "tier": "curated"}]
    assert registry.screen([pack], 64) == []
    coverage = registry.coverage({"hydroxyzine hydrochloride"})
    assert coverage["unassessed_pair_count"] == 0


# --------------------------- ground-truth library ---------------------------
def test_manifest_validation_accepts_and_rejects():
    valid = {
        "doc_id": "cdsco-2025-01", "source": "https://www.cdsco.gov.in/uploadalertsfiles/x.pdf",
        "sha256": "0" * 64, "version": 1, "pages": 4, "kind": "nsq", "finding": "quality_defect",
        "rows": [{"page": 1, "locator": "row 1", "finding": "quality_defect", "product": "Demo"}],
    }
    assert validate_manifest([valid]) == []
    assert validate_manifest([valid, valid]) and "duplicate" in validate_manifest([valid, valid])[0]
    bad = {**valid, "sha256": "nothex", "kind": "unknown"}
    assert validate_manifest([bad]) and "entry 0:" in validate_manifest([bad])[0]


def test_library_add_get_and_disagreement():
    library = GroundTruthLibrary()
    entry = {
        "doc_id": "cdsco-2025-01", "source": "https://www.cdsco.gov.in/uploadalertsfiles/x.pdf",
        "sha256": "0" * 64, "version": 1, "pages": 2, "kind": "nsq", "finding": "recall",
        "reviewers": [{"reviewer": "a", "agreed": True, "at": "2025-01-02"},
                      {"reviewer": "b", "agreed": False, "note": "scope unclear", "at": "2025-01-03"}],
    }
    library.add(entry)
    assert library.get("cdsco-2025-01", 1) is not None
    assert library.disagreements()[0]["disagreement"] is True
    with pytest.raises(ValueError):
        library.add({**entry, "sha256": "1" * 64})  # immutable version


# ------------------------------- outbox ------------------------------------
class FailingProvider:
    async def send(self, message):
        return "delivery refused"


def test_outbox_lifecycle_deliver_acknowledge():
    outbox = Outbox()
    msg = outbox.enqueue(Notification(id="n1", tenant="t", recipient="pharmacy-1",
                                      review_id="r1"))
    assert msg.status == "pending"
    import asyncio
    delivered = asyncio.run(outbox.deliver_pending("t"))
    assert delivered == 1
    assert outbox.entries("t")[0].status == "delivered"
    assert outbox.acknowledge("n1", "t").status == "acknowledged"
    assert outbox.acknowledge("n1", "other") is None


def test_outbox_retries_then_fails():
    outbox = Outbox(provider=FailingProvider(), max_attempts=2)
    outbox.enqueue(Notification(id="n2", tenant="t", recipient="x"))
    import asyncio
    asyncio.run(outbox.deliver_pending("t"))
    assert outbox.entries("t")[0].status == "retried" and outbox.entries("t")[0].attempts == 1
    asyncio.run(outbox.deliver_pending("t"))
    assert outbox.entries("t")[0].status == "failed" and outbox.entries("t")[0].last_error


# -------------------------------- ledger -----------------------------------
def test_ledger_reconciles_reported_vs_verified():
    ledger = Ledger()
    stock_id, tenant = "tenant:item", "tenant"
    ledger.append({"id": "t1", "stock_id": stock_id, "tenant": tenant, "kind": "stock_in",
                   "quantity_delta": 10, "actor": "pharmacy"})
    ledger.append({"id": "t2", "stock_id": stock_id, "tenant": tenant, "kind": "quarantine",
                   "quantity_delta": 4, "actor": "pharmacy"})
    recon = ledger.reconcile(stock_id, tenant, expected_quantity=6)
    assert recon["matches_record"] is True
    assert recon["reported_unverified_movements"] == 2 and recon["all_verified"] is False
    ledger.append({"id": "t3", "stock_id": stock_id, "tenant": tenant, "kind": "return",
                   "quantity_delta": 4, "actor": "pharmacy", "verified": True})
    recon = ledger.reconcile(stock_id, tenant, expected_quantity=10)
    assert recon["verified_movements"] == 1
    with pytest.raises(ValueError):
        ledger.append({"id": "t1", "stock_id": stock_id, "tenant": tenant, "kind": "stock_out",
                       "quantity_delta": 1, "actor": "x", "at": "2025-01-01"})


# ------------------------------- molecular ---------------------------------
def test_molecular_evidence_and_pharmacist_review():
    catalog = MolecularCatalog()
    catalog.add_evidence({
        "target": "CYP3A4", "drug": "clarithromycin", "relationship": "inhibition",
        "structures": [
            {"accession": "1TQN", "kind": "experimental", "method": "X-ray", "source": "https://rcsb.org/1TQN"},
            {"accession": "P08684", "kind": "predicted", "method": "AlphaFold",
             "source": "https://alphafold.ebi.ac.uk/P08684", "confidence": "high"},
        ],
        "evidence": [{"source": "https://dailymed", "locator": "7"}],
        "reviewed_by": "fixture", "reviewed_at": "2025-01-01",
    })
    assert len(catalog.evidence()) == 1

    proposed = catalog.propose({"id": "h1", "drug": "clarithromycin", "target": "CYP3A4",
                               "mechanism": "CYP3A4 inhibition raises statin exposure",
                               "evidence": [{"source": "https://dailymed", "locator": "7"}]})
    assert proposed["status"] == "draft"
    assert catalog.public_hypotheses() == []
    reviewed = catalog.review("h1", reviewer="pharmacist", accept=True, review_date=date(2025, 1, 2))
    assert reviewed["status"] == "pharmacist_reviewed"
    assert catalog.public_hypotheses()[0]["id"] == "h1"
    catalog.review("h1", reviewer="pharmacist", accept=False)  # reject path does not raise


def test_predicted_structure_requires_confidence():
    catalog = MolecularCatalog()
    with pytest.raises(Exception):
        catalog.add_evidence({"target": "CYP3A4", "drug": "x", "relationship": "metabolism",
                              "structures": [{"accession": "P08684", "kind": "predicted",
                                              "source": "https://x", "method": "AlphaFold"}]})


# --------------------------------- auth ------------------------------------
def test_session_tokens_and_permissions():
    store = SessionStore(b"secret-key-at-least-thirty-two-bytes-long!!")
    actor = {"user": "pharmacy", "role": "member", "tenant": "demo", "demo": True}
    token = store.issue(actor)
    assert store.verify(token)["user"] == "pharmacy"
    assert store.verify(token + "x") is None  # bad signature
    assert store.revoke(token) is True
    assert store.verify(token) is None
    assert can(actor, "save_stock") is True
    assert can(actor, "publish_notice") is False
    publisher = {**actor, "role": "publisher"}
    assert can(publisher, "publish_notice") is True


def test_redaction_masks_sensitive_values():
    raw = "Authorization: Basic dXNlcjpwYXNz token Bearer abc.def sha256=" + "a" * 64 + " batch O01-0A-998877665544"
    masked = redact(raw)
    assert "Basic ***" in masked and "Bearer ***" in masked and "<sha256>" in masked
    assert "dXNlcjpwYXNz" not in masked and "a" * 64 not in masked
