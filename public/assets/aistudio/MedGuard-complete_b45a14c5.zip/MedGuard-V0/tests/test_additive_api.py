"""Integration tests for the additive modules wired into the API."""
from uuid import uuid4

import pytest
from fastapi.testclient import TestClient

from medguard.api import PASSWORDS, create_app
from medguard.store import Memory

PACK = {"product": "Demo 10 mg", "manufacturer": "Example Labs", "batch": "001-A",
        "quantity": 10, "location": "Shelf A", "confirmed": True}


@pytest.fixture
def client(tmp_path):
    hashed = PASSWORDS.hash("test-password")
    accounts = {
        "member": {"hash": hashed, "tenant": "one", "role": "member"},
        "publisher": {"hash": hashed, "tenant": "one", "role": "publisher"},
        "pharmacist": {"hash": hashed, "tenant": "one", "role": "publisher"},
    }
    with TestClient(create_app(Memory(), accounts, tmp_path)) as c:
        yield c


def auth(user="member"):
    return user, "test-password"


def bearer(token):
    return {"Authorization": "Bearer " + token}


def test_session_token_round_trip(client):
    response = client.post("/api/session", auth=auth())
    assert response.status_code == 200
    token = response.json()["token"]
    assert client.get("/api/me", headers=bearer(token)).status_code == 200
    assert client.get("/api/me", headers=bearer(token + "tampered")).status_code == 401


def test_permissions_reflect_role(client):
    member = client.get("/api/permissions", auth=auth()).json()
    publisher = client.get("/api/permissions", auth=auth("publisher")).json()
    assert "publish_notice" not in member["permissions"]
    assert "publish_notice" in publisher["permissions"]


def test_clinical_governance_report(client):
    report = client.get("/api/clinical/rules", auth=auth()).json()
    assert report["total"] == report["governed"] + report["not_governed"]
    assert isinstance(report["rules"], list)


def test_source_status_reports_skipped_documents(client):
    response = client.get("/api/source-status", auth=auth("publisher"))
    assert response.status_code == 200
    assert "skipped_documents" in response.json()


def test_ground_truth_add_list_and_validate(client):
    entry = {"doc_id": "g1", "source": "https://www.cdsco.gov.in/uploadalertsfiles/x.pdf",
             "sha256": "0" * 64, "version": 1, "pages": 1, "kind": "nsq",
             "finding": "quality_defect"}
    assert client.post("/api/ground-truth", auth=auth("publisher"), json=entry).status_code == 200
    assert client.post("/api/ground-truth", auth=auth("publisher"),
                       json={"doc_id": "bad", "source": "https://evil.example/x.pdf"}).status_code == 422
    listed = client.get("/api/ground-truth", auth=auth()).json()
    assert listed["entries"][0]["doc_id"] == "g1"


def test_outbox_lifecycle(client):
    payload = {"id": "n1", "recipient": "pharmacy-1", "review_id": "r1"}
    msg = client.post("/api/outbox", auth=auth("publisher"), json=payload).json()
    assert msg["status"] == "pending"
    assert client.post("/api/outbox/deliver", auth=auth()).json()["delivered"] == 1
    assert client.get("/api/outbox", auth=auth()).json()[0]["status"] == "delivered"
    assert client.put("/api/outbox/n1/ack", auth=auth()).json()["status"] == "acknowledged"
    # re-acknowledging the same notification is idempotent within the tenant
    assert client.put("/api/outbox/n1/ack", auth=auth("publisher")).json()["status"] == "acknowledged"


def test_inventory_ledger_movements_and_reconcile(client):
    item_id = str(uuid4())
    assert client.put(f"/api/stock/{item_id}", auth=auth(), json=PACK).status_code == 200
    movement = {"id": "m1", "kind": "quarantine", "quantity_delta": 4, "note": "hold"}
    assert client.post(f"/api/stock/{item_id}/movements", auth=auth(), json=movement).status_code == 200
    txns = client.get(f"/api/stock/{item_id}/transactions", auth=auth()).json()
    assert txns[0]["kind"] == "quarantine"
    recon = client.get(f"/api/stock/{item_id}/reconcile", auth=auth()).json()
    assert recon["expected_quantity"] == 10 and recon["ledger_quantity"] == -4
    assert recon["reported_unverified_movements"] == 1


def test_molecular_hypothesis_pharmacist_review(client):
    evidence = {"target": "CYP3A4", "drug": "clarithromycin", "relationship": "inhibition",
                "structures": [{"accession": "1TQN", "kind": "experimental",
                                 "method": "X-ray", "source": "https://rcsb.org/1TQN"}],
                "evidence": [{"source": "https://dailymed", "locator": "7"}],
                "reviewed_by": "fixture", "reviewed_at": "2025-01-01"}
    assert client.post("/api/molecular/evidence", auth=auth("publisher"), json=evidence).status_code == 200
    hypothesis = {"id": "h1", "drug": "clarithromycin", "target": "CYP3A4",
                  "mechanism": "CYP3A4 inhibition raises statin exposure"}
    proposed = client.post("/api/molecular/hypotheses", auth=auth("publisher"), json=hypothesis).json()
    assert proposed["tier"] == "predicted" and proposed["proposed_by"] == "publisher"
    # Patients/households never see hypotheses, drafted or reviewed.
    assert client.get("/api/molecular/hypotheses", auth=auth()).status_code == 403
    assert client.get("/api/molecular/queue", auth=auth()).status_code == 403
    assert client.get("/api/molecular/hypotheses", auth=auth("pharmacist")).json() == []  # not yet reviewed
    assert client.get("/api/molecular/queue", auth=auth("pharmacist")).json()[0]["status"] == "draft"
    # The proposer cannot review their own hypothesis; a member cannot review at all.
    assert client.put("/api/molecular/hypotheses/h1/review", auth=auth("publisher"),
                      json={"accept": True}).status_code == 403
    assert client.put("/api/molecular/hypotheses/h1/review", auth=auth(),
                      json={"accept": True}).status_code == 403
    reviewed = client.put("/api/molecular/hypotheses/h1/review", auth=auth("pharmacist"),
                          json={"accept": True}).json()
    assert reviewed["status"] == "pharmacist_reviewed"
    assert client.get("/api/molecular/hypotheses", auth=auth("pharmacist")).json()[0]["id"] == "h1"
    assert client.get("/api/molecular/hypotheses", auth=auth()).status_code == 403


def test_hypothesis_cannot_claim_a_verified_tier(client):
    bad = {"id": "h2", "drug": "x", "target": "CYP3A4", "mechanism": "m", "tier": "verified"}
    # The API forces tier=predicted; the model itself also rejects anything else.
    assert client.post("/api/molecular/hypotheses", auth=auth("publisher"), json=bad).json()["tier"] == "predicted"


def test_protein_library_has_provenance_labels(client):
    proteins = client.get("/api/molecular/proteins", auth=auth()).json()
    assert [p["target"] for p in proteins] == ["CYP3A4", "CYP2D6", "hERG", "P-gp"]
    for protein in proteins:
        kinds = {s["kind"]: s["label"] for s in protein["structures"]}
        assert kinds["experimental"].startswith("Experimental (PDB ")
        assert kinds["predicted"].startswith("AlphaFold-predicted (")
    assert client.get("/api/molecular/proteins/p-gp", auth=auth()).json()["target"] == "P-gp"
    assert client.get("/api/molecular/proteins/unknown", auth=auth()).status_code == 404


def test_regimen_findings_carry_tier_and_why_link(client):
    packs = [{"product": "A", "manufacturer": "m", "batch": "1", "ingredients": ["clarithromycin"],
              "form": "tablet", "strength": "250", "confirmed": True},
             {"product": "B", "manufacturer": "m", "batch": "2", "ingredients": ["simvastatin"],
              "form": "tablet", "strength": "20", "confirmed": True}]
    findings = client.post("/api/regimen", auth=auth(), json={"packs": packs, "age": 70}).json()["findings"]
    interaction = next(f for f in findings if f["kind"] == "interaction")
    assert interaction["tier"] == "curated"
    assert interaction["mechanism"]["targets"] == ["CYP3A4"]


def test_check_reports_not_found_as_of_today(client):
    from datetime import date
    pack = {"product": "Nothing Listed 5 mg", "manufacturer": "None", "batch": "X1", "confirmed": True}
    body = client.post("/api/check", auth=auth(), json=pack).json()
    assert body["matches"] == [] and body["not_found_as_of"] == date.today().isoformat()
