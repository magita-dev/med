import { useEffect, useState } from 'react';
import { get, type ClinicalRulesResponse } from './api';

export function ClinicalRules({ token }: { token: string }) {
  const [report, setReport] = useState<ClinicalRulesResponse>();
  const [error, setError] = useState('');

  async function load() {
    setError('');
    try { setReport(await get<ClinicalRulesResponse>('/clinical/rules', token)); }
    catch (e) { setError(e instanceof Error ? e.message : 'Failed to load rules'); }
  }
  useEffect(() => { void load(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, []);

  return <section aria-labelledby="clinical-governance">
    <h2 id="clinical-governance" className="font-semibold text-lg">Clinical rule governance</h2>
    <p className="text-sm text-emerald-900 mt-1 mb-4">
      Each curated rule is checked for a licence, evidence citation, applicability, qualified
      sign-off and a scheduled re-review date. A rule without these is reported, not used to
      claim broad coverage.
    </p>
    <button className="secondary mb-4" onClick={load}>Refresh</button>
    {error && <p role="alert" className="text-red-900 bg-red-50 rounded-lg p-3 mb-3">{error}</p>}
    {report && <>
      <div className="grid grid-cols-3 gap-3 mb-4 max-w-md text-center">
        <div className="rounded-lg border border-emerald-100 bg-emerald-50 p-3">
          <p className="text-2xl font-bold">{report.governed}</p><p className="text-sm">Governed</p></div>
        <div className="rounded-lg border border-amber-100 bg-amber-50 p-3">
          <p className="text-2xl font-bold">{report.not_governed}</p><p className="text-sm">Missing fields</p></div>
        <div className="rounded-lg border border-emerald-100 bg-white p-3">
          <p className="text-2xl font-bold">{report.total}</p><p className="text-sm">Total</p></div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-sm">
          <thead><tr className="bg-emerald-50">
            {['Ingredients', 'Kind', 'Jurisdiction', 'Governed', 'Re-review', 'Source'].map(h =>
              <th key={h} scope="col" className="p-3">{h}</th>)}
          </tr></thead>
          <tbody>{report.rules.map((rule, i) => <tr key={i} className="border-b border-emerald-100 align-top">
            <td className="p-3">{rule.ingredients.join(' + ')}</td>
            <td className="p-3">{rule.kind}</td>
            <td className="p-3">{rule.jurisdiction ?? '—'}</td>
            <td className="p-3">{rule.governed
              ? <span className="text-emerald-800">Yes{rule.expired ? ' · expired' : ''}</span>
              : <span className="text-amber-800" title={rule.missing.join(', ')}>Missing {rule.missing.length}</span>}</td>
            <td className="p-3">{rule.re_review_at || '—'}</td>
            <td className="p-3 break-all">{rule.source
              ? <a href={rule.source} target="_blank" rel="noreferrer">Source ↗</a> : '—'}</td>
          </tr>)}</tbody>
        </table>
      </div>
      <p className="text-xs text-emerald-900 mt-3">Educational only. Not a clinical decision tool and not a comprehensive interaction database.</p>
    </>}
  </section>;
}
