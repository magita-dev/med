import { useState } from 'react';
import { post, type EvidenceTier, type Mechanism } from './api';
import { TierBadge, WhyPanel } from './ProteinViewer';

type Lang = 'en' | 'ta';
type Item = { raw: string; drug: string; form: string; strength_value: number | null; strength_unit: string | null;
  frequency: string | null; slots: number[]; as_needed: boolean; units_per_day: number | null;
  modifiers: string[]; duration_days: number | null };
type Check = { outcome: string; reason?: string; daily_mg?: number; max_daily_mg?: number;
  rule?: { source: string; locator: string; synthetic?: boolean } };
type Row = Item & { instruction: Record<Lang, string>; dose: Check; indication: Check };
type Finding = { kind: string; ingredients: string[]; tier: EvidenceTier; message?: Record<string, string>;
  mechanism?: Mechanism };
type Result = { outcome: 'issues_found' | 'nothing_found'; summary: Record<Lang, string>; as_of: string;
  checks_ran: number; checks_not_run: number; items: Row[]; findings: Finding[] };

const T = {
  en: { title: 'Prescription review', lines: 'Prescription lines (one medicine per line, generic names)',
    cond: 'Condition you were prescribed for (optional)', age: 'Age in years (optional)', parse: 'Read lines',
    photo: 'Or scan a prescription photo', confirm: 'I checked these against my prescription',
    review: 'Review prescription', translated: 'In plain language', dose: 'Dose check', ind: 'Condition match',
    none: 'No lines could be read. Use the form: Tab Name 500 mg 1-0-1 x 5 days.', speak: 'Read aloud',
    unparsed: 'Could not read these lines', ocr503: 'Photo reading is not set up here. Type the lines instead.',
    outcome: { exceeds_cited_maximum: 'Above the cited daily maximum', at_or_below_cited_maximum: 'At or below the cited daily maximum',
      listed_in_cited_label: 'Use is listed in the cited label', not_listed_in_cited_label: 'Use not listed in the cited label. This is not necessarily wrong: ask your doctor.',
      unassessed: 'Not assessed: no reviewed rule or missing detail' } as Record<string, string>,
    synthetic: 'Synthetic demo rule' },
  ta: { title: 'மருந்துச்சீட்டு மதிப்பாய்வு', lines: 'மருந்துச்சீட்டு வரிகள் (ஒரு வரிக்கு ஒரு மருந்து, generic பெயர்)',
    cond: 'எந்த நோய்க்காக மருந்து தரப்பட்டது (விருப்பம்)', age: 'வயது (விருப்பம்)', parse: 'வரிகளைப் படிக்கவும்',
    photo: 'அல்லது மருந்துச்சீட்டுப் படத்தை ஸ்கேன் செய்யவும்', confirm: 'இவற்றை என் மருந்துச்சீட்டுடன் சரிபார்த்தேன்',
    review: 'மதிப்பாய்வு செய்', translated: 'எளிய மொழியில்', dose: 'அளவு சோதனை', ind: 'நோய் பொருத்தம்',
    none: 'வரிகளைப் படிக்க இயலவில்லை. வடிவம்: Tab Name 500 mg 1-0-1 x 5 days.', speak: 'படித்துக் காட்டு',
    unparsed: 'இந்த வரிகளைப் படிக்க இயலவில்லை', ocr503: 'இங்கு படம் படிக்கும் வசதி அமைக்கப்படவில்லை. வரிகளைத் தட்டச்சு செய்யவும்.',
    outcome: { exceeds_cited_maximum: 'குறிப்பிடப்பட்ட தினசரி அதிகபட்சத்தை மீறுகிறது', at_or_below_cited_maximum: 'குறிப்பிடப்பட்ட தினசரி அதிகபட்சத்திற்குள் உள்ளது',
      listed_in_cited_label: 'குறிப்பிட்ட மருந்துத் தகவலில் இந்தப் பயன்பாடு உள்ளது', not_listed_in_cited_label: 'குறிப்பிட்ட மருந்துத் தகவலில் இந்தப் பயன்பாடு இல்லை. இது தவறு என்று அர்த்தமல்ல: மருத்துவரிடம் கேளுங்கள்.',
      unassessed: 'மதிப்பிடப்படவில்லை: மதிப்பாய்வு செய்யப்பட்ட விதி இல்லை அல்லது விவரம் இல்லை' } as Record<string, string>,
    synthetic: 'செயற்கை டெமோ விதி' },
};

function speak(language: Lang, text: string) {
  const voices = 'speechSynthesis' in window ? window.speechSynthesis.getVoices() : [];
  const match = voices.filter(v => v.lang.toLowerCase().startsWith(language));
  let voice = match.find(v => v.localService);
  if (!voice && match.length) {
    const ask = language === 'ta' ? 'இந்தக் குரல் உரையை உலாவி நிறுவனத்தின் சேவைக்கு அனுப்பலாம். தொடரலாமா?'
      : 'This voice may send the text to your browser vendor. Continue?';
    if (!window.confirm(ask)) return;
    voice = match[0];
  }
  if (!voice) { window.alert(language === 'ta' ? 'இந்த மொழிக்கான குரல் கிடைக்கவில்லை.' : 'No installed voice for this language.'); return; }
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.voice = voice; utterance.lang = voice.lang;
  window.speechSynthesis.cancel(); window.speechSynthesis.speak(utterance);
}

export function Prescription({ token }: { token: string }) {
  const [lang, setLang] = useState<Lang>('en');
  const [text, setText] = useState('');
  const [condition, setCondition] = useState('');
  const [age, setAge] = useState('');
  const [items, setItems] = useState<Item[]>([]);
  const [unparsed, setUnparsed] = useState<string[]>([]);
  const [confirmed, setConfirmed] = useState(false);
  const [result, setResult] = useState<Result>();
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const t = T[lang];

  async function run(action: () => Promise<void>) {
    setBusy(true); setError('');
    try { await action(); } catch (e) { setError(e instanceof Error ? e.message : 'Request failed'); }
    finally { setBusy(false); }
  }
  const parse = () => run(async () => {
    setResult(undefined); setConfirmed(false);
    const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
    const out = await post<{ proposals: Item[]; unparsed: string[] }>('/prescription/parse', { lines }, token);
    setItems(out.proposals); setUnparsed(out.unparsed);
  });
  const scan = (file: File) => run(async () => {
    const body = new FormData(); body.append('file', file);
    const response = await fetch('/api/ocr?language=en', { method: 'POST', body,
      headers: { Authorization: 'Basic ' + token } });
    const out = await response.json().catch(() => ({}));
    if (response.status === 503) throw new Error(t.ocr503);
    if (!response.ok) throw new Error(typeof out.detail === 'string' ? out.detail : 'Image recognition failed');
    setText((out.lines as { text: string }[]).map(l => l.text).join('\n'));
  });
  const edit = (index: number, patch: Partial<Item>) => {
    setItems(list => list.map((item, i) => i === index ? { ...item, ...patch } : item));
    setResult(undefined); setConfirmed(false);
  };
  const review = () => run(async () => {
    setResult(await post<Result>('/prescription/review', {
      items: items.map(item => ({ ...item, confirmed: true })),
      condition: condition || null, age: age ? Number(age) : null }, token));
  });

  return <section aria-labelledby="rx-title" lang={lang} className="grid gap-4">
    <div className="flex items-center gap-3">
      <h2 id="rx-title" className="text-xl font-bold">{t.title}</h2>
      <select aria-label="Explanation language" value={lang} onChange={e => setLang(e.target.value === 'ta' ? 'ta' : 'en')}>
        <option value="en">English</option><option value="ta">தமிழ்</option></select>
    </div>
    <label>{t.photo}<input type="file" accept="image/*" disabled={busy}
      onChange={e => e.target.files?.[0] && void scan(e.target.files[0])} /></label>
    <label>{t.lines}<textarea rows={5} value={text} onChange={e => setText(e.target.value)}
      placeholder="Tab Clarithromycin 250 mg BD&#10;Tab Simvastatin 20 mg HS" /></label>
    <div className="grid gap-3 sm:grid-cols-2">
      <label>{t.cond}<input value={condition} maxLength={200} onChange={e => setCondition(e.target.value)} /></label>
      <label>{t.age}<input type="number" min={0} max={125} value={age} onChange={e => setAge(e.target.value)} /></label>
    </div>
    <div><button disabled={busy || !text.trim()} onClick={() => void parse()}>{t.parse}</button></div>
    {error && <p role="alert">{error}</p>}
    {unparsed.length > 0 && <p className="text-sm">{t.unparsed}: {unparsed.join(' | ')}</p>}
    {!items.length && unparsed.length > 0 && <p>{t.none}</p>}

    {items.length > 0 && <div className="grid gap-3">
      <table className="text-sm"><thead><tr><th>Medicine (generic)</th><th>Strength</th><th>Units per day</th><th>Days</th></tr></thead>
        <tbody>{items.map((item, i) => <tr key={i}>
          <td><input aria-label="Medicine" value={item.drug} onChange={e => edit(i, { drug: e.target.value.toLowerCase() })} /></td>
          <td>{item.strength_value ?? '—'} {item.strength_unit ?? ''}</td>
          <td><input aria-label="Units per day" type="number" min={0} step="0.5" value={item.units_per_day ?? ''}
            onChange={e => edit(i, { units_per_day: e.target.value ? Number(e.target.value) : null })} /></td>
          <td>{item.duration_days ?? '—'}</td></tr>)}</tbody></table>
      <label className="flex gap-2 items-center"><input type="checkbox" checked={confirmed}
        onChange={e => setConfirmed(e.target.checked)} />{t.confirm}</label>
      <div><button disabled={busy || !confirmed} onClick={() => void review()}>{t.review}</button></div>
    </div>}

    {result && <div className="bg-emerald-50 rounded-lg p-4 grid gap-3" aria-label="Prescription result">
      <p className="font-semibold">{result.summary[lang]}</p>
      <h3 className="font-semibold">{t.translated}</h3>
      <ul className="list-disc ml-5">{result.items.map((row, i) => <li key={i}>{row.instruction[lang]}</li>)}</ul>
      {result.items.map((row, i) => <article key={i} className="border-t border-emerald-200 pt-2 text-sm">
        <p className="font-semibold">{row.drug}</p>
        {[[t.dose, row.dose], [t.ind, row.indication]].map(([label, check]) => <p key={label as string}>
          <strong>{label as string}:</strong> {t.outcome[(check as Check).outcome]}
          {(check as Check).daily_mg !== undefined && ` (${(check as Check).daily_mg} mg/day; cited max ${(check as Check).max_daily_mg} mg/day)`}
          {(check as Check).rule && <>{' '}<span lang="en" className="opacity-80">· {(check as Check).rule?.synthetic ? t.synthetic : (check as Check).rule?.locator}</span></>}
        </p>)}
      </article>)}
      {result.findings.map((f, i) => <article key={i} className="border-t border-emerald-200 pt-2">
        <p><TierBadge tier={f.tier} />{f.ingredients.join(' + ')} · {f.message?.[lang] ?? ''}</p>
        {f.mechanism && <WhyPanel mechanism={f.mechanism} token={token} language={lang} />}
      </article>)}
      <div><button className="secondary" onClick={() => speak(lang, [result.summary[lang],
        ...result.items.map(r => r.instruction[lang])].join('. '))}>{t.speak}</button></div>
    </div>}
  </section>;
}
