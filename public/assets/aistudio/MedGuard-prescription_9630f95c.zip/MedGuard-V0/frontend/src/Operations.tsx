import { useEffect, useState } from 'react';
import type { FormEvent } from 'react';
import { get, post, put, setBearer,
  type OutboxMessage, type LedgerTransaction, type ReconcileResponse,
  type PermissionsResponse } from './api';

type Actor = { user: string; role: string; tenant: string; demo: boolean };
type StockItem = { id: string; product: string; batch: string; quantity: number; location: string };

export function Operations({ token, actor }: { token: string; actor: Actor }) {
  const isPublisher = actor.role === 'publisher';
  const [error, setError] = useState('');
  const [status, setStatus] = useState('');

  // identity / session
  const [perms, setPerms] = useState<PermissionsResponse>();
  const [sessionToken, setSessionToken] = useState('');

  // outbox
  const [outbox, setOutbox] = useState<OutboxMessage[]>([]);

  // ledger
  const [stock, setStock] = useState<StockItem[]>([]);
  const [selectedStock, setSelectedStock] = useState('');
  const [txns, setTxns] = useState<LedgerTransaction[]>([]);
  const [recon, setRecon] = useState<ReconcileResponse>();

  async function loadPerms() {
    try { setPerms(await get<PermissionsResponse>('/permissions', token)); }
    catch (e) { setError(e instanceof Error ? e.message : 'Failed'); }
  }
  async function loadOutbox() {
    try { setOutbox(await get<OutboxMessage[]>('/outbox', token)); }
    catch (e) { setError(e instanceof Error ? e.message : 'Failed'); }
  }
  async function loadStock() {
    try { setStock(await get<StockItem[]>('/stock', token)); }
    catch (e) { setError(e instanceof Error ? e.message : 'Failed'); }
  }
  async function loadLedger(id: string) {
    setSelectedStock(id);
    setTxns([]); setRecon(undefined);
    if (!id) return;
    try {
      const [t, r] = await Promise.all([
        get<LedgerTransaction[]>(`/stock/${encodeURIComponent(id)}/transactions`, token),
        get<ReconcileResponse>(`/stock/${encodeURIComponent(id)}/reconcile`, token),
      ]);
      setTxns(t); setRecon(r);
    } catch (e) { setError(e instanceof Error ? e.message : 'Failed'); }
  }

  useEffect(() => { void loadPerms(); void loadOutbox(); void loadStock(); /* eslint-disable-next-line */ }, []);

  async function issueSession() {
    setError('');
    try { const { token: t } = await post<{ token: string }>('/session', {}, token); setSessionToken(t); }
    catch (e) { setError(e instanceof Error ? e.message : 'Failed'); }
  }

  async function enqueueOutbox(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const id = String(data.get('id') || crypto.randomUUID());
    try {
      await post<OutboxMessage>('/outbox', {
        id, recipient: String(data.get('recipient') || ''), subject: String(data.get('subject') || ''),
        body: String(data.get('body') || ''), review_id: String(data.get('review_id') || '') || null,
      }, token);
      setStatus('Notification queued.');
      await loadOutbox();
    } catch (e) { setError(e instanceof Error ? e.message : 'Failed'); }
  }

  async function deliver() {
    try { const r = await post<{ delivered: number }>('/outbox/deliver', {}, token); setStatus(`${r.delivered} delivered.`); await loadOutbox(); }
    catch (e) { setError(e instanceof Error ? e.message : 'Failed'); }
  }
  async function ack(id: string) {
    try { await put<OutboxMessage>(`/outbox/${encodeURIComponent(id)}/ack`, {}, token); await loadOutbox(); }
    catch (e) { setError(e instanceof Error ? e.message : 'Failed'); }
  }

  async function recordMovement(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!selectedStock) return;
    const data = new FormData(event.currentTarget);
    try {
      await post<LedgerTransaction>(`/stock/${encodeURIComponent(selectedStock)}/movements`, {
        id: crypto.randomUUID(), kind: String(data.get('kind')),
        quantity_delta: Number(data.get('quantity_delta')) || 0,
        note: String(data.get('note') || ''), verified: data.get('verified') === 'on',
      }, token);
      setStatus('Movement recorded.');
      await loadLedger(selectedStock);
    } catch (e) { setError(e instanceof Error ? e.message : 'Failed'); }
  }

  return <section aria-labelledby="operations" className="space-y-8">
    <h2 id="operations" className="font-semibold text-lg">Operations</h2>
    {error && <p role="alert" className="text-red-900 bg-red-50 rounded-lg p-3">{error}</p>}
    {status && <p aria-live="polite" className="text-sm text-emerald-900">{status}</p>}

    <div className="rounded-xl border border-emerald-100 bg-emerald-50 p-4">
      <h3 className="font-semibold">Identity and permissions</h3>
      <p className="text-sm mt-1">Signed in as <strong>{actor.user}</strong> · role <strong>{actor.role}</strong> · tenant <strong>{actor.tenant}</strong></p>
      {perms && <p className="text-sm mt-1">Permissions: {perms.permissions.join(', ')}</p>}
      <div className="flex flex-wrap items-center gap-3 mt-3">
        <button className="secondary" onClick={issueSession}>Issue a session token</button>
        {sessionToken && <>
          <code className="text-xs break-all bg-white px-2 py-1 rounded border border-emerald-100">{sessionToken.slice(0, 16)}…</code>
          <button className="secondary" onClick={() => { setBearer(sessionToken); setStatus('Session token active for new API calls.'); }}>Use token</button>
        </>}
      </div>
      <p className="text-xs text-emerald-900 mt-2">An opaque HMAC session token lets a client avoid resending credentials. A production deployment would use OIDC.</p>
    </div>

    <div className="rounded-xl border border-emerald-100 bg-white p-4">
      <h3 className="font-semibold">Notification outbox</h3>
      <p className="text-sm text-emerald-900 mt-1 mb-3">Durable notifications with pending → delivered → acknowledged states. Acknowledgement is a UI action, not proof of physical recall.</p>
      <button className="secondary mb-3" onClick={deliver}>Deliver pending</button>
      {outbox.length === 0 ? <p>No notifications.</p> : <ul className="text-sm space-y-1">
        {outbox.map(m => <li key={m.id} className="flex flex-wrap items-center gap-3 border-b border-emerald-50 py-2">
          <span className="font-medium">{m.recipient}</span>
          <span className="px-2 py-0.5 rounded bg-emerald-50 text-emerald-800">{m.status}</span>
          <span className="text-xs text-emerald-900">attempts {m.attempts}{m.last_error ? ' · ' + m.last_error : ''}</span>
          {m.status === 'delivered' && <button className="secondary" onClick={() => ack(m.id)}>Acknowledge</button>}
        </li>)}
      </ul>}
      {isPublisher && <form className="grid gap-3 max-w-md mt-4" onSubmit={enqueueOutbox}>
        <h4 className="font-semibold text-sm">Queue a notification</h4>
        <label>Recipient <input name="recipient" required maxLength={200} /></label>
        <label>Subject <input name="subject" maxLength={200} /></label>
        <label>Body <textarea name="body" rows={2} maxLength={2000} /></label>
        <label>Review id (optional) <input name="review_id" maxLength={200} /></label>
        <button>Queue</button>
      </form>}
    </div>

    <div className="rounded-xl border border-emerald-100 bg-white p-4">
      <h3 className="font-semibold">Inventory transaction ledger</h3>
      <label className="block max-w-sm mt-2">Select stock item
        <select value={selectedStock} onChange={e => void loadLedger(e.target.value)}>
          <option value="">—</option>
          {stock.map(item => <option key={item.id} value={item.id}>{item.product} · {item.batch || 'Unknown'}</option>)}
        </select>
      </label>
      {recon && <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 max-w-2xl text-sm">
        <div className="rounded border border-emerald-100 p-3"><p className="font-semibold">Expected</p><p>{recon.expected_quantity}</p></div>
        <div className="rounded border border-emerald-100 p-3"><p className="font-semibold">Ledger</p><p>{recon.ledger_quantity}</p></div>
        <div className="rounded border border-emerald-100 p-3"><p className="font-semibold">Matches record</p><p>{recon.matches_record ? 'Yes' : 'No'}</p></div>
        <div className="rounded border border-emerald-100 p-3"><p className="font-semibold">Unverified moves</p><p>{recon.reported_unverified_movements}</p></div>
      </div>}
      {txns.length > 0 && <table className="w-full text-left border-collapse text-sm mt-4">
        <thead><tr className="bg-emerald-50">{['Kind', 'Δ', 'Actor', 'At', 'Verified', 'Note'].map(h =>
          <th key={h} scope="col" className="p-3">{h}</th>)}</tr></thead>
        <tbody>{txns.map(t => <tr key={t.id} className="border-b border-emerald-100">
          <td className="p-3">{t.kind.replaceAll('_', ' ')}</td>
          <td className="p-3">{t.quantity_delta}</td>
          <td className="p-3">{t.actor}</td>
          <td className="p-3">{t.at.slice(0, 19).replace('T', ' ')}</td>
          <td className="p-3">{t.verified ? 'Yes' : 'No'}</td>
          <td className="p-3">{t.note}</td>
        </tr>)}</tbody>
      </table>}
      {selectedStock && <form className="grid gap-3 max-w-md mt-4" onSubmit={recordMovement}>
        <h4 className="font-semibold text-sm">Record a stock movement</h4>
        <label>Action
          <select name="kind" required>
            <option value="stock_in">Stock in</option><option value="stock_out">Stock out</option>
            <option value="quarantine">Quarantine</option><option value="return">Return</option>
            <option value="record_correction">Record correction</option>
          </select>
        </label>
        <label>Quantity change <input name="quantity_delta" type="number" defaultValue={0} /></label>
        <label>Note <input name="note" maxLength={200} /></label>
        <label className="flex items-center gap-2"><input type="checkbox" name="verified" /> Independently verified (physical movement confirmed)</label>
        <button>Record movement</button>
      </form>}
    </div>
  </section>;
}
