import { useEffect, useState } from 'react';

export type OcrLine = { text: string; confidence: number; polygon?: number[][] };

export function ScanPreview({ file, lines, activeLine }: { file: File; lines: OcrLine[]; activeLine?: number }) {
  const [url, setUrl] = useState('');
  const [image, setImage] = useState({ width: 0, height: 0 });
  const [selected, setSelected] = useState<number>();
  const [zoom, setZoom] = useState(false);
  const highlighted = activeLine ?? selected;
  useEffect(() => {
    const next = URL.createObjectURL(file);
    setUrl(next);
    setImage({ width: 0, height: 0 });
    setSelected(undefined);
    setZoom(false);
    return () => URL.revokeObjectURL(next);
  }, [file]);

  return <div className="scan-grid">
    <div className="min-w-0">
    <button type="button" className="secondary mb-2" aria-pressed={zoom} onClick={() => setZoom(!zoom)}>
      {zoom ? 'Fit image' : 'Zoom image'}
    </button>
    <div className="overflow-auto max-h-[32rem]" tabIndex={zoom ? 0 : undefined} aria-label="Medicine image preview">
    <div className="scan-image" style={zoom ? { width: '200%', maxWidth: 'none' } : undefined}>
      {url && <img src={url} style={zoom ? { width: '100%', maxHeight: 'none' } : undefined}
        alt="Uploaded medicine image for manual verification" onLoad={event =>
        setImage({ width: event.currentTarget.naturalWidth, height: event.currentTarget.naturalHeight })} />}
      {image.width > 0 && lines.length > 0 && <svg className="scan-overlay" aria-hidden="true"
        viewBox={`0 0 ${image.width} ${image.height}`}>
        {lines.map((line, index) => line.polygon && <polygon key={index}
          points={line.polygon.map(pair => pair.join(',')).join(' ')}
          className={highlighted === index ? 'selected' : ''} />)}
      </svg>}
    </div>
    </div>
    </div>
    {lines.length > 0 && <div>
      <h3 className="font-semibold">Unconfirmed OCR</h3>
      <ul className="scan-lines">{lines.map((line, index) => <li key={index}>
        <button type="button" aria-pressed={highlighted === index} onClick={() =>
          setSelected(selected === index ? undefined : index)}>
          <span>{line.text}</span><span>{Math.round(line.confidence * 100)}%</span>
        </button>
      </li>)}</ul>
    </div>}
  </div>;
}
