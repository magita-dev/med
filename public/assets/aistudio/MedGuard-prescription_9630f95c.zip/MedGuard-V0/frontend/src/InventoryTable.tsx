import { useState } from 'react';

type Item = { id: string; product: string; batch: string; quantity: number; location: string };

export function InventoryTable({ stock }: { stock: Item[] }) {
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState<'product' | 'batch' | 'location' | 'quantity'>('product');
  const [page, setPage] = useState(0);
  const query = search.trim().toLocaleLowerCase();
  const rows = stock.filter(item => [item.product, item.batch, item.location].some(
    value => value.toLocaleLowerCase().includes(query))).sort((first, second) =>
    sort === 'quantity' ? first.quantity - second.quantity : first[sort].localeCompare(second[sort]));
  const lastPage = Math.max(0, Math.ceil(rows.length / 20) - 1);
  const current = Math.min(page, lastPage);
  return <section aria-labelledby="recorded-stock">
    <h2 id="recorded-stock" className="font-semibold text-lg">Recorded stock</h2>
    {stock.length > 0 && <label className="block max-w-sm my-3">Search product, batch or location
      <input type="search" value={search} onChange={event => { setSearch(event.target.value); setPage(0); }} />
    </label>}
    {stock.length > 0 && <label className="block max-w-sm my-3">Sort stock
      <select value={sort} onChange={event => {
        setSort(event.target.value as typeof sort);
        setPage(0);
      }}>
        <option value="product">Product</option><option value="batch">Batch</option>
        <option value="quantity">Quantity</option><option value="location">Location</option>
      </select>
    </label>}
    {rows.length ? <div className="overflow-x-auto">
      <table className="w-full text-left border-collapse text-sm">
        <thead><tr className="bg-emerald-50">
          {['Product', 'Batch', 'Quantity', 'Location'].map(title =>
            <th key={title} scope="col" className="p-3">{title}</th>)}
        </tr></thead>
        <tbody>{rows.slice(current * 20, current * 20 + 20).map(item => <tr key={item.id} className="border-b border-emerald-100">
          <th scope="row" className="p-3 font-medium">{item.product}</th>
          <td className="p-3">{item.batch || 'Unknown'}</td>
          <td className="p-3">{item.quantity}</td>
          <td className="p-3">{item.location || 'Unspecified'}</td>
        </tr>)}</tbody>
      </table>
      {lastPage > 0 && <nav aria-label="Stock table pages" className="flex items-center gap-2 py-3">
        <button className="secondary" disabled={current === 0} onClick={() => setPage(current - 1)}>Previous</button>
        <span role="status">Page {current + 1} of {lastPage + 1}</span>
        <button className="secondary" disabled={current === lastPage} onClick={() => setPage(current + 1)}>Next</button>
      </nav>}
    </div> : <p role="status">{stock.length ? 'No stock matches your search.' : 'No stock recorded.'}</p>}
  </section>;
}
