import { useEffect, useState } from 'react';
import { get, type EvidenceTier, type Mechanism, type ProteinView } from './api';

export const TIERS: Record<EvidenceTier, { name: string; meaning: string; style: string }> = {
  verified: { name: 'Verified', meaning: 'Regulator alert from an official source.', style: 'bg-emerald-700 text-white' },
  curated: { name: 'Curated', meaning: 'Reviewed label or interaction-database rule.', style: 'bg-sky-700 text-white' },
  predicted: { name: 'Predicted', meaning: 'Structure-based. Can explain an alert, never create one.', style: 'bg-amber-600 text-white' },
};

export function TierBadge({ tier }: { tier: EvidenceTier }) {
  const info = TIERS[tier];
  return <span title={info.meaning} className={'inline-block rounded px-2 py-0.5 text-xs font-semibold mr-2 ' + info.style}>
    {info.name} evidence</span>;
}

/** Mol* viewer for one protein. Every structure carries an experimental / predicted label. */
export function ProteinViewer({ target, token, compact = false }: { target: string; token: string; compact?: boolean }) {
  const [protein, setProtein] = useState<ProteinView>();
  const [kind, setKind] = useState<'experimental' | 'predicted'>('experimental');
  const [enabled, setEnabled] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    setProtein(undefined); setEnabled(false); setError('');
    get<ProteinView>('/molecular/proteins/' + encodeURIComponent(target), token)
      .then(setProtein).catch(e => setError(e instanceof Error ? e.message : 'Failed'));
  }, [target, token]);

  if (error) return <p role="alert">{error}</p>;
  if (!protein) return <p>Loading structure record…</p>;
  const structure = protein.structures.find(s => s.kind === kind) ?? protein.structures[0];
  const query = new URLSearchParams(structure.kind === 'experimental' ? { pdb: structure.accession } : { afdb: structure.accession });
  const viewer = 'https://molstar.org/viewer/?' + query.toString();

  return <div className="grid gap-3">
    <label className="block max-w-sm">{protein.target} structure
      <select value={kind} onChange={e => { setKind(e.target.value === 'predicted' ? 'predicted' : 'experimental'); setEnabled(false); }}>
        {protein.structures.map(s => <option key={s.kind} value={s.kind}>{s.label}</option>)}
      </select>
    </label>
    <div className="bg-[#102e2b] text-white rounded-xl overflow-hidden">
      {enabled ? <iframe key={structure.accession + structure.kind} src={viewer}
          title={'Mol* 3D viewer for ' + protein.target + ' ' + structure.accession}
          className={'w-full border-0 ' + (compact ? 'h-80' : 'h-[clamp(24rem,55vh,38rem)]')}
          referrerPolicy="no-referrer" sandbox="allow-scripts allow-same-origin" allowFullScreen /> :
        <div className="flex min-h-48 flex-col justify-center items-start p-6 gap-3">
          <h3 className="text-2xl font-semibold">{protein.name}</h3>
          <p className="text-emerald-100">{structure.label}</p>
          <button className="secondary" onClick={() => setEnabled(true)}>Load interactive 3D viewer</button>
          <p className="text-sm text-emerald-100">Loads the public structure from the hosted Mol* viewer.</p>
        </div>}
    </div>
    <p className="text-sm"><strong>{structure.label}</strong> · {structure.method}. {structure.trust}
      {structure.confidence && <> Confidence: {structure.confidence}.</>}{' '}
      <a href={structure.source} target="_blank" rel="noreferrer">Primary record ↗</a>
      {' · '}<a href={viewer} target="_blank" rel="noreferrer">Open viewer in a new tab ↗</a></p>
    <p className="text-sm">{protein.role}</p>
    <p className="text-sm">{protein.limitation}</p>
  </div>;
}

export function WhyPanel({ mechanism, token, language = 'en' }:
  { mechanism: Mechanism; token: string; language?: string }) {
  const [open, setOpen] = useState(false);
  const text = mechanism.explanation[language] ?? mechanism.explanation.en;
  return <div className="mt-2">
    <button className="secondary" aria-expanded={open} onClick={() => setOpen(o => !o)}>
      {open ? (language === 'ta' ? 'மறை' : 'Hide why') : (language === 'ta' ? 'ஏன்?' : 'Why?')}</button>
    {open && <div className="mt-3 grid gap-3 border border-emerald-200 rounded-lg p-3 bg-white">
      <p lang="en"><TierBadge tier="predicted" />Explanation only. The alert above stands on its cited label, not on this structure.</p>
      <p lang={language}>{text}</p>
      <p className="text-sm" lang="en"><a href={mechanism.source} target="_blank" rel="noreferrer">Evidence: {mechanism.locator} ↗</a></p>
      {mechanism.targets.map(target => <ProteinViewer key={target} target={target} token={token} compact />)}
    </div>}
  </div>;
}
