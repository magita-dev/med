import { useEffect, useState } from 'react';
import type { FormEvent } from 'react';
import { get, post, put,
  type MolecularEvidence as EvidenceRecord, type MolecularHypothesis } from './api';
import { ProteinViewer, TierBadge } from './ProteinViewer';

const TARGETS = ['CYP3A4', 'CYP2D6', 'hERG', 'P-gp'];

function MolecularEvidence({ token, isPublisher, user }: { token: string; isPublisher: boolean; user: string }) {
  const [evidence, setEvidence] = useState<EvidenceRecord[]>([]);
  const [hypotheses, setHypotheses] = useState<MolecularHypothesis[]>([]);
  const [error, setError] = useState('');
  const [status, setStatus] = useState('');

  async function load() {
    setError('');
    try {
      setEvidence(await get<EvidenceRecord[]>('/molecular/evidence', token));
      // Hypotheses are reviewer-facing only; patients and households never receive them.
      setHypotheses(isPublisher ? await get<MolecularHypothesis[]>('/molecular/queue', token) : []);
    } catch (e) { setError(e instanceof Error ? e.message : 'Failed'); }
  }
  useEffect(() => { void load(); /* eslint-disable-next-line */ }, []);

  async function addEvidence(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    try {
      await post<EvidenceRecord>('/molecular/evidence', {
        target: String(data.get('target')), drug: String(data.get('drug')),
        relationship: String(data.get('relationship')),
        structures: [{ accession: String(data.get('accession')), kind: String(data.get('kind')) as 'experimental' | 'predicted',
          method: String(data.get('method')), source: String(data.get('source')),
          confidence: String(data.get('confidence')) || null }],
        evidence: [{ source: String(data.get('source')), locator: String(data.get('locator')) }],
        reviewed_by: 'pharmacist', reviewed_at: new Date().toISOString().slice(0, 10),
      }, token);
      setStatus('Evidence added.');
      await load();
    } catch (e) { setError(e instanceof Error ? e.message : 'Failed'); }
  }

  async function review(id: string, accept: boolean) {
    try {
      await put('/molecular/hypotheses/' + encodeURIComponent(id) + '/review', { accept }, token);
      setStatus(accept ? 'Hypothesis marked pharmacist-reviewed.' : 'Hypothesis rejected.');
      await load();
    } catch (e) { setError(e instanceof Error ? e.message : 'Failed'); }
  }

  async function propose(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    try {
      await post<MolecularHypothesis>('/molecular/hypotheses', {
        id: crypto.randomUUID(), drug: String(data.get('drug')), target: String(data.get('target')),
        mechanism: String(data.get('mechanism')),
        evidence: [{ source: String(data.get('source')), locator: String(data.get('locator')) }],
      }, token);
      setStatus('Hypothesis proposed as a draft awaiting pharmacist review.');
      await load();
    } catch (e) { setError(e instanceof Error ? e.message : 'Failed'); }
  }

  return <section aria-labelledby="molecular-evidence" className="mt-6 border-t border-emerald-100 pt-6">
    <h2 id="molecular-evidence" className="text-xl font-bold mb-2">Drug-protein evidence and hypotheses</h2>
    <p className="text-sm text-emerald-900 mb-4">
      A curated catalog keeps experimental and predicted structures distinct. A hypothesis links a
      medicine to a target with cited evidence and must pass pharmacist review before it is exposed.
      A structure never infers a clinical interaction.
    </p>
    {error && <p role="alert" className="text-red-900 bg-red-50 rounded-lg p-3 mb-3">{error}</p>}
    {status && <p aria-live="polite" className="text-sm text-emerald-900 mb-3">{status}</p>}
    {evidence.length > 0 && <>
      <h3 className="font-semibold mb-2">Evidence catalog</h3>
      <ul className="text-sm space-y-2 mb-4">{evidence.map((e, i) => <li key={i} className="border border-emerald-100 rounded-lg p-3">
        <p className="font-semibold">{e.drug} → {e.target} · {e.relationship}</p>
        {e.structures.map((s, j) => <p key={j} className="text-sm">
          {s.kind === 'predicted' ? 'Predicted' : 'Experimental'} · {s.accession} · {s.method}
          {s.confidence ? ` · confidence ${s.confidence}` : ''}
        </p>)}
      </li>)}</ul>
    </>}
    {hypotheses.length > 0 && <>
      <h3 className="font-semibold mb-2">Pharmacist hypothesis queue</h3>
      <p className="text-sm mb-2">Structure-based hypotheses are reviewer-only. They never appear to patients and never create an alert.</p>
      <ul className="text-sm space-y-2 mb-4">{hypotheses.map(h => <li key={h.id} className="border border-emerald-100 rounded-lg p-3">
        <p className="font-semibold"><TierBadge tier={h.tier} />{h.drug} → {h.target}</p>
        <p>{h.mechanism}</p>
        <p className="text-xs text-emerald-900">Proposed by {h.proposed_by || 'unknown'} · {h.status.replaceAll('_', ' ')}
          {h.reviewer && ` · reviewed by ${h.reviewer} ${h.reviewed_at ?? ''}`}</p>
        {h.status === 'draft' && (h.proposed_by === user ?
          <p className="text-xs">Awaiting a different reviewer.</p> :
          <p className="mt-2 flex gap-2">
            <button onClick={() => void review(h.id, true)}>Accept as reviewed</button>
            <button className="secondary" onClick={() => void review(h.id, false)}>Reject</button>
          </p>)}
      </li>)}</ul>
    </>}
    {isPublisher && <details className="border border-emerald-100 rounded-lg p-4">
      <summary className="font-semibold cursor-pointer">Curate evidence or propose a hypothesis (publisher)</summary>
      <form className="grid gap-3 max-w-md mt-4" onSubmit={addEvidence}>
        <h4 className="font-semibold text-sm">Add evidence</h4>
        <label>Target protein <input name="target" required maxLength={80} /></label>
        <label>Drug <input name="drug" required maxLength={200} /></label>
        <label>Relationship
          <select name="relationship"><option>metabolism</option><option>inhibition</option>
          <option>induction</option><option>target</option><option>transport</option></select>
        </label>
        <label>Structure accession <input name="accession" required maxLength={80} /></label>
        <label>Structure kind
          <select name="kind"><option value="experimental">Experimental</option><option value="predicted">Predicted</option></select>
        </label>
        <label>Method <input name="method" maxLength={120} /></label>
        <label>Structure source URL <input name="source" required maxLength={1600} /></label>
        <label>Confidence (predicted only) <input name="confidence" maxLength={40} /></label>
        <label>Evidence locator <input name="locator" maxLength={200} /></label>
        <button>Add evidence</button>
      </form>
      <form className="grid gap-3 max-w-md mt-6" onSubmit={propose}>
        <h4 className="font-semibold text-sm">Propose a hypothesis</h4>
        <label>Drug <input name="drug" required maxLength={200} /></label>
        <label>Target <input name="target" required maxLength={80} /></label>
        <label>Mechanism <textarea name="mechanism" rows={2} required maxLength={1000} /></label>
        <label>Evidence source URL <input name="source" maxLength={1600} /></label>
        <label>Evidence locator <input name="locator" maxLength={200} /></label>
        <button>Propose</button>
      </form>
      <div className="mt-4">
        <button className="secondary" onClick={() => void load()}>Refresh</button>
      </div>
    </details>}
  </section>;
}

export function MechanismLens({ token, isPublisher, user = '', initialTarget }:
  { token: string; isPublisher: boolean; user?: string; initialTarget?: string }) {
  const [target, setTarget] = useState(initialTarget ?? 'CYP3A4');
  return <>
    <div className="grid gap-5 lg:grid-cols-[minmax(0,2fr)_minmax(15rem,1fr)]">
      <section className="min-w-0" aria-label="Interactive molecular structure">
        <label className="block max-w-sm mb-3">Protein
          <select value={target} onChange={event => setTarget(event.target.value)}>
            {TARGETS.map(t => <option key={t} value={t}>{t}</option>)}
          </select>
        </label>
        <ProteinViewer target={target} token={token} />
      </section>
      <aside className="rounded-xl border border-emerald-100 bg-emerald-50 p-5 space-y-3">
        <p className="text-sm text-emerald-900">Mechanism lens · explanation only</p>
        <p><TierBadge tier="predicted" /></p>
        <p className="text-sm">The structure helps you see the protein involved in a warning. It is separate from screening and regulatory decisions: a prediction can explain an alert but can never create one.</p>
        <p className="text-sm">Open <strong>Why?</strong> on a Regimen Check finding to see the protein for that specific warning.</p>
      </aside>
    </div>
    <MolecularEvidence token={token} isPublisher={isPublisher} user={user} />
  </>;
}
