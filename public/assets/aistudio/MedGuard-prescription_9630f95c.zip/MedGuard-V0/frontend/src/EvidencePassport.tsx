import { copy } from './copy';
import type { Language } from './copy';

export type EvidenceMatch = {
  status: 'exact' | 'uncertain' | 'different_batch';
  checks: Record<string, string>;
  criteria?: { field: string; entered: string; notice: string; outcome: string }[];
  notice: {
    _id: string; kind: string; evidence_status: string; source: string | null; locator: string;
    sha256?: string; published?: string; reviewed_at?: string; source_page?: number;
    verification?: { source_bytes: string; transcription: string; scope: string };
  };
};

export function EvidencePassport({ match, language }: { match: EvidenceMatch; language: Language }) {
  const { notice, checks, criteria, status } = match;
  const kind = { nsq: 'Quality notice', recall: 'Recall', spurious: 'Spurious product notice',
    prohibition: 'Combination prohibition' }[notice.kind] ?? notice.kind;
  return <article className="passport" data-status={status}>
    <header>
      <p className="passport-label" lang="en">Evidence Passport</p>
      <h3>{copy[language][status]}</h3>
      <p lang="en">{kind} · {notice.evidence_status.replaceAll('_', ' ')}</p>
      {status !== 'different_batch' && <p>{copy[language].review}</p>}
    </header>
    {criteria?.length ? <table className="passport-criteria text-sm" lang="en">
      <caption className="text-left font-semibold">{copy[language].criteria}</caption>
      <thead><tr><th scope="col">Criterion</th><th scope="col">{copy[language].entered}</th>
        <th scope="col">{copy[language].recorded}</th><th scope="col">Result</th></tr></thead>
      <tbody>{criteria.map(row => <tr key={row.field}>
        <th scope="row">{row.field}</th><td>{row.entered || '—'}</td><td>{row.notice || '—'}</td>
        <td>{row.outcome.replaceAll('_', ' ')}</td></tr>)}</tbody>
    </table> : <dl className="passport-criteria" lang="en">
      {Object.entries(checks).map(([field, outcome]) => <div key={field}>
        <dt>{field}</dt><dd>{outcome.replaceAll('_', ' ')}</dd>
      </div>)}
    </dl>}
    <footer lang="en">
      {notice.source && <a href={notice.source} target="_blank" rel="noreferrer">Source document ↗</a>}
      <p>{notice.locator}{notice.source_page ? ' · PDF page ' + notice.source_page : ''}</p>
      {notice.published && <p>Published <time>{notice.published}</time></p>}
      {notice.reviewed_at && <p>Reviewed <time dateTime={notice.reviewed_at}>{notice.reviewed_at.slice(0, 10)}</time></p>}
      {notice.verification && <details>
        <summary>What was verified</summary>
        <dl>{Object.entries(notice.verification).map(([step, result]) => <div key={step}>
          <dt className="font-semibold capitalize">{step.replaceAll('_', ' ')}</dt>
          <dd>{result.replaceAll('_', ' ')}</dd>
        </div>)}</dl>
      </details>}
      {notice.sha256 && <details><summary>Evidence fingerprint</summary><code className="break-all">{notice.sha256}</code></details>}
    </footer>
  </article>;
}
