import { copy } from './copy';
import type { Language } from './copy';

type Item = { kind: string; ingredients: string[] };

/** Deterministic doctor questions built from fixed, translated templates. No AI-generated text. */
export function doctorQuestions(language: Language, findings: Item[], matchCount: number): string[] {
  const t = copy[language];
  const fill = (template: string, names: string[]) =>
    template.replace('{a}', names[0] ?? '').replace('{b}', names[1] ?? '');
  const questions: string[] = [];
  if (matchCount) questions.push(t.q_notice);
  for (const finding of findings) {
    const template = ({ interaction: t.q_interaction, duplicate: t.q_duplicate,
      geriatric: t.q_geriatric } as Record<string, string>)[finding.kind];
    if (template) questions.push(fill(template, finding.ingredients));
  }
  return [...new Set(questions)];
}
