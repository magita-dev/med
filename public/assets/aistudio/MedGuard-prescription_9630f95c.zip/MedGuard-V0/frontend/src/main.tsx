import { useEffect, useRef, useState } from 'react';
import { MechanismLens } from './MechanismLens';
import { TierBadge, WhyPanel } from './ProteinViewer';
import type { EvidenceTier, Mechanism } from './api';
import { doctorQuestions } from './questions';
import { Prescription } from './Prescription';
import { CellViewer } from './CellViewer';
import { ClinicalRules } from './ClinicalRules';
import { Operations } from './Operations';
import { EvidencePassport } from './EvidencePassport';
import { InventoryTable } from './InventoryTable';
import { ScanPreview } from './ScanPreview';
import type { OcrLine } from './ScanPreview';
import type { EvidenceMatch } from './EvidencePassport';
import type { FormEvent } from 'react';
import { createRoot } from 'react-dom/client';
import { copy } from './copy';
import type { Language } from './copy';
import './styles.css';

type Pack = {
  product: string; manufacturer: string; batch: string; ingredients: string[];
  form: string; strength: string; confirmed: true;
};
type Citation = { source: string | null; locator: string; sha256?: string };
type Notice = Citation & { _id: string; evidence_status: string; kind: string;
  product?: string; batch?: string; manufacturer?: string; ingredients?: string[];
  form?: string; strength?: string; effective?: string; active?: boolean; all_formulations?: boolean;
  source_page?: number; row_validation?: string; evidence_span?: number[] };
type Match = EvidenceMatch & { notice: Notice };
type Finding = Partial<Citation> & {
  kind: string; ingredients: string[]; message?: Record<Language, string>; jurisdiction?: string;
  tier?: EvidenceTier; mechanism?: Mechanism;
};
type Report = { matches: Match[]; findings?: Finding[]; not_found_as_of?: string;
  regulatory_freshness?: { sources: { source: string; stale: boolean; error?: string;
    last_success_at?: string; document_limit_reached?: boolean }[] };
  identity_candidates?: { product: string; manufacturer: string }[];
  clinical_coverage?: { jurisdiction: string; scope: string; unassessed_pair_count: number;
    packs_missing_ingredients: number } };
type Review = Match & { id: string; product: string; acknowledgement: { actor: string; at: string } | null;
  resolution: { outcome: string } | null };
type StockItem = Pack & { id: string; quantity: number; location: string };
type Actor = { user: string; role: string; tenant: string; demo: boolean };
type SourceStatus = { source: string; checked_at?: string; first_seen?: string; sha256?: string; error?: string };
type Capture = { _id: string; source: string; sha256: string; status: string;
  rows: { product: string; batch: string; manufacturer: string; locator: string; source_page: number }[] };
type SourceMonitor = { sources: SourceStatus[]; observed_versions: SourceStatus[]; ingestion: Capture[] };
type View = 'Pack check' | 'Regimen' | 'Prescription' | 'Inventory' | 'Evidence desk' | 'Mechanism Lens' | 'Cell Structure' | 'Clinical rules' | 'Operations';

function Source({ evidence }: { evidence: Partial<Citation> }) {
  return <p className="text-sm mt-2">
    {evidence.source && <a href={evidence.source} target="_blank" rel="noreferrer">Source ↗</a>}
    {' '}{evidence.locator}{evidence.sha256 && <span className="block break-all">SHA-256 {evidence.sha256}</span>}
  </p>;
}

function App() {
  const [lang, setLang] = useState<Language>('en');
  const [token, setToken] = useState('');
  const [actor, setActor] = useState<Actor>();
  const [view, setView] = useState<View>('Pack check');
  const [error, setError] = useState('');
  const [status, setStatus] = useState('');
  const [busy, setBusy] = useState(false);
  const [report, setReport] = useState<Report>();
  const [review, setReview] = useState<Review[]>([]);
  const [notificationCount, setNotificationCount] = useState<number>();
  const [stock, setStock] = useState<StockItem[]>([]);
  const packForm = useRef<HTMLFormElement>(null);
  const [ambiguous, setAmbiguous] = useState<string[]>([]);
  const [regimen, setRegimen] = useState<Pack[]>([]);
  const [confirmed, setConfirmed] = useState(false);
  const [file, setFile] = useState<File>();
  const [ocr, setOcr] = useState<OcrLine[]>([]);
  const [proposalLines, setProposalLines] = useState<Record<string, number>>({});
  const [focusedField, setFocusedField] = useState('');
  const [noticeFile, setNoticeFile] = useState<File>();
  const [preview, setPreview] = useState('');
  const [sourceStatus, setSourceStatus] = useState<SourceMonitor>();
  const [drafts, setDrafts] = useState<(Notice & { submitted_by: string })[]>([]);
  const [capture, setCapture] = useState<Capture>();
  const [metadata, setMetadata] = useState('');
  const [stockId, setStockId] = useState(() => crypto.randomUUID());
  const t = copy[lang];

  useEffect(() => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.getVoices();
      return () => window.speechSynthesis.cancel();
    }
  }, []);

  useEffect(() => {
    if (!token) return;
    let stopped = false;
    const controller = new AbortController();
    async function refresh() {
      try {
        const response = await fetch('/api/notifications', {
          headers: { Authorization: 'Basic ' + token }, cache: 'no-store', signal: controller.signal,
        });
        if (!response.ok) throw new Error('Notifications unavailable');
        const pending = await response.json() as Review[];
        if (!stopped) setNotificationCount(pending.length);
      } catch {
        if (!stopped) setNotificationCount(undefined);
      }
    }
    void refresh();
    const timer = window.setInterval(() => void refresh(), 30000);
    return () => { stopped = true; controller.abort(); window.clearInterval(timer); };
  }, [token]);

  async function api<T>(path: string, init?: RequestInit, auth = token): Promise<T> {
    const headers = new Headers(init?.headers);
    headers.set('Authorization', 'Basic ' + auth);
    if (typeof init?.body === 'string') headers.set('Content-Type', 'application/json');
    const response = await fetch('/api' + path, { ...init, headers, cache: 'no-store' });
    const result = await response.json();
    if (!response.ok) throw new Error(typeof result.detail === 'string' ? result.detail : 'Check the submitted fields.');
    return result as T;
  }

  async function run(action: () => Promise<void>) {
    setBusy(true);
    setError('');
    setStatus('');
    try { await action(); }
    catch (problem) { setError(problem instanceof Error ? problem.message : 'Request failed'); }
    finally { setBusy(false); }
  }

  function speak(message: string) {
    const voices = 'speechSynthesis' in window ? window.speechSynthesis.getVoices() : [];
    const forLanguage = voices.filter(v => v.lang.toLowerCase().startsWith(lang));
    // Prefer an on-device voice. A network voice may send the text to a vendor, so ask first.
    let voice = forLanguage.find(v => v.localService);
    if (!voice && forLanguage.length) {
      if (!window.confirm(t.remoteVoice)) return;
      voice = forLanguage[0];
    }
    if (!voice) { setError(t.unavailable); return; }
    const utterance = new SpeechSynthesisUtterance(message);
    utterance.voice = voice;
    utterance.lang = voice.lang;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utterance);
  }

  function signIn(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    void run(async () => {
      const credentials = new TextEncoder().encode(data.get('user') + ':' + data.get('password'));
      const auth = btoa(String.fromCharCode(...credentials));
      setActor(await api<Actor>('/me', undefined, auth));
      setToken(auth);
    });
  }

  function go(next: View) {
    setView(next);
    setReport(undefined);
    setError('');
    setStatus('');
    setConfirmed(false);
    setFile(undefined);
    setOcr([]);
    setAmbiguous([]);
    if (next === 'Inventory') void run(async () => {
      const [items, reviews] = await Promise.all([
        api<StockItem[]>('/stock'), api<Review[]>('/reviews'),
      ]);
      setStock(items);
      setReview(reviews);
    });
  }

  function submitPack(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!confirmed) return;
    const submitter = (event.nativeEvent as SubmitEvent).submitter as HTMLButtonElement;
    const data = new FormData(event.currentTarget);
    const get = (key: string) => String(data.get(key) ?? '').trim();
    const pack: Pack = {
      product: get('product'), manufacturer: get('manufacturer'), batch: get('batch'),
      ingredients: get('ingredients').split(',').map(item => item.trim()).filter(Boolean),
      form: get('form'), strength: get('strength'), confirmed: true,
    };
    if (submitter.value === 'regimen') {
      setRegimen(items => [...items, pack]);
      setStatus('Added to the regimen.');
      return;
    }
    setReport(undefined);
    void run(async () => {
      if (submitter.value === 'stock') {
        await api('/stock/' + stockId, { method: 'PUT', body: JSON.stringify({
          ...pack, quantity: Number(get('quantity')) || 1, location: get('location'),
        }) });
        setStatus('Stock registered. Review matched notices in Inventory.');
      } else {
        setReport(await api<Report>('/check', { method: 'POST', body: JSON.stringify(pack) }));
      }
    });
  }

  const views: View[] = ['Pack check', 'Regimen', 'Prescription', 'Inventory', 'Clinical rules', 'Mechanism Lens', 'Cell Structure', 'Operations'];
  if (actor?.role === 'publisher') views.push('Evidence desk');

  return <div className="mx-auto max-w-5xl px-4 pb-14">
    <header className="flex flex-wrap items-center justify-between gap-4 py-7">
      <div><p className="text-3xl font-extrabold tracking-tight">MedGuard</p>
        <p lang={lang} className="text-sm text-emerald-900">{t.tagline}</p></div>
      <label>Explanation language
        <select value={lang} onChange={e => setLang(e.target.value as Language)}>
          <option value="en">English</option><option value="hi">हिन्दी</option><option value="ta">தமிழ்</option>
        </select>
      </label>
    </header>

    {!actor ? <main className="panel max-w-md mx-auto mt-8">
      <h1 className="text-2xl font-bold mb-4">Sign in</h1>
      <form onSubmit={signIn} className="grid gap-4">
        <label>Username<input name="user" autoComplete="username" required maxLength={80} /></label>
        <label>Password<input name="password" type="password" autoComplete="current-password" required maxLength={256} /></label>
        <button disabled={busy}>Sign in</button>
      </form>
    </main> : <>
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm">{actor.user} · {actor.tenant}{actor.demo && ' · Training demo'}</p>
        <button className="secondary" onClick={() => window.location.reload()}>Sign out</button>
      </div>
      <nav aria-label="Workspace" className="flex flex-wrap gap-2 mb-4">
        {views.map(item => <button key={item} className="secondary" disabled={busy}
          aria-current={view === item ? 'page' : undefined} onClick={() => go(item)}>
          {item}{item === 'Inventory' && !!notificationCount && ' (' + notificationCount + ')'}
        </button>)}
      </nav>
      <main className="panel">
        <h1 className="text-2xl font-bold mb-5">{view}</h1>

        {view === 'Pack check' && <>
          <div className="rounded-lg border border-emerald-100 bg-emerald-50 p-4 mb-5">
            <label>Pack or prescription image <input type="file" accept="image/png,image/jpeg" capture="environment"
              onChange={e => { setFile(e.target.files?.[0]); setOcr([]); setProposalLines({}); setAmbiguous([]); setConfirmed(false); }} /></label>
            <button className="secondary mt-3" disabled={busy || !file} onClick={() => void run(async () => {
              if (!file) return;
              const upload = new FormData();
              upload.append('file', file);
              const result = await api<{ lines: OcrLine[]; proposals: Record<string, {
                value: string | null; requires_manual_entry?: boolean; candidates?: { line: number }[];
              }> }>(
                '/ocr?language=' + lang, { method: 'POST', body: upload },
              );
              setOcr(result.lines);
              setProposalLines(Object.fromEntries(Object.entries(result.proposals).flatMap(([field, proposal]) =>
                proposal.candidates?.length === 1 ? [[field, proposal.candidates[0].line]] : [])));
              setConfirmed(false);
              setReport(undefined);
              setStockId(crypto.randomUUID());
              packForm.current?.reset();
              for (const [field, proposal] of Object.entries(result.proposals)) {
                const input = packForm.current?.elements.namedItem(field);
                if (input instanceof HTMLInputElement && proposal.value !== null && !proposal.requires_manual_entry) {
                  input.value = proposal.value;
                }
              }
              setAmbiguous(Object.keys(result.proposals).filter(key =>
                result.proposals[key].value === null || result.proposals[key].requires_manual_entry));
              setStatus('OCR suggestions loaded. Review every field against the original.');
            })}>Read image</button>
            {ambiguous.length > 0 && <p>Verify against the original and enter manually: {ambiguous.join(', ')}.</p>}
            <p className="mt-2 text-sm">Use a sharp, evenly lit image with the batch and manufacturer visible.</p>
            {file && <ScanPreview key={file.name + ':' + file.lastModified} file={file} lines={ocr}
              activeLine={proposalLines[focusedField]} />}
            {ocr.length > 0 && <p className="mt-2 text-sm">
              Compare every batch character with the printed label, especially O and 0, and I and 1.
              Leave the batch blank if any character is unclear.
            </p>}
          </div>
          <form ref={packForm} className="grid gap-4" onSubmit={submitPack}
            onFocus={event => setFocusedField(event.target instanceof HTMLInputElement ? event.target.name : '')}
            onBlur={event => { if (!event.currentTarget.contains(event.relatedTarget)) setFocusedField(''); }}
            onChange={e => {
            if (e.target instanceof HTMLInputElement && e.target.type !== 'checkbox') {
              setConfirmed(false);
              setReport(undefined);
              setStockId(crypto.randomUUID());
            }
          }}>
            <label>Product name<input name="product" required maxLength={200} /></label>
            <div className="grid sm:grid-cols-2 gap-4">
              <label>Manufacturer<input name="manufacturer" maxLength={200} /></label>
              <label>Batch<input name="batch" maxLength={200} /></label>
              <label>Dosage form<input name="form" maxLength={200} /></label>
              <label>Strength as printed<input name="strength" maxLength={200} /></label>
            </div>
            <label>Confirmed ingredients, comma separated<input name="ingredients" /></label>
            <div className="grid sm:grid-cols-2 gap-4">
              <label>Stock quantity<input name="quantity" type="number" defaultValue={1} min={1} max={1000000} /></label>
              <label>Stock location<input name="location" maxLength={200} /></label>
            </div>
            <label className="flex items-start gap-2"><input type="checkbox" className="mt-1" checked={confirmed}
              onChange={e => setConfirmed(e.target.checked)} required />
              I reviewed these fields against the original and left unknown fields blank.</label>
            <div className="flex flex-wrap gap-2">
              <button disabled={busy} value="check">Check pack</button>
              <button disabled={busy} className="secondary" value="stock">Save to inventory</button>
              <button disabled={busy || regimen.length >= 40} className="secondary" value="regimen">Add to regimen</button>
            </div>
          </form>
        </>}

        {view === 'Regimen' && <>
          {regimen.length ? <ol className="grid gap-2 mb-4">{regimen.map((pack, index) => <li key={index}
            className="flex justify-between items-center gap-4"><span>{pack.product} · {pack.ingredients.join(', ') || 'Ingredients unknown'}</span>
            <button className="secondary" aria-label={'Remove ' + pack.product} onClick={() => {
              setRegimen(items => items.filter((_, i) => i !== index)); setReport(undefined);
            }}>Remove</button></li>)}</ol> : <p className="mb-4">Add confirmed products from Pack check.</p>}
          <form className="grid gap-4 max-w-sm" onSubmit={event => {
            event.preventDefault();
            const age = String(new FormData(event.currentTarget).get('age'));
            setReport(undefined);
            void run(async () => setReport(await api<Report>('/regimen', {
              method: 'POST', body: JSON.stringify({ packs: regimen, age: age ? Number(age) : null }),
            })));
          }}>
            <label>Age in years (optional)<input type="number" name="age" min="0" max="125" onChange={() => setReport(undefined)} /></label>
            <button disabled={busy || !regimen.length}>Screen regimen</button>
          </form>
        </>}

        {view === 'Inventory' && <>
          <InventoryTable stock={stock} />
          <h2 className="font-semibold text-lg mt-5">Notice review queue</h2>
          {!review.length && <p lang={lang}>{t.none}</p>}
          {review.map(item => <article className="border-t border-emerald-100 py-3 mt-2" key={item.id}>
            <h3 className="font-semibold">{item.product}</h3>
                <EvidencePassport match={item} language={lang} />
            {item.acknowledgement ? <p className="mt-2">Acknowledged by {item.acknowledgement.actor} · {item.acknowledgement.at}</p> :
              <button className="mt-2" disabled={busy} onClick={() => void run(async () => {
                await api('/reviews/' + encodeURIComponent(item.id) + '/ack', { method: 'PUT' });
                setReview(await api<Review[]>('/reviews'));
                setNotificationCount((await api<Review[]>('/notifications')).length);
              })}>Acknowledge</button>}
            {item.resolution ? <p>Response recorded · {item.resolution.outcome.replaceAll('_', ' ')}. Physical stock movement has not been verified.</p> :
              item.acknowledgement && <form className="grid gap-2 mt-3 max-w-sm" onSubmit={event => {
                event.preventDefault();
                const data = new FormData(event.currentTarget);
                void run(async () => {
                  await api('/reviews/' + encodeURIComponent(item.id) + '/resolution', {
                    method: 'PUT', body: JSON.stringify({ outcome: data.get('outcome'), note: data.get('note') }),
                  });
                  setReview(await api<Review[]>('/reviews'));
                });
              }}>
                <label>Stock response<select name="outcome">
                  <option value="quarantined">Quarantined</option><option value="returned">Returned</option>
                  <option value="record_corrected">Record corrected</option><option value="escalated">Escalated</option>
                </select></label>
                <label>Response note<input name="note" required maxLength={200} /></label>
                <button disabled={busy}>Record response</button>
              </form>}
          </article>)}
        </>}

        {view === 'Evidence desk' && <>
          <button className="secondary mb-3" disabled={busy} onClick={() => void run(async () => {
            setDrafts(await api<typeof drafts>('/notice-drafts'));
          })}>Load notice drafts</button>
          {drafts.map(draft => <article key={draft._id} className="my-3">
            <p>{draft._id} · {draft.evidence_status} · Submitted by {draft.submitted_by}</p>
            <p>{draft.kind} · {draft.product} · {draft.manufacturer} · {draft.batch} · {draft.ingredients?.join(' + ')}</p>
            <p>Effective {draft.effective} · {draft.active ? 'Active' : 'Withdrawal'} · {draft.form} {draft.strength}
              {draft.all_formulations && ' · All formulations'}</p>
            {draft.source_page && <p>Official PDF page {draft.source_page}</p>}
            {draft.evidence_span && <p>Selected PDF region {draft.evidence_span.join(', ')}</p>}
            <Source evidence={draft} />
            {draft.submitted_by !== actor.user && <button className="mt-2" disabled={busy} onClick={() => {
              if (!window.confirm('Have you independently checked the original PDF, the cited row or selected region, and the notice scope?')) return;
              void run(async () => {
                const approved = await api<Notice>('/notice-drafts/' + encodeURIComponent(draft._id) + '/approve', {
                  method: 'PUT', body: JSON.stringify({ reviewer_attests_span: true }),
                });
                setDrafts(await api<typeof drafts>('/notice-drafts'));
                setStatus(approved.evidence_status === 'human_reviewed_unverified_extraction'
                  ? 'Approved for manual follow-up. Extraction remains unverified.'
                  : 'Approved extracted-row revision ' + draft._id);
              });
            }}>Approve reviewed draft</button>}
          </article>)}
          <button className="secondary mb-3" disabled={busy} onClick={() => void run(async () => {
            setSourceStatus(await api<SourceMonitor>('/source-status'));
          })}>Check monitored sources</button>
          {sourceStatus && <section className="mb-4">
            <h2 className="font-semibold">Official source observations</h2>
            {!sourceStatus.sources.length && <p>No checks recorded.</p>}
            {sourceStatus.sources.map(item => <p key={item.source} className="break-all text-sm">
              <a href={item.source} target="_blank" rel="noreferrer">{item.source}</a>
              {' · '}{item.checked_at}{' · '}{item.error ?? item.sha256}
            </p>)}
            <p>{sourceStatus.observed_versions.length} distinct versions observed. Publication requires source and scope review.</p>
            {sourceStatus.ingestion.map(item => <details key={item._id} className="my-2">
              <summary>{item.status.replaceAll('_', ' ')} · {item.rows.length} proposed rows</summary>
              <p className="break-all"><a href={item.source} target="_blank" rel="noreferrer">{item.source}</a></p>
              <ul>{item.rows.map((row, i) => <li key={i}>
                {row.product} · {row.manufacturer} · {row.batch} · {row.locator}{' '}
                <button className="secondary" onClick={() => {
                  setCapture(item);
                  setMetadata(JSON.stringify({kind: 'nsq', source: item.source,
                    product: row.product, manufacturer: row.manufacturer, batch: row.batch,
                    locator: row.locator, source_page: row.source_page,
                  }, null, 2));
                }}>Use proposed row</button>
              </li>)}</ul>
            </details>)}
          </section>}
          <label>Official notice PDF<input type="file" accept=".pdf" onChange={e => {
            setNoticeFile(e.target.files?.[0]); setCapture(undefined); setPreview('');
          }} /></label>
          <button className="secondary mt-2" disabled={busy || !noticeFile} onClick={() => void run(async () => {
            const data = new FormData();
            if (noticeFile) data.set('file', noticeFile);
            const result = await api<{ pages: { page: number; text: string }[] }>('/evidence/extract', { method: 'POST', body: data });
            setPreview(result.pages.map(p => 'Page ' + p.page + '\n' + p.text).join('\n\n'));
          })}>Extract for review</button>
          {preview && <pre className="max-h-60 overflow-auto whitespace-pre-wrap text-sm bg-emerald-50 p-3 mt-3">{preview}</pre>}
          <form className="grid gap-4 mt-5" onSubmit={event => {
            event.preventDefault();
            const data = new FormData(event.currentTarget);
            if (noticeFile) data.set('file', noticeFile);
            void run(async () => {
              const result = capture ? await api<Notice>('/ingestion/' + capture.sha256 + '/draft', {
                method: 'POST', body: metadata,
              }) : await api<Notice>('/notices', { method: 'POST', body: data });
              setStatus('Submitted notice draft ' + result._id + ' for independent review.');
            });
          }}>
            {capture && <p className="break-all">Using captured PDF {capture.sha256}</p>}
            <label>Notice metadata JSON<textarea name="metadata" rows={7} required value={metadata}
              onChange={event => setMetadata(event.target.value)}
              placeholder='{"key":"notice-id","version":1,"kind":"nsq","locator":"page 1, row 1",…}' /></label>
            <p>Use the Notice schema in the <a href="/api/docs" target="_blank" rel="noreferrer">API reference</a>.</p>
            <p>For manual review, include the PDF page, a normalized evidence rectangle
              [left, top, right, bottom], and submitter_attests_span set to true after checking that region.</p>
            <label className="flex items-start gap-2"><input type="checkbox" name="verified" value="true" required />
              I verified the file, source URL, row and scope against the official publication.</label>
            <button disabled={busy || (!noticeFile && !capture)}>Submit revision for review</button>
          </form>
        </>}

        {view === 'Prescription' && <Prescription token={token} />}
        {view === 'Mechanism Lens' && <MechanismLens token={token} isPublisher={actor.role === 'publisher'} user={actor.user} />}

        {view === 'Cell Structure' && <CellViewer />}

        {view === 'Clinical rules' && <ClinicalRules token={token} />}

        {view === 'Operations' && <Operations token={token} actor={actor} />}

        {report && <section className="mt-6 bg-emerald-50 p-4 rounded-lg" aria-label="Findings" lang={lang}>
          <h2 className="text-lg font-semibold">Findings</h2>
          {report.regulatory_freshness && <details lang="en" className="mb-2">
            <summary>Regulatory source coverage{report.regulatory_freshness.sources.some(
              source => source.stale || source.error || source.document_limit_reached) ? ' · Check source status' : ''}</summary>
            <p>Coverage is limited to configured sources. New notices may await review.</p>
            {!report.regulatory_freshness.sources.length && <p>No monitored sources configured.</p>}
            <ul>{report.regulatory_freshness.sources.map(source => <li key={source.source} className="break-all">
              <a href={source.source} target="_blank" rel="noreferrer">{source.source}</a>
              {' · '}{source.last_success_at ?? 'No successful fetch'}{source.stale && ' · Stale'}
              {source.error && ' · Latest check failed'}{source.document_limit_reached && ' · Discovery limit reached'}
            </li>)}</ul>
          </details>}
          {report.clinical_coverage && <p lang="en">Selected US label rules only.
            {' '}{report.clinical_coverage.unassessed_pair_count} entered ingredient pairs have no loaded rule.
            {' '}{report.clinical_coverage.packs_missing_ingredients} listed products lack ingredients.</p>}
          {!!report.identity_candidates?.length && <div lang="en">
            <p>Catalog candidates to verify against the original pack</p>
            <ul>{report.identity_candidates.map(candidate => <li key={candidate.product + '|' + candidate.manufacturer}>
              {candidate.product} · {candidate.manufacturer}
            </li>)}</ul>
          </div>}
          {!report.matches.length && !report.findings?.length && report.not_found_as_of &&
            <p>{t.not_found.replace('{date}', report.not_found_as_of)}</p>}
          {report.matches.map((match, i) => <EvidencePassport key={match.notice._id + ':' + i}
            match={match} language={lang} />)}
          {report.findings?.map((finding, i) => <article key={i} className="mt-3 border-t border-emerald-200 pt-2">
            <p>{finding.tier && <TierBadge tier={finding.tier} />}{finding.ingredients.join(' + ')} · {finding.message?.[lang] ?? t.duplicate}</p>
            {finding.jurisdiction && <p>Label jurisdiction {finding.jurisdiction}</p>}
            <Source evidence={finding} />
            {finding.mechanism && <WhyPanel mechanism={finding.mechanism} token={token} language={lang} />}
          </article>)}
          {(() => {
            const questions = doctorQuestions(lang, report.findings ?? [], report.matches.length);
            return questions.length > 0 && <div className="mt-4">
              <h3 className="font-semibold">{t.doctorHeading}</h3>
              <ul className="list-disc ml-5">{questions.map(q => <li key={q}>{q}</li>)}</ul>
              <button className="secondary mt-2" onClick={() => speak(questions.join(' '))}>{t.speak}</button>
            </div>;
          })()}
          <button className="secondary mt-3" onClick={() => speak([
            ...report.matches.map(m => t[m.status]),
            ...report.findings?.map(f => f.ingredients.join(', ') + '. ' + (f.message?.[lang] ?? t.duplicate)) ?? [],
            ...(!report.matches.length && !report.findings?.length ?
              [t.not_found.replace('{date}', report.not_found_as_of ?? '')] :
              report.findings?.length || report.matches.some(m => m.status !== 'different_batch') ? [t.review] : []),
            t.coverage,
          ].join('. '))}>{t.speak}</button>
        </section>}
        {view !== 'Prescription' && view !== 'Mechanism Lens' && view !== 'Evidence desk' && view !== 'Cell Structure' &&
          view !== 'Clinical rules' && view !== 'Operations' &&
          <p lang={lang} className="mt-5 text-sm text-emerald-900">{t.coverage}</p>}
      </main>
    </>}
    <div className="mt-4" aria-live="polite">{busy ? 'Working…' : status}</div>
    {error && <p role="alert" className="mt-2 text-red-900 bg-red-50 rounded-lg p-3">{error}</p>}
  </div>;
}

createRoot(document.getElementById('root')!).render(<App />);

