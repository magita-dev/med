import { useCallback, useEffect, useRef, useState } from 'react';

/* Interactive 3D viewer of a cell's inner structure (organelles).
 *
 * Implemented with a small dependency-free software-3D renderer on a 2D canvas:
 * each organelle is an oriented ellipsoid. The visible silhouette of a rotated
 * ellipsoid under orthographic projection is an ellipse derived from the 2x2
 * matrix J*Jᵀ (where J is the projected linear map), which we decompose to get
 * the on-screen radii and orientation. Shading is a radial gradient faking a
 * single light from the upper-left. No external 3D library is required. */

type Vec3 = [number, number, number];
type Kind =
  | 'membrane' | 'nucleus' | 'nucleolus' | 'mitochondrion' | 'er' | 'golgi'
  | 'lysosome' | 'ribosome' | 'vacuole' | 'peroxisome' | 'centrosome';

type Instance = {
  kind: Kind;
  center: Vec3;
  radii: Vec3;
  orient: Vec3;        // Euler angles (ox, oy, oz) for the instance orientation
  color: [number, number, number];
  alpha: number;       // body fill alpha
  outline: number;     // outline alpha
};

type Info = { name: string; role: string; medicine: string };

const INFO: Record<Kind, Info> = {
  membrane: {
    name: 'Cell membrane',
    role: 'The lipid bilayer that separates the cell from its surroundings and controls what enters and leaves.',
    medicine: 'A medicine has to cross this membrane to reach its target. How well a drug dissolves in fat (lipophilicity) and which transport proteins are present strongly affect absorption and effect.',
  },
  nucleus: {
    name: 'Nucleus',
    role: 'Holds the cell\'s DNA and directs gene expression.',
    medicine: 'Many drug targets act here, for example nuclear hormone receptors. Some medicines, such as certain chemotherapeutics, act directly on DNA inside the nucleus.',
  },
  nucleolus: {
    name: 'Nucleolus',
    role: 'A dense region in the nucleus where ribosomes are assembled.',
    medicine: 'Some drugs affect ribosome production; changes here are studied as a marker of drug stress on the cell.',
  },
  mitochondrion: {
    name: 'Mitochondrion',
    role: 'Produces most of the cell\'s energy (ATP) through respiration.',
    medicine: 'A common site of drug toxicity. High-dose paracetamol and some antiretrovirals can damage mitochondria; statins are linked to muscle effects.',
  },
  er: {
    name: 'Endoplasmic reticulum',
    role: 'A folded membrane network. The rough ER (studded with ribosomes) builds proteins; the smooth ER makes lipids and hosts drug-metabolising enzymes.',
    medicine: 'Smooth ER contains cytochrome P450 enzymes such as CYP3A4 — the same enzyme shown in the Mechanism Lens — which metabolise many medicines.',
  },
  golgi: {
    name: 'Golgi apparatus',
    role: 'Modifies, sorts and packages proteins for delivery inside or outside the cell.',
    medicine: 'Modifies proteins before they reach the cell surface, which can change how a cell responds to certain medicines.',
  },
  lysosome: {
    name: 'Lysosome',
    role: 'A vesicle full of enzymes that breaks down worn-out parts and captured material.',
    medicine: 'Some drugs build up in lysosomes and can disrupt them; this is studied as a cause of drug side effects.',
  },
  ribosome: {
    name: 'Ribosome',
    role: 'The machine that reads genetic instructions and assembles proteins.',
    medicine: 'A direct target of several antibiotic classes, for example tetracyclines and macrolides such as clarithromycin, which stop bacteria building proteins.',
  },
  vacuole: {
    name: 'Vacuole',
    role: 'A storage sac for water, nutrients and waste, helping maintain cell balance.',
    medicine: 'Sequesters and stores materials; certain drugs can accumulate in these compartments.',
  },
  peroxisome: {
    name: 'Peroxisome',
    role: 'Carries out oxidation reactions, including breaking down fatty acids and neutralising reactive oxygen.',
    medicine: 'Contributes to lipid metabolism; some drug and toxin processing involves peroxisomal pathways.',
  },
  centrosome: {
    name: 'Centrosome',
    role: 'Organises the microtubules that shape the cell and pull chromosomes apart during division.',
    medicine: 'Microtubules are the target of some cancer medicines, for example vincristine, which block cell division.',
  },
};

const SWATCH: Record<Kind, string> = {
  membrane: '#9ce0c6', nucleus: '#b284d6', nucleolus: '#825bb2', mitochondrion: '#e4785c',
  er: '#6eb4e2', golgi: '#eec65c', lysosome: '#78c896', ribosome: '#606074', vacuole: '#c8b4e6',
  peroxisome: '#dea078', centrosome: '#d66482',
};

// ---- 3x3 matrix helpers (row-major) ----------------------------------------
function rxMat(p: number): number[] {
  const c = Math.cos(p), s = Math.sin(p);
  return [1, 0, 0, 0, c, -s, 0, s, c];
}
function ryMat(y: number): number[] {
  const c = Math.cos(y), s = Math.sin(y);
  return [c, 0, s, 0, 1, 0, -s, 0, c];
}
function rzMat(z: number): number[] {
  const c = Math.cos(z), s = Math.sin(z);
  return [c, -s, 0, s, c, 0, 0, 0, 1];
}
function matMul(a: number[], b: number[]): number[] {
  const r = new Array<number>(9).fill(0);
  for (let i = 0; i < 3; i++)
    for (let j = 0; j < 3; j++) {
      let s = 0;
      for (let k = 0; k < 3; k++) s += a[i * 3 + k] * b[k * 3 + j];
      r[i * 3 + j] = s;
    }
  return r;
}
function matVec(m: number[], v: Vec3): Vec3 {
  return [
    m[0] * v[0] + m[1] * v[1] + m[2] * v[2],
    m[3] * v[0] + m[4] * v[1] + m[5] * v[2],
    m[6] * v[0] + m[7] * v[1] + m[8] * v[2],
  ];
}
function orientMat(o: Vec3): number[] {
  return matMul(rzMat(o[2]), matMul(ryMat(o[1]), rxMat(o[0])));
}
// R * diag(radii)
function scaleMat(r: number[], radii: Vec3): number[] {
  return [
    r[0] * radii[0], r[1] * radii[1], r[2] * radii[2],
    r[3] * radii[0], r[4] * radii[1], r[5] * radii[2],
    r[6] * radii[0], r[7] * radii[1], r[8] * radii[2],
  ];
}

// ---- scene ------------------------------------------------------------------
const NUCLEUS_CENTER: Vec3 = [0.05, 0.02, -0.02];

const BASE_INSTANCES: Instance[] = [
  { kind: 'membrane', center: [0, 0, 0], radii: [1.0, 0.78, 0.88], orient: [0, 0, 0], color: [156, 224, 198], alpha: 0.05, outline: 0.4 },
  { kind: 'nucleus', center: NUCLEUS_CENTER, radii: [0.4, 0.38, 0.4], orient: [0, 0, 0], color: [178, 132, 214], alpha: 1, outline: 0.5 },
  { kind: 'nucleolus', center: [0.02, 0.1, 0.05], radii: [0.14, 0.13, 0.14], orient: [0, 0, 0], color: [130, 88, 178], alpha: 1, outline: 0.5 },
  { kind: 'mitochondrion', center: [0.55, 0.42, 0.25], radii: [0.17, 0.06, 0.06], orient: [0, 0.6, 0.3], color: [228, 120, 92], alpha: 1, outline: 0.55 },
  { kind: 'mitochondrion', center: [-0.5, 0.4, -0.28], radii: [0.16, 0.06, 0.06], orient: [0, -0.5, 1.1], color: [228, 120, 92], alpha: 1, outline: 0.55 },
  { kind: 'mitochondrion', center: [0.3, -0.52, 0.4], radii: [0.15, 0.055, 0.055], orient: [0.3, 0.2, -0.6], color: [228, 120, 92], alpha: 1, outline: 0.55 },
  { kind: 'er', center: [0.48, -0.18, 0.3], radii: [0.2, 0.045, 0.06], orient: [0.4, 0.5, 0.2], color: [110, 180, 226], alpha: 0.92, outline: 0.5 },
  { kind: 'er', center: [-0.42, -0.3, 0.18], radii: [0.18, 0.045, 0.05], orient: [-0.2, -0.6, 0.5], color: [110, 180, 226], alpha: 0.92, outline: 0.5 },
  { kind: 'er', center: [-0.2, 0.48, -0.35], radii: [0.16, 0.04, 0.05], orient: [0.6, -0.3, 0.8], color: [110, 180, 226], alpha: 0.92, outline: 0.5 },
  { kind: 'er', center: [0.22, 0.3, -0.46], radii: [0.15, 0.04, 0.05], orient: [-0.5, 0.4, -0.3], color: [110, 180, 226], alpha: 0.92, outline: 0.5 },
  { kind: 'golgi', center: [-0.52, 0.12, 0.06], radii: [0.14, 0.028, 0.17], orient: [0.1, 0.15, 0], color: [238, 198, 92], alpha: 0.95, outline: 0.55 },
  { kind: 'golgi', center: [-0.52, 0.04, 0.06], radii: [0.14, 0.028, 0.17], orient: [0.1, 0.15, 0], color: [238, 198, 92], alpha: 0.95, outline: 0.55 },
  { kind: 'golgi', center: [-0.52, -0.04, 0.06], radii: [0.14, 0.028, 0.17], orient: [0.1, 0.15, 0], color: [238, 198, 92], alpha: 0.95, outline: 0.55 },
  { kind: 'golgi', center: [-0.52, -0.12, 0.06], radii: [0.14, 0.028, 0.17], orient: [0.1, 0.15, 0], color: [238, 198, 92], alpha: 0.95, outline: 0.55 },
  { kind: 'lysosome', center: [0.5, -0.3, -0.25], radii: [0.07, 0.07, 0.07], orient: [0, 0, 0], color: [120, 200, 150], alpha: 0.95, outline: 0.5 },
  { kind: 'lysosome', center: [-0.3, -0.45, 0.3], radii: [0.06, 0.06, 0.06], orient: [0, 0, 0], color: [120, 200, 150], alpha: 0.95, outline: 0.5 },
  { kind: 'lysosome', center: [0.1, 0.5, 0.4], radii: [0.055, 0.055, 0.055], orient: [0, 0, 0], color: [120, 200, 150], alpha: 0.95, outline: 0.5 },
  { kind: 'vacuole', center: [0.4, 0.05, -0.45], radii: [0.12, 0.12, 0.12], orient: [0, 0, 0], color: [200, 180, 230], alpha: 0.5, outline: 0.55 },
  { kind: 'peroxisome', center: [-0.15, -0.3, 0.45], radii: [0.055, 0.055, 0.055], orient: [0, 0, 0], color: [222, 160, 120], alpha: 0.95, outline: 0.5 },
  { kind: 'centrosome', center: [0.36, -0.4, 0.05], radii: [0.03, 0.03, 0.11], orient: [0, 0, 0], color: [214, 100, 130], alpha: 0.95, outline: 0.5 },
  { kind: 'centrosome', center: [0.36, -0.4, 0.05], radii: [0.11, 0.03, 0.03], orient: [0, 0, 0], color: [214, 100, 130], alpha: 0.95, outline: 0.5 },
];

// Deterministic ribosomes so the scene is stable across renders.
function buildRibosomes(): Instance[] {
  let seed = 987654321;
  const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
  const out: Instance[] = [];
  let attempts = 0;
  while (out.length < 34 && attempts < 4000) {
    attempts++;
    const r = 0.78 * Math.cbrt(rnd());
    const theta = rnd() * Math.PI * 2;
    const phi = Math.acos(2 * rnd() - 1);
    const p: Vec3 = [
      r * Math.sin(phi) * Math.cos(theta),
      r * Math.sin(phi) * Math.sin(theta),
      r * Math.cos(phi),
    ];
    const dn = Math.hypot(p[0] - NUCLEUS_CENTER[0], p[1] - NUCLEUS_CENTER[1], p[2] - NUCLEUS_CENTER[2]);
    if (dn < 0.5) continue; // keep ribosomes out of the nucleus
    out.push({ kind: 'ribosome', center: p, radii: [0.022, 0.022, 0.022], orient: [0, 0, 0], color: [96, 96, 116], alpha: 1, outline: 0 });
  }
  return out;
}

const INSTANCES: Instance[] = [...BASE_INSTANCES, ...buildRibosomes()];

type ScreenItem = {
  kind: Kind;
  scx: number; scy: number; r1: number; r2: number; theta: number; z: number;
  alpha: number; outline: number; color: [number, number, number];
};

function project(inst: Instance, V: number[], scale: number, cx: number, cy: number): ScreenItem {
  const vc = matVec(V, inst.center);
  const S = scaleMat(orientMat(inst.orient), inst.radii);
  const A = matMul(V, S); // A = V * S
  // J = [ row0 ; -row1 ]  (canvas y is downward)
  const a = A[0] * A[0] + A[1] * A[1] + A[2] * A[2];
  const b = -(A[0] * A[3] + A[1] * A[4] + A[2] * A[5]);
  const d = A[3] * A[3] + A[4] * A[4] + A[5] * A[5];
  // eigen-decomposition of [[a,b],[b,d]]
  const tr = a + d;
  const det = a * d - b * b;
  const disc = Math.max(0, tr * tr - 4 * det);
  const sq = Math.sqrt(disc);
  const l1 = (tr + sq) / 2;
  const l2 = (tr - sq) / 2;
  let theta: number;
  if (Math.abs(b) < 1e-9) theta = a >= d ? 0 : Math.PI / 2;
  else theta = Math.atan2(l1 - a, b);
  return {
    kind: inst.kind,
    scx: cx + vc[0] * scale,
    scy: cy - vc[1] * scale,
    r1: Math.sqrt(Math.max(0, l1)) * scale,
    r2: Math.sqrt(Math.max(0, l2)) * scale,
    theta, z: vc[2],
    alpha: inst.alpha, outline: inst.outline, color: inst.color,
  };
}

const clamp255 = (v: number) => Math.max(0, Math.min(255, Math.round(v)));
const rgba = (r: number, g: number, b: number, a: number) => `rgba(${clamp255(r)},${clamp255(g)},${clamp255(b)},${a})`;

export function CellViewer() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const yawRef = useRef(0.6);
  const pitchRef = useRef(-0.3);
  const zoomRef = useRef(1);
  const selRef = useRef<Kind | null>(null);
  const itemsRef = useRef<ScreenItem[]>([]);
  const dragRef = useRef<{ x: number; y: number; moved: number } | null>(null);

  const [selected, setSelected] = useState<Kind | null>(null);
  const [auto, setAuto] = useState(false);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const dpr = window.devicePixelRatio || 1;
    const cssW = canvas.clientWidth;
    const cssH = canvas.clientHeight;
    if (cssW === 0 || cssH === 0) return;
    if (canvas.width !== Math.round(cssW * dpr) || canvas.height !== Math.round(cssH * dpr)) {
      canvas.width = Math.round(cssW * dpr);
      canvas.height = Math.round(cssH * dpr);
    }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, cssW, cssH);

    const bg = ctx.createRadialGradient(cssW * 0.5, cssH * 0.42, 0, cssW * 0.5, cssH * 0.5, Math.max(cssW, cssH) * 0.75);
    bg.addColorStop(0, '#1a4a42');
    bg.addColorStop(1, '#0b211e');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, cssW, cssH);

    const V = matMul(ryMat(yawRef.current), rxMat(pitchRef.current));
    const scale = Math.min(cssW, cssH) * 0.42 * zoomRef.current;
    const cx = cssW / 2;
    const cy = cssH / 2;

    const all = INSTANCES.map(inst => project(inst, V, scale, cx, cy));
    itemsRef.current = all;
    const sel = selRef.current;

    const membrane = all.filter(it => it.kind === 'membrane');
    const rest = all.filter(it => it.kind !== 'membrane');

    // cytoplasm tint from the membrane, drawn behind everything
    for (const m of membrane) {
      ctx.save();
      ctx.beginPath();
      ctx.ellipse(m.scx, m.scy, m.r1, m.r2, m.theta, 0, Math.PI * 2);
      ctx.fillStyle = rgba(m.color[0], m.color[1], m.color[2], m.alpha);
      ctx.fill();
      ctx.restore();
    }

    // organelles, back to front
    rest.sort((p, q) => p.z - q.z);
    for (const it of rest) {
      const isSel = it.kind === sel;
      ctx.save();
      ctx.beginPath();
      ctx.ellipse(it.scx, it.scy, it.r1, it.r2, it.theta, 0, Math.PI * 2);
      if (it.r1 < 3 || it.r2 < 3) {
        // tiny dot (ribosome): solid fill, no gradient
        ctx.fillStyle = rgba(it.color[0], it.color[1], it.color[2], it.alpha);
        ctx.fill();
        if (isSel) { ctx.lineWidth = 2; ctx.strokeStyle = '#7ff3d0'; ctx.stroke(); }
        ctx.restore();
        continue;
      }
      const r = Math.max(it.r1, it.r2);
      const grad = ctx.createRadialGradient(
        it.scx - 0.34 * it.r1, it.scy - 0.34 * it.r2, 0,
        it.scx, it.scy, r * 1.3,
      );
      const c = it.color;
      grad.addColorStop(0, rgba(c[0] * 1.4 + 25, c[1] * 1.4 + 25, c[2] * 1.4 + 25, it.alpha));
      grad.addColorStop(0.5, rgba(c[0], c[1], c[2], it.alpha));
      grad.addColorStop(1, rgba(c[0] * 0.45, c[1] * 0.45, c[2] * 0.45, it.alpha));
      ctx.fillStyle = grad;
      ctx.fill();
      // inner membrane hint for mitochondria (cristae suggestion)
      if (it.kind === 'mitochondrion') {
        ctx.save();
        ctx.translate(it.scx, it.scy);
        ctx.rotate(it.theta);
        ctx.beginPath();
        ctx.ellipse(0, 0, it.r1 * 0.55, it.r2 * 0.7, 0, 0, Math.PI * 2);
        ctx.fillStyle = rgba(c[0] * 0.5, c[1] * 0.45, c[2] * 0.45, 0.45);
        ctx.fill();
        ctx.restore();
      }
      ctx.lineWidth = isSel ? 2.5 : 1;
      ctx.strokeStyle = isSel
        ? 'rgba(127,243,208,0.95)'
        : rgba(c[0] * 0.4, c[1] * 0.4, c[2] * 0.4, it.outline);
      ctx.stroke();
      ctx.restore();
    }

    // crisp membrane outline on top
    for (const m of membrane) {
      ctx.save();
      ctx.beginPath();
      ctx.ellipse(m.scx, m.scy, m.r1, m.r2, m.theta, 0, Math.PI * 2);
      ctx.lineWidth = m.kind === sel ? 2.5 : 1.5;
      ctx.strokeStyle = m.kind === sel ? 'rgba(127,243,208,0.95)' : rgba(m.color[0], m.color[1], m.color[2], m.outline);
      ctx.stroke();
      ctx.restore();
    }
  }, []);

  // pointer / wheel interaction
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const onDown = (e: PointerEvent) => {
      canvas.setPointerCapture(e.pointerId);
      dragRef.current = { x: e.clientX, y: e.clientY, moved: 0 };
    };
    const onMove = (e: PointerEvent) => {
      const drag = dragRef.current;
      if (!drag) return;
      const dx = e.clientX - drag.x;
      const dy = e.clientY - drag.y;
      drag.x = e.clientX;
      drag.y = e.clientY;
      drag.moved += Math.abs(dx) + Math.abs(dy);
      yawRef.current += dx * 0.01;
      pitchRef.current = Math.max(-1.45, Math.min(1.45, pitchRef.current + dy * 0.01));
      draw();
    };
    const onUp = (e: PointerEvent) => {
      const drag = dragRef.current;
      dragRef.current = null;
      if (!drag || drag.moved > 5) return; // it was a drag, not a click
      const rect = canvas.getBoundingClientRect();
      const px = e.clientX - rect.left;
      const py = e.clientY - rect.top;
      let best: ScreenItem | null = null;
      for (const it of itemsRef.current) {
        if (it.r1 < 2 && it.r2 < 2) continue;
        const cos = Math.cos(it.theta);
        const sin = Math.sin(it.theta);
        const lx = (px - it.scx) * cos + (py - it.scy) * sin;
        const ly = -(px - it.scx) * sin + (py - it.scy) * cos;
        if ((lx * lx) / (it.r1 * it.r1 + 0.0001) + (ly * ly) / (it.r2 * it.r2 + 0.0001) <= 1) {
          if (!best || it.z > best.z) best = it;
        }
      }
      const kind = best ? best.kind : null;
      selRef.current = kind;
      setSelected(kind);
      draw();
    };
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      zoomRef.current = Math.max(0.45, Math.min(3, zoomRef.current * (1 - e.deltaY * 0.0012)));
      draw();
    };

    canvas.addEventListener('pointerdown', onDown);
    canvas.addEventListener('pointermove', onMove);
    canvas.addEventListener('pointerup', onUp);
    canvas.addEventListener('pointercancel', () => { dragRef.current = null; });
    canvas.addEventListener('wheel', onWheel, { passive: false });
    return () => {
      canvas.removeEventListener('pointerdown', onDown);
      canvas.removeEventListener('pointermove', onMove);
      canvas.removeEventListener('pointerup', onUp);
      canvas.removeEventListener('wheel', onWheel);
    };
  }, [draw]);

  // redraw on selection change and resize
  useEffect(() => { draw(); }, [draw, selected]);
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ro = new ResizeObserver(() => draw());
    ro.observe(canvas);
    return () => ro.disconnect();
  }, [draw]);

  // auto-rotate
  useEffect(() => {
    if (!auto) return;
    let raf = 0;
    const loop = () => {
      yawRef.current += 0.004;
      draw();
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [auto, draw]);

  const select = (k: Kind | null) => { selRef.current = k; setSelected(k); draw(); };
  const reset = () => { yawRef.current = 0.6; pitchRef.current = -0.3; zoomRef.current = 1; draw(); };

  const legendKinds: Kind[] = ['membrane', 'nucleus', 'nucleolus', 'mitochondrion', 'er', 'golgi', 'lysosome', 'ribosome', 'vacuole', 'peroxisome', 'centrosome'];
  const info = selected ? INFO[selected] : null;

  return <div className="grid gap-5 lg:grid-cols-[minmax(0,2fr)_minmax(15rem,1fr)]">
    <section className="min-w-0" aria-label="Interactive 3D cell structure">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
        <p className="text-sm text-emerald-900">Drag to rotate · Scroll to zoom · Click an organelle</p>
        <div className="flex items-center gap-3">
          <label className="flex items-center gap-2 text-sm font-semibold">
            <input type="checkbox" checked={auto} onChange={e => setAuto(e.target.checked)} />
            Auto-rotate
          </label>
          <button className="secondary" onClick={reset}>Reset view</button>
        </div>
      </div>
      <div className="rounded-xl overflow-hidden" style={{ background: '#0b211e' }}>
        <canvas ref={canvasRef} aria-label="3D cell with organelles"
          className="w-full h-[clamp(24rem,58vh,42rem)] block"
          style={{ touchAction: 'none', cursor: 'grab' }} />
      </div>
    </section>

    <aside className="space-y-4">
      <div className="rounded-xl border border-emerald-100 bg-emerald-50 p-5 space-y-3">
        {info ? <>
          <p className="text-sm text-emerald-900">Organelle</p>
          <h2 className="font-semibold text-xl">{info.name}</h2>
          <p className="text-sm"><span className="font-semibold">Role: </span>{info.role}</p>
          <p className="text-sm"><span className="font-semibold">Medicine relevance: </span>{info.medicine}</p>
          <button className="secondary" onClick={() => select(null)}>Clear selection</button>
        </> : <>
          <h2 className="font-semibold text-xl">Inside the cell</h2>
          <p className="text-sm text-emerald-900">Select an organelle in the 3D view or the list below to read its role and how medicines relate to it.</p>
        </>}
        <p className="text-xs text-emerald-900 border-t border-emerald-200 pt-3">
          Educational illustration only. This is not a clinical tool and does not predict how a medicine will affect a specific person.
        </p>
      </div>

      <div className="rounded-xl border border-emerald-100 bg-white p-4">
        <p className="font-semibold mb-2 text-sm">Organelles</p>
        <ul className="grid gap-1.5">
          {legendKinds.map(k => (
            <li key={k}>
              <button className="w-full flex items-center gap-2 text-sm text-left rounded-md px-2 py-1"
                style={selected === k ? { background: '#e4f3ed', fontWeight: 650 } : undefined}
                onClick={() => select(k)}>
                <span aria-hidden="true" style={{ display: 'inline-block', width: 12, height: 12, borderRadius: 3, background: SWATCH[k], border: '1px solid #0003' }} />
                {INFO[k].name}
              </button>
            </li>
          ))}
        </ul>
      </div>
    </aside>
  </div>;
}
