import { defineConfig } from '@playwright/test';

export default defineConfig({
  testDir: './e2e',
  use: {
    baseURL: 'http://127.0.0.1:5173',
    channel: process.env.MEDGUARD_BROWSER_CHANNEL || undefined,
  },
  webServer: [
    {
      command: 'python -m uvicorn --app-dir backend medguard.api:create_app --factory --host 127.0.0.1 --port 8000',
      cwd: '..',
      env: { MEDGUARD_DEMO: '1' },
      url: 'http://127.0.0.1:8000/api/health',
      reuseExistingServer: false,
    },
    { command: 'npm run dev', url: 'http://127.0.0.1:5173', reuseExistingServer: false },
  ],
});
