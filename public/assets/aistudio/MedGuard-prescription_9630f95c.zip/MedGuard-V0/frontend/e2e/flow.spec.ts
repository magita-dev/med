import { expect, test } from '@playwright/test';

test('Mechanism Lens loads only the selected public structure on demand', async ({ page }) => {
  await page.route('https://molstar.org/viewer/**', route => route.fulfill({
    contentType: 'text/html', body: '<p>Hosted viewer fixture</p>',
  }));
  await page.goto('/');
  await page.getByLabel('Username').fill('household');
  await page.getByLabel('Password').fill('medguard-demo');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await page.getByRole('button', { name: 'Mechanism Lens' }).click();
  await expect(page.locator('iframe')).toHaveCount(0);
  await page.getByRole('button', { name: 'Load interactive 3D viewer' }).click();
  await expect(page.locator('iframe')).toHaveAttribute('src', 'https://molstar.org/viewer/?pdb=1TQN');
  await page.getByLabel('CYP3A4 structure').selectOption('predicted');
  await expect(page.locator('iframe')).toHaveAttribute('src', 'https://molstar.org/viewer/?afdb=P08684');
  await expect(page.getByText('AlphaFold-predicted (P08684)').first()).toBeVisible();
  await expect(page.getByText(/A structure shows the protein, not binding/)).toBeVisible();
  // Switching protein resets the viewer; hERG is a cryo-EM experimental structure.
  await page.getByLabel('Protein', { exact: true }).selectOption('hERG');
  await expect(page.locator('iframe')).toHaveCount(0);
  await page.getByRole('button', { name: 'Load interactive 3D viewer' }).click();
  await expect(page.locator('iframe')).toHaveAttribute('src', 'https://molstar.org/viewer/?pdb=5VA2');
  // Households never receive the pharmacist hypothesis queue.
  await expect(page.getByText('Pharmacist hypothesis queue')).toHaveCount(0);
});

test('confirmed pack, notice, stock, acknowledgement and localized explanation', async ({ page }) => {
  await page.goto('/');
  await page.getByLabel('Username').fill('household');
  await page.getByLabel('Password').fill('medguard-demo');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await page.getByLabel('Product name').fill('Monopropylene Glycol USP');
  await page.getByLabel('Manufacturer').fill('Shell Eastern Chemicals');
  await page.getByLabel('Batch', { exact: true }).fill('9971702044');
  await page.getByRole('checkbox').check();
  await page.getByRole('button', { name: 'Check pack' }).click();
  await expect(page.getByRole('region', { name: 'Findings' })).toContainText('Confirmed');
  await expect(page.getByText('Evidence Passport')).toBeVisible();
  await expect(page.getByText('Published')).toBeVisible();
  await expect(page.getByRole('link', { name: 'Source' })).toHaveAttribute('href', /cdsco.gov.in/);
  await page.getByLabel('Explanation language').selectOption('ta');
  await expect(page.getByRole('region', { name: 'Findings' })).toHaveAttribute('lang', 'ta');
  await page.getByRole('button', { name: 'Save to inventory' }).click();
  await expect(page.getByText('Stock registered', { exact: false })).toBeVisible();
  await page.getByRole('button', { name: /^Inventory(?: \(\d+\))?$/ }).click();
  await page.getByRole('button', { name: 'Acknowledge', exact: true }).click();
  await expect(page.getByText('Acknowledged by household', { exact: false })).toBeVisible();
  await page.getByLabel('Response note').fill('Moved to hold shelf');
  await page.getByRole('button', { name: 'Record response' }).click();
  await expect(page.getByText('Response recorded · quarantined')).toBeVisible();
});

test('OCR suggestions require confirmation and show informational batch mismatch', async ({ page }) => {
  await page.goto('/');
  await page.getByLabel('Username').fill('household');
  await page.getByLabel('Password').fill('medguard-demo');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await page.route('**/api/ocr?*', route => route.fulfill({ json: {
    confirmed: false, lines: [{ text: 'Batch No.: 9971702045', confidence: 0.98 }],
    proposals: {
      product: { value: 'Monopropylene Glycol USP' },
      manufacturer: { value: 'Shell Eastern Chemicals' },
      batch: { value: '9971702045', requires_manual_entry: true, candidates: [{ line: 0 }] },
    },
  } }));
  await page.getByLabel('Pack or prescription image').setInputFiles({
    name: 'fixture.png', mimeType: 'image/png', buffer: Buffer.from('fixture'),
  });
  await page.getByRole('button', { name: 'Read image' }).click();
  await expect(page.getByText('Verify against the original and enter manually: batch.')).toBeVisible();
  const batch = page.getByLabel('Batch', { exact: true });
  await expect(batch).toHaveValue('');
  await batch.focus();
  await expect(page.getByRole('button', { name: /Batch No\.: 9971702045/ })).toHaveAttribute('aria-pressed', 'true');
  await batch.fill('9971702045');
  await expect(page.getByRole('checkbox')).not.toBeChecked();
  await page.getByRole('checkbox').check();
  await page.getByRole('button', { name: 'Check pack' }).click();
  await expect(page.getByRole('region', { name: 'Findings' })).toContainText('different batch');
  await expect(page.locator('.passport')).toHaveAttribute('data-status', 'different_batch');
});

test('regimen screening and pharmacy workspace', async ({ page }) => {
  await page.goto('/');
  await page.getByLabel('Username').fill('pharmacy');
  await page.getByLabel('Password').fill('medguard-demo');
  await page.getByRole('button', { name: 'Sign in' }).click();
  for (const [product, ingredient] of [['Fictional A', 'clarithromycin'], ['Fictional B', 'simvastatin']]) {
    await page.getByLabel('Product name').fill(product);
    await page.getByLabel('Confirmed ingredients, comma separated').fill(ingredient);
    await page.getByRole('checkbox').check();
    await page.getByRole('button', { name: 'Add to regimen' }).click();
  }
  await page.getByRole('button', { name: 'Regimen', exact: true }).click();
  await page.getByRole('button', { name: 'Screen regimen' }).click();
  await expect(page.getByRole('region', { name: 'Findings' })).toContainText('contraindicates');
  await expect(page.getByRole('link', { name: 'Source' })).toHaveAttribute('href', /dailymed.nlm.nih.gov/);
  await page.getByRole('button', { name: 'Inventory', exact: true }).click();
  await expect(page.getByText('No stock recorded.')).toBeVisible();
});
