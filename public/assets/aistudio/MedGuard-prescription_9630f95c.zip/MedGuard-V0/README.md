# MedGuard

**Evidence-first medicine checks and pharmacy surveillance.**

MedGuard helps connect a *human-confirmed* medicine identity to source-linked regulatory notices, limited curated medication-screening rules, and a pharmacy inventory review workflow. Its aim is to make a published warning easier to identify, verify, and act on—without hiding where the evidence ends.

> **Project status:** Engineering prototype (`MedGuard-V0`, the ninth development revision). The repository includes a synthetic local demo, optional MongoDB persistence, and an optional pretrained PaddleOCR inference adapter. It has **not** been validated as a clinical decision tool, a complete Indian regulatory-alert database, or a comprehensive drug-interaction checker.
>
> **This revision** adds the eight "modules to add" as implemented backend modules with API routes and frontend surfaces, plus a 3D **Cell Structure** viewer, regulatory action/scope verification, skipped-document reporting, session tokens, role permissions and log redaction. Items that fundamentally require external resources (trained model weights, a licensed interaction database, real official PDFs with adjudicated labels, an OIDC provider, a live MongoDB) are implemented as far as code allows and clearly flagged — they are not validated.
>
> **Safety boundary:** A product or batch match does **not** establish what regulatory action applies. “No matching alert found” does **not** mean a medicine is safe. OCR output and fuzzy matches require confirmation. Users should not discontinue prescribed medication based on this prototype; real-world actions require professional and regulatory guidance.

## What the project currently does

The features below are implemented to different levels. **Demo** means the supplied fixtures exercise a working path; **partial** means code exists but real-world coverage or integration is incomplete; **educational** means it is not used to generate clinical warnings.

### 1. Regulatory intelligence — partial

- Watches configured official HTTPS notice URLs, downloads supported documents, and records source versions and SHA-256 digests.
- Proposes rows from recognized NSQ PDF tables and retains source provenance for reviewer inspection.
- Uses a two-person notice submission/approval flow, including separate source-byte, transcription, and scope evidence states.
- Shows monitoring errors and source-freshness information for configured sources.
- **Does not yet:** guarantee coverage of all CDSCO/state publications, parse every PDF layout, or independently establish that a notice's legal meaning was transcribed correctly.

Code: [`sources.py`](backend/medguard/sources.py), [`documents.py`](backend/medguard/documents.py), [`api.py`](backend/medguard/api.py).

### 2. Medicine Pack Check — demo

- Compares confirmed medicine name, manufacturer, and batch against loaded notice criteria.
- Distinguishes exact matches, ambiguous identities, and different-batch cases.
- Offers reviewed alias and similarity *suggestions*; they never become authoritative matches automatically.
- Provides an Evidence Passport that exposes the source and matching basis, with a criterion-by-criterion table (entered value, notice value, outcome).
- Result tiers: **Confirmed**, **Same product, different batch**, **Possible match**, and **Not found as of [date]**. No result is ever worded as "safe".

Code: [`core.py`](backend/medguard/core.py), [`identity.py`](backend/medguard/identity.py), [`EvidencePassport.tsx`](frontend/src/EvidencePassport.tsx).

### 3. Medicine-image OCR — partial

- Accepts an uploaded image and offers an optional local PaddleOCR detection/recognition pipeline.
- Can be configured for English, Devanagari, and Tamil recognition models.
- Presents text-line coordinates and field proposals for review; ambiguous batch suggestions are not silently accepted.
- Includes an interactive scan preview with image zoom and source-line highlighting.
- **Does not yet:** ship model weights, demonstrate representative real-pack accuracy, or provide a MedGuard-trained/fine-tuned model.

Code: [`ocr.py`](backend/medguard/ocr.py), [`ScanPreview.tsx`](frontend/src/ScanPreview.tsx).

### 4. Regimen Check — limited demo

- Flags duplicate ingredients and selected prohibited fixed-dose compositions when present in the loaded rules.
- Demonstrates three curated, label-derived clinical examples.
- Reports uncovered ingredient combinations as **unassessed**, rather than claiming they are interaction-free.
- **Does not yet:** cover general drug interactions, dosing, geriatric prescribing, or the Indian medicine market comprehensively.

Code: [`core.py`](backend/medguard/core.py), [`clinical.json`](fixtures/clinical.json).

### 5. Reverse surveillance — demo

- Matches approved notice revisions against tenant inventory.
- Uses opaque HMAC candidate-index tokens and MongoDB query paths to avoid an unconditional full scan in supported cases.
- Tracks revision-scoped impacts, worker leases, checkpoints, and replay-safe writes.
- Can run an optional standalone worker in persistent mode.
- **Does not yet:** have proven multi-instance, Atlas-failover, or durable external-notification behavior.

Code: [`candidates.py`](backend/medguard/candidates.py), [`store.py`](backend/medguard/store.py), [`worker.py`](backend/medguard/worker.py).

### 6. Evidence and audit trail — partial

- Records document digests, source references, review states, and notice versions.
- Stores encrypted evidence and tenant stock through the configured persistence adapter.
- Keeps manually reviewed extraction distinct from a successfully checked source row.
- **Does not yet:** prove the regulatory *finding/action type* is correct in every notice, or provide a production-grade tamper-evident audit system.

Code: [`api.py`](backend/medguard/api.py), [`store.py`](backend/medguard/store.py), [`EvidencePassport.tsx`](frontend/src/EvidencePassport.tsx).

### 7. Facility workspace and accessibility — partial

- Maintains tenant-scoped stock items, quantities, and locations; shows affected-stock reviews.
- Supports acknowledgement and recorded responses, with basic in-app review counts.
- Displays selected findings and deterministic doctor/pharmacist questions (fixed templates, no generated text) in English, Hindi, and Tamil, with browser speech. An on-device voice is preferred; a network voice is used only after the user confirms it may send the text to the browser vendor. Hindi and Tamil strings still need independent native-speaker review.
- **Does not yet:** verify physical stock quarantine/return, deliver reliable external alerts, or provide a fully localized, independently accessibility-tested interface.

Code: [`InventoryTable.tsx`](frontend/src/InventoryTable.tsx), [`copy.ts`](frontend/src/copy.ts), [`main.tsx`](frontend/src/main.tsx).

### 7b. Prescription review — partial

- Reads prescription lines (typed, or from the optional local OCR) into **proposals** the person must confirm: generic medicine name, strength, units per day, duration.
- Translates dosing shorthand (OD, BD, TDS, QID, HS, SOS, AC, PC, 1-0-1) into plain **English or Tamil**. Medicine names stay generic.
- **Dose check** and **condition match** only run when a reviewed, cited rule is loaded for that medicine (`fixtures/dose_rules.json`, `fixtures/indications.json`). Otherwise the check is reported as not assessed. The shipped rules are for a synthetic demo medicine only.
- Interactions, duplicates and elderly-risk findings reuse Regimen Check, with the AlphaFold **Why?** view and English/Tamil explanation.
- **Never outputs "safe".** The result is "possible issues found" or "no issues found as of [date] in N checks that could run, M could not run".
- **Does not yet:** map brand names to generic names, read handwriting reliably, or hold real dose/indication rules. Those need licensed or reviewed data and pharmacist sign-off.

### 8. Molecular Mechanism Lens — educational

- **Why? in Regimen Check:** a finding that has a cited mechanism shows a **Why?** button that opens the 3D view of the proteins involved. Today the two clarithromycin–statin rules link to CYP3A4.
- **Protein library:** CYP3A4, CYP2D6, hERG and P-gp, each with an experimental (PDB) and an AlphaFold-predicted structure in an embedded Mol* viewer (`GET /api/molecular/proteins[/{target}]`). Accessions are in [`molecular.py`](backend/medguard/molecular.py) and **must be re-checked against RCSB and AlphaFold DB before release**.
- **Provenance labels:** every structure is labelled `Experimental (PDB …)` or `AlphaFold-predicted (…)`, with a trust note and the primary record link.
- **Evidence tiers:** every finding carries `verified` (regulator alert), `curated` (reviewed label/interaction rule) or `predicted`. The engine drops any rule tagged `predicted` (`core.screen`), the rule schema rejects it, and hypotheses are fixed to `predicted`. A prediction can explain an alert; it can never create one.
- **Pharmacist hypothesis queue:** structure-based hypotheses are reviewer-only (`GET /api/molecular/queue`, `GET/PUT /api/molecular/hypotheses…` return 403 to members). A proposer cannot review their own hypothesis.
- **Does not:** run AlphaFold, predict a patient's interactions, or justify clinical warnings from a 3D structure. CYP2D6, hERG and P-gp have no linked clinical rules yet; adding them requires label-cited, pharmacist-reviewed rules.

Code: [`molecular.py`](backend/medguard/molecular.py), [`ProteinViewer.tsx`](frontend/src/ProteinViewer.tsx), [`MechanismLens.tsx`](frontend/src/MechanismLens.tsx).

### 9. Cell Structure Lens — educational

- A dependency-free interactive 3D viewer of the inner structure of a cell (membrane, nucleus, nucleolus, mitochondria, endoplasmic reticulum, Golgi, lysosomes, ribosomes, vacuole, peroxisome, centrosome).
- Drag to rotate, scroll to zoom, click an organelle for its role and medicine relevance (e.g. smooth ER hosts CYP3A4, the same enzyme in the Mechanism Lens; ribosomes are the target of macrolide antibiotics).
- **Does not:** predict how a medicine affects a specific person. Educational illustration only.

Code: [`CellViewer.tsx`](frontend/src/CellViewer.tsx).

## How the parts fit together

```mermaid
flowchart LR
  A[Configured official notice sources] --> B[Capture and extract evidence]
  B --> C[Independent reviewer approval]
  C --> D[Versioned notices]
  E[Medicine photo or manual entry] --> F[OCR proposal / identity confirmation]
  F --> G[Deterministic Pack Check]
  D --> G
  F --> H[Tenant inventory]
  D --> I[Surveillance jobs]
  H --> I
  I --> J[Facility review and response]
  G --> K[Evidence Passport]
  L[Limited curated rules] --> M[Regimen Check]
```

**Backend:** FastAPI, Pydantic, Python 3.13, PyMongo Async/in-memory storage, cryptography/Fernet, Argon2id, pdfplumber, optional PaddleOCR.  
**Frontend:** React 19, TypeScript, Vite 7, Tailwind CSS 4.  
**Optional infrastructure:** MongoDB or Atlas, encrypted local/S3-compatible evidence storage, locally provisioned OCR model weights.

### Repository map

```text
MedGuard-V0/
├── backend/medguard/
│   ├── api.py             # API routes, approval and workflow orchestration
│   ├── core.py            # deterministic pack/regimen rules
│   ├── models.py          # Pydantic contracts
│   ├── sources.py         # official-source capture and table proposals
│   ├── documents.py       # PDF extraction
│   ├── ocr.py             # optional OCR adapter
│   ├── identity.py        # candidate identities and reviewed aliases
│   ├── candidates.py      # HMAC candidate tokens
│   ├── store.py           # in-memory and MongoDB storage
│   └── worker.py          # standalone surveillance worker
├── frontend/src/          # app, scanner, evidence, inventory and Mol* viewer
├── frontend/e2e/          # Playwright flows
├── fixtures/              # synthetic notices and limited clinical examples
├── tests/                 # unit, integration and benchmark entry points
├── docs/                  # design, research, audit and validation records
├── .github/workflows/     # CI checks
├── Dockerfile
├── requirements.txt
└── requirements-ocr.txt
```

## Known gaps and next engineering priorities

The existing code should be improved in place. Every item below has a clear outcome we can test.

### P0 — Safety and correctness

**Regulatory document coverage**

- **Problem:** Source discovery and row extraction recognize only selected PDF and archive layouts. Scanned pages, corrections, and notices outside configured sources can be missed.
- **Improve:** Add source-specific adapters, OCR fallback where justified, skipped-document reporting, page/row coordinates, and revision tracking.
- **Done when:** An independently annotated collection of real official PDFs has document-level and row-level precision/recall results, including failures.
- **Start in:** [`sources.py`](backend/medguard/sources.py), [`documents.py`](backend/medguard/documents.py).

**Regulatory action verification**

- **Problem:** Correct document bytes and matched identity fields do not alone prove that the associated finding, action type, authority, or scope is correct.
- **Improve:** Represent NSQ findings, recalls, spurious-product notices, and prohibitions as distinct concepts. Review the source locator, finding, effective scope, and authority separately.
- **Done when:** The approval workflow rejects unsupported action/scope claims in an independently reviewed test set; manual verification remains visibly separate.
- **Start in:** [`models.py`](backend/medguard/models.py), [`api.py`](backend/medguard/api.py).

**OCR and medicine identity**

- **Problem:** Pretrained recognition models are optional; field accuracy on Indian packs and confident batch-transcription errors remain unmeasured.
- **Improve:** Build a labelled pack-image corpus, compare OCR baselines, evaluate ambiguous characters, and maintain a reviewed versioned product/manufacturer catalog. Keep human confirmation.
- **Done when:** Exact product/manufacturer/batch metrics, false confident matches, and abstention/correction rates are reported on held-out images.
- **Start in:** [`ocr.py`](backend/medguard/ocr.py), [`identity.py`](backend/medguard/identity.py), [`tests/benchmark_ocr.py`](tests/benchmark_ocr.py).

**Clinical evidence and coverage**

- **Problem:** Three illustrative rules cannot support broad medication-interaction or geriatric-risk claims.
- **Improve:** Use appropriately licensed, maintained sources; add rule provenance, jurisdiction, formulation, dose/route applicability, independent pharmacist review and expiry/re-review dates.
- **Done when:** Positive, negative, boundary, and unassessed cases are reproducibly evaluated; published coverage stays explicit.
- **Start in:** [`clinical.json`](fixtures/clinical.json), [`core.py`](backend/medguard/core.py).

### P1 — Reliability and product quality

**MongoDB and surveillance workers**

- Test atomic updates, indexes, job leases, worker restarts, simultaneous inserts, retries, recovery and cross-tenant isolation against **real MongoDB**, not just in-memory stubs.
- Measure performance with realistic candidate distributions and different inventory sizes. Use an external durable workflow system only if the existing leases/checkpoints fail measured requirements.
- Code: [`store.py`](backend/medguard/store.py), [`worker.py`](backend/medguard/worker.py), [`tests/test_mongo.py`](tests/test_mongo.py).

**Closed-loop notifications and inventory actions**

- Build a durable notification outbox with delivery, failure, retry and acknowledgement states.
- Add stock-in/stock-out/quarantine/return transactions and reconcile recorded quantities. A click on “acknowledge” must not be represented as physical recall completion.
- Add indexed, server-side pagination and filters for inventory and impact queues.
- Code: [`api.py`](backend/medguard/api.py), [`InventoryTable.tsx`](frontend/src/InventoryTable.tsx).

**Authentication and privacy**

- Replace development HTTP Basic with appropriate OIDC/session management, stronger publisher authentication, narrowly scoped roles and permission tests.
- Add upload limits, secure key rotation, backup/restore drills, audit protections and sensitive-log redaction before handling sensitive records.
- Code: [`api.py`](backend/medguard/api.py), [`store.py`](backend/medguard/store.py).

**Frontend and language quality**

- Split the large application shell into feature modules, establish reusable accessible components and typed API state, and support server-side pagination.
- Complete English/Hindi/Tamil translations using reviewed medicine-safety wording. Test camera-first mobile use, keyboard interaction, screen readers, slow networks and interrupted flows.
- Code: [`main.tsx`](frontend/src/main.tsx), [`copy.ts`](frontend/src/copy.ts), [`ScanPreview.tsx`](frontend/src/ScanPreview.tsx).

### P2 — Research extensions

**Molecular evidence:** Build a curated, reviewed drug–protein evidence catalog and a pharmacist-only hypothesis workflow. Keep experimental and predicted structures distinct and never infer a clinical interaction solely from the viewer.

## New modules and endpoints (this revision)

The eight proposed modules are now implemented as backend modules with API routes and (where applicable) frontend surfaces. All are additive: existing routes and the full original test suite remain green.

| Module | Code | API |
| --- | --- | --- |
| 1. Regulatory ground-truth library | [`groundtruth.py`](backend/medguard/groundtruth.py) | `GET/POST /api/ground-truth` |
| 2. Reviewed medicine identity registry | [`registry.py`](backend/medguard/registry.py) | `GET /api/identity/registry` |
| 3. OCR evaluation and model registry | [`ocrlib.py`](backend/medguard/ocrlib.py) | `GET/POST /api/ocr/models`, `POST /api/ocr/compare` |
| 4. Clinical rule governance | [`governance.py`](backend/medguard/governance.py) | `GET /api/clinical/rules` |
| 5. Notification outbox | [`outbox.py`](backend/medguard/outbox.py) | `GET/POST /api/outbox`, `POST /api/outbox/deliver`, `PUT /api/outbox/{id}/ack` |
| 6. Inventory transaction ledger | [`ledger.py`](backend/medguard/ledger.py) | `GET/POST /api/stock/{id}/transactions`, `/movements`, `GET /api/stock/{id}/reconcile` |
| 7. Production identity and operations | [`auth.py`](backend/medguard/auth.py) | `POST /api/session`, `GET /api/permissions` |
| 8. Product design and localization | [`api.ts`](frontend/src/api.ts), [`ClinicalRules.tsx`](frontend/src/ClinicalRules.tsx), [`Operations.tsx`](frontend/src/Operations.tsx) | typed API client + new views |

Additional P0/P1/P2 work in this revision:

- **Regulatory action verification** ([`verification.py`](backend/medguard/verification.py), `GET /api/notices/{id}/verification`): NSQ findings, recalls, spurious-product notices and prohibitions are represented as distinct action concepts with separate finding, action type, scope and authority; unsupported claims are reported for rejection.
- **Skipped-document reporting** (`GET /api/source-status` now returns `skipped_documents`): documents that could not be auto-extracted are reported for manual review rather than silently dropped.
- **Molecular evidence catalog and pharmacist-only hypothesis workflow** ([`molecular.py`](backend/medguard/molecular.py), `GET/POST /api/molecular/evidence`, `GET/POST /api/molecular/hypotheses`, `GET /api/molecular/queue`, `PUT /api/molecular/hypotheses/{id}/review`): experimental and predicted structures are kept distinct; a hypothesis requires review by someone other than its proposer and is never exposed to members.
- **Session tokens, roles and log redaction** ([`auth.py`](backend/medguard/auth.py)): opaque HMAC session tokens (Bearer) alongside HTTP-Basic; a named permission model per role; sensitive-log redaction. HTTP-Basic remains the default; Bearer is opt-in.

External-resource boundaries (implemented as code, not validated): the ground-truth library validates manifests but real adjudicated official PDFs are supplied out of band; the OCR model registry records externally provisioned weight hashes but ships no weights; clinical governance reports rule provenance but a licensed interaction database is not included; production identity provides session tokens locally and expects an OIDC provider (e.g. Keycloak) for a real deployment; MongoDB hardening keeps in-memory and real-Mongo tests, with the real-Mongo test opt-in via `MEDGUARD_TEST_MONGO_URI`.

## Modules to add (not implemented in V0)

These are proposed work packages, not finished features:

1. **Regulatory ground-truth library.** Versioned official PDFs with adjudicated document/row labels, source locations, findings and reviewer-disagreement records.
2. **Reviewed medicine identity registry.** Canonical product/manufacturer entries, aliases, composition, provenance and release versions.
3. **OCR evaluation and model registry.** Labelled image splits, baseline comparisons, weight hashes, inference configuration and optional fine-tuning experiments.
4. **Clinical rule governance.** Rule licensing, evidence citations, applicability constraints, clinician/pharmacist sign-off and scheduled review.
5. **Notification outbox.** Durable pending/delivered/failed/retried/acknowledged records and approved delivery-provider adapters.
6. **Inventory transaction ledger.** Quantity movements, quarantine/return events, actor identity and reported-versus-verified outcomes.
7. **Production identity and operations.** OIDC/MFA, permissions, monitored jobs, key management and recovery tooling.
8. **Product design and localization system.** Reusable component library, full language coverage, accessibility and visual-regression testing.

## ML and dataset status

**No MedGuard-trained or fine-tuned model is included in this repository.** The relevant distinctions are:

- **PaddleOCR:** Optional inference using externally provisioned upstream pretrained model artifacts. Model weights are not shipped here, and a representative real-pack benchmark has not been completed.
- **Regulatory PDF parsing:** Layout/table extraction and manual reviewer decisions; not a trained regulatory understanding model.
- **Pack and inventory matching:** Deterministic criteria, reviewed aliases and candidate suggestions; not an LLM classifier.
- **Regimen screening:** A small, curated rule set; not a trained interaction predictor.
- **Mechanism Lens:** Viewer of existing PDB/AlphaFold structures; no structure prediction or patient-specific inference.

Use [`tests/benchmark_ocr.py`](tests/benchmark_ocr.py) and [`tests/benchmark_regulatory.py`](tests/benchmark_regulatory.py) with **independently annotated source data** before making performance claims. Do not interpret synthetic test success or PDF proposal counts as clinical accuracy.

## Frontend direction: Evidence in Focus

The product identity should come from making evidence understandable, not from copying a generic hospital dashboard.

- **For households:** Photograph the pack → review fields against highlighted image regions → confirm identity → read a plainly worded result → open the Evidence Passport → see what to ask a pharmacist.
- **For pharmacies:** Find affected batches → inspect the source and changes → assign/review an alert → record stock actions → see an auditable outcome and what remains unresolved.
- **Distinctive interaction:** An **Evidence Passport** for each warning, displaying *where the statement came from*, *what exactly matched*, *when the source was checked*, and *what the system could not determine*.

A polished interface should also survive the boring cases: slow uploads, absent OCR weights, offline sources, stale data, session expiry, empty states and accessibility needs. Measure real-user completion and comprehension rather than judging screenshots alone.

## Open-source implementations worth studying

These are references for specific upgrades—not all dependencies of V0, and not drop-in guarantees of correctness. Review licence terms and model-weight restrictions, pin versions, and benchmark before adopting a change.

**Regulatory extraction and OCR**

- [pdfplumber](https://github.com/jsvine/pdfplumber) — Inspect text/table geometry and debug source spans in [`documents.py`](backend/medguard/documents.py); scanned PDFs still need OCR.
- [PaddleOCR](https://github.com/PaddlePaddle/PaddleOCR) — Current OCR baseline, multilingual model options, inference APIs, and documented training/fine-tuning paths.
- [docTR](https://github.com/mindee/doctr) — Independent OCR detector/recognizer baseline for medicine-image comparisons.
- [RapidFuzz](https://github.com/rapidfuzz/RapidFuzz) — Better candidate ranking for product/manufacturer variants in [`identity.py`](backend/medguard/identity.py), never automatic batch acceptance.

**Storage, jobs, security and telemetry**

- [PyMongo](https://github.com/mongodb/mongo-python-driver) — Async queries, indexes, atomic updates and query-plan analysis in [`store.py`](backend/medguard/store.py).
- [Testcontainers for Python](https://github.com/testcontainers/testcontainers-python) — Disposable database instances for realistic integration/failure tests.
- [Temporal Python SDK](https://github.com/temporalio/sdk-python) — Optional future durable-workflow approach; only consider it after measuring the limits of existing jobs.
- [Keycloak](https://github.com/keycloak/keycloak) — OIDC, user lifecycle and MFA reference for replacing development-only authentication.
- [OpenTelemetry Python](https://github.com/open-telemetry/opentelemetry-python) — Worker/source freshness, latency and failure traces with sensitive data excluded.

**Frontend and quality tooling**

- [shadcn/ui](https://github.com/shadcn-ui/ui) — Source-owned components that can be styled as MedGuard rather than as a template.
- [Radix Primitives](https://github.com/radix-ui/primitives) — Keyboard and focus foundations for overlays, dialogs and menus.
- [TanStack Query](https://github.com/TanStack/query) — Typed server-state handling, caching, retries and invalidation after updates.
- [TanStack Table](https://github.com/TanStack/table) — Inventory sorting, filters and server-backed pagination.
- [react-i18next](https://github.com/i18next/react-i18next) — Maintainable localization throughout the UI (clinical wording still needs human review).
- [Storybook](https://github.com/storybookjs/storybook) — Document and visually compare scanner/evidence components across states.
- [axe-core](https://github.com/dequelabs/axe-core) — Automated accessibility checks, supplemented by manual tests.
- [Playwright](https://github.com/microsoft/playwright) — Cross-browser journeys and visual regression.
- [Mol*](https://github.com/molstar/molstar) — Molecular viewer integration and provenance display, not pharmacological proof.

**Regulatory information:** [CDSCO alerts](https://www.cdsco.gov.in/opencms/opencms/en/Notifications/Alerts/) and [CDSCO Gazette notifications](https://www.cdsco.gov.in/opencms/opencms/en/Notifications/Gazette-Notifications/) are possible primary sources, not GitHub packages. Verify scope and availability independently and keep source copies/hashes for evaluation. FHIR/CDS Hooks/OHDSI can help with interoperability, but do not supply a complete licensed Indian interaction database.

## Development sequence

Use small, reviewable changes and attach an evidence trail to each milestone.

1. **Freeze the baseline.** Tag this V0 archive, preserve fixtures, pin dependencies and record current tests and limitations.
2. **Prove regulatory correctness.** Annotate representative official PDFs; measure document and row errors, source scope and reviewer agreement.
3. **Prove medicine identification.** Benchmark OCR and alias candidates on held-out photos; optimize incorrect confident batch handling and correction time.
4. **Prove surveillance reliability.** Run a real MongoDB test server, interrupt workers, replay jobs and measure duplicate/missing impacts and query latency.
5. **Govern clinical rules.** Review licensed evidence with a qualified professional; version the rules and test edge cases.
6. **Refine the product experience.** Split feature code, build the Evidence Passport system, localize all screens and conduct real usability/accessibility studies.
7. **Prepare for a controlled pilot.** Only after security, operational recovery, clinical oversight and regulatory requirements are addressed.

For each change, record: **problem → baseline → modification → test dataset → results → remaining failures → rollback plan**.

## Reference documentation

- [Architecture](docs/ARCHITECTURE.md) and [Research](docs/RESEARCH.md)
- [Validation plan](docs/VALIDATION.md) and [Test report](docs/TEST_REPORT.md)
- [Clinical rule review](docs/CLINICAL_RULE_REVIEW.md) and [CDSCO extraction probe](docs/CDSCO_PROBE.json)
- [V0 audit response](docs/V0_AUDIT_RESPONSE.md)
- Historical development notes: [V3](docs/V3_REGULATORY_MILESTONE.md), [V4](docs/V4_VALIDATION.md), [V5](docs/V5_VALIDATION.md), [V6](docs/V6_AUDIT_RESPONSE.md), [V7](docs/V7_MONGO_CDSCO.md), [V8](docs/V8_AUDIT_RESPONSE.md)

---

## Run MedGuard locally

### Requirements

- **Python 3.13** and **Node.js 22.12+ or 24** with npm.
- Internet access for the initial dependency installation. The default demo does **not** require MongoDB, model weights, or a cloud account.
- Use commands from the extracted `MedGuard-V0/` directory unless stated otherwise.

### 1. Start the backend — Windows PowerShell

```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
$env:MEDGUARD_DEMO = '1'
.\.venv\Scripts\python.exe -m uvicorn --app-dir backend medguard.api:create_app --factory --host 127.0.0.1 --port 8000
```

For **macOS/Linux**, use this equivalent:

```bash
python3.13 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
export MEDGUARD_DEMO=1
python -m uvicorn --app-dir backend medguard.api:create_app --factory --host 127.0.0.1 --port 8000
```

### 2. Start the frontend — second terminal

```bash
cd frontend
npm ci
npm run dev
```

- App: **http://127.0.0.1:5173**
- API: **http://127.0.0.1:8000**
- API docs: **http://127.0.0.1:8000/api/docs**

### 3. Sign in with demo users

All four accounts below use the password **`medguard-demo`** and exist only with `MEDGUARD_DEMO=1`.

- `household` — member account on the demo tenant.
- `reviewer` — publisher on the demo tenant.
- `second-reviewer` — separate publisher for notice approval.
- `pharmacy` — member on a separate pharmacy tenant, useful for isolation checks.

### 4. Try the core workflows

1. **Pack Check:** Enter product `Monopropylene Glycol USP`, manufacturer `Shell Eastern Chemicals`, and batch `9971702044`. Inspect the historical demo evidence. Then remove the manufacturer or change the batch to observe uncertainty and different-batch behavior.
2. **Regimen Check:** Use fictional products whose confirmed ingredients are `clarithromycin` and `simvastatin`. Observe the example warning and the uncovered-pair statement. A separate sample uses `hydroxyzine hydrochloride`, tablet form, at age 65+.
3. **Facility:** Save a confirmed pack to inventory, review its impact and record an acknowledgement. Log in as `pharmacy` to confirm the other tenant's records are not shown.
4. **Evidence desk:** Review notice metadata as `reviewer`; an independent `second-reviewer` is required to approve a properly documented notice. Avoid patient data and do not treat a sample notice as a live recall.
5. **Accessibility and structures:** Switch result language among English/Hindi/Tamil, try local browser speech if a suitable voice is installed, and open the Mol* educational viewer (requires network and WebGL).

The in-memory metadata resets on restart. Locally stored encrypted evidence can remain in `.evidence/`; avoid uploading sensitive content.

### 5. Run tests and benchmarks

**Backend (Windows PowerShell, from project root):**

```powershell
$env:PYTHONPATH = 'backend'
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe tests/benchmark_matching.py
.\.venv\Scripts\python.exe tests/benchmark_candidates.py
```

On macOS/Linux use `export PYTHONPATH=backend` and `python` after activating the environment.

**Frontend:** Stop manually started servers before Playwright tests; the test configuration starts its own servers on ports 8000/5173.

```powershell
$env:PATH = (Resolve-Path .venv/Scripts).Path + ';' + $env:PATH
cd frontend
npm ci
npm run build
npx playwright install chromium
npm test
```

**Dedicated MongoDB tests (optional):** The test creates and later drops a random database. Never point this at a production/app database.

```powershell
$env:MEDGUARD_TEST_MONGO_URI = 'mongodb://127.0.0.1:27017'
$env:PYTHONPATH = 'backend'
.\.venv\Scripts\python.exe tests/mongo_preflight.py
.\.venv\Scripts\python.exe -m pytest -q tests/test_mongo.py
```

**Regulatory and OCR evaluations (optional):** Require your own annotated, local source files and appropriately provisioned model weights.

```powershell
$env:PYTHONPATH = 'backend'
.\.venv\Scripts\python.exe tests/benchmark_regulatory.py path/to/annotated_manifest.json
.\.venv\Scripts\python.exe tests/benchmark_regulatory.py path/to/annotated_manifest.json --baseline
.\.venv\Scripts\python.exe tests/benchmark_ocr.py path/to/image_manifest.json
```

See the benchmark scripts for the exact manifest fields. A successful benchmark script on synthetic cases is not evidence of real-world clinical performance.

### 6. Optional persistent MongoDB mode

Demo mode must be **unset** (`Remove-Item Env:MEDGUARD_DEMO -ErrorAction SilentlyContinue` in PowerShell). Configure these environment variables before starting the backend:

- `MEDGUARD_MONGO_URI` — MongoDB URI, including Atlas TLS settings where relevant.
- `MEDGUARD_DATABASE` — database name (defaults to `medguard`).
- `MEDGUARD_ENCRYPTION_KEY` — persistent Fernet key, managed securely; losing it makes encrypted records unreadable.
- `MEDGUARD_PREVIOUS_ENCRYPTION_KEYS` — optional older read keys for a controlled rotation.
- `MEDGUARD_INDEX_KEY` — optional stable HMAC candidate-index secret; at least 32 bytes if set.
- `MEDGUARD_ACCOUNTS` — path to an account JSON mapping usernames to Argon2id `hash`, `tenant`, and `role` (`member` or `publisher`).
- `MEDGUARD_IDENTITY_CATALOG` — optional reviewed aliases file.
- `MEDGUARD_SOURCE_URLS` — space-separated configured official HTTPS notice PDFs/archive pages.
- `MEDGUARD_EVIDENCE_DIR` — encrypted local evidence directory (default `.evidence`).
- `MEDGUARD_S3_BUCKET` — optional private S3 bucket for encrypted evidence; also requires standard AWS credentials.
- `MEDGUARD_WORKER_MODE` — `embedded` (default) or `external`.

Generate a new Fernet encryption key locally and store it in an appropriate secrets manager (do **not** commit the generated key):

```powershell
.\.venv\Scripts\python.exe -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
```

Generate a password hash locally without putting the password in your shell history:

```powershell
.\.venv\Scripts\python.exe -c "from argon2 import PasswordHasher; import getpass; print(PasswordHasher().hash(getpass.getpass('New password: ')))"
```

The file referenced by `MEDGUARD_ACCOUNTS` has this shape (example only):

```json
{
  "sample-reviewer": {
    "hash": "<your-argon2id-hash>",
    "tenant": "research-lab",
    "role": "publisher"
  }
}
```

For a separate worker, configure both terminals identically (including database, secrets and identity catalog), set `MEDGUARD_WORKER_MODE=external`, and run:

```powershell
# Terminal A — API
$env:MEDGUARD_WORKER_MODE = 'external'
$env:PYTHONPATH = 'backend'
.\.venv\Scripts\python.exe -m uvicorn --app-dir backend medguard.api:create_app --factory --host 127.0.0.1 --port 8000

# Terminal B — worker (in a separate shell with the same environment)
$env:MEDGUARD_WORKER_MODE = 'external'
$env:PYTHONPATH = 'backend'
.\.venv\Scripts\python.exe -m medguard.worker
```

This is a development persistence path, not authorization to use real pharmacy/patient data. Validate permissions, security, failure recovery and backup restoration first.

### 7. Optional pretrained OCR

Install the OCR-specific packages in an environment compatible with the chosen PaddlePaddle runtime:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-ocr.txt
```

Download compatible upstream inference artifacts, verify their source/version/licence and recorded hashes, then point MedGuard at local model directories:

```powershell
$env:MEDGUARD_OCR_DETECTOR = 'C:\models\ppocr-det'
$env:MEDGUARD_OCR_EN = 'C:\models\ppocr-en'
$env:MEDGUARD_OCR_HI = 'C:\models\ppocr-hi'
$env:MEDGUARD_OCR_TA = 'C:\models\ppocr-ta'
```

These are **example paths**, not directories supplied with this repository. Restart the backend after configuring them. Manual medicine entry remains available when OCR is not configured.

### 8. Optional Docker demo

```bash
docker build -t medguard .
docker run --rm -p 127.0.0.1:8000:8000 -e MEDGUARD_DEMO=1 medguard
```

Open **http://127.0.0.1:8000**. The Dockerfile builds the frontend and serves it through FastAPI in demo mode. **This is not a production deployment recipe**, and the Docker build has not been independently reproduced for this README revision.

---

**Contribution standard:** Keep V0 as a reproducible reference, make changes in reviewable increments, and treat every new capability as incomplete until its real inputs, failure cases, benchmarks and safety limits are documented.
