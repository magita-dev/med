# MedGuard architecture

```mermaid
flowchart LR
  A[CDSCO and eGazette] --> B[Publisher reviews official notice and scope]
  B --> C[Immutable version with source and SHA-256]
  B --> D[Encrypted evidence object]
  E[Pack or prescription photo] --> F[Local OCR]
  F --> G[Human checks original and confirms identity]
  G --> H[Deterministic pack check]
  G --> I[Encrypted tenant stock]
  G --> J[Regimen screen]
  C --> H
  C --> K[Versioned tenant review queue]
  I --> K
  K --> L[Append-only acknowledgement]
  M[Curated label rules] --> J
  H --> N[Source-linked text and local voice]
  J --> N
  K --> N
  O[PDB and AlphaFold] --> P[Separate educational viewer links]
```

```mermaid
sequenceDiagram
  actor Publisher
  participant API
  participant Evidence
  participant DB as MongoDB or in-memory demo
  actor Household
  Publisher->>API: Upload PDF, reviewed fields, stable notice key and revision
  API->>Evidence: Encrypt and write digest-addressed bytes
  API->>DB: Insert immutable revision
  Household->>API: Request inventory review queue
  API->>DB: Read tenant stock and applicable revisions
  API->>API: Decrypt stock and evaluate criteria
  API-->>Household: Exact and uncertain evidence results
  Household->>API: Acknowledge stock and notice revision
  API->>DB: Insert unique tenant-stock-revision event
```

## Boundaries

- Global regulatory notices are public-source metadata. Publishers can add immutable revisions. Every notice stores provenance and a publisher attestation. Human review is the trust boundary and an official URL alone cannot authenticate uploaded bytes.
- Private stock is encrypted as a record. The server decrypts for matching. Tenant IDs are derived from authenticated account configuration and used for every private read/write. No batch is hashed as a substitute for comparison.
- Stock registration and publication materialize idempotent, revision-scoped impacts. A periodic reconciliation pass retries interrupted work and processes newly effective notices. Review reads filter impacts to current revisions. The worker builds an in-memory product/composition candidate index and scans encrypted stock. Large deployments still need bounded batching and persistent job coordination.
- Stock POST-equivalent writes and acknowledgements use insert-if-absent IDs. Evidence blobs can be orphaned by rejected revisions or database failures. A future retention job must preserve all referenced digests. Acknowledging means a reviewer saw a specific result. It is not a recall resolution.
- Scope is intentionally strict. Exact means agreement with modeled fields. An unknown required field yields uncertain when the comparison has an anchor. Different product names and ingredient sets currently need manual reconciliation. For affected stock this can reduce sensitivity.
- The initial scope model supports one product, one batch or one FDC composition plus literal form/strength scope per row. Split multi-lot notices into separately reviewable rows. Complex legal exceptions and per-ingredient strength mapping need a formal structured schema before onboarding them.
- Educational references are outbound links. The browser sends no stock, OCR payload or regimen to the molecule providers.
