# v8 audit corrections

## Delivered

- The scan workspace displays the uploaded image, overlays OCR polygons and lets a reviewer select a detected line by keyboard or pointer. Fields remain editable and require human confirmation. Server-side OCR normalizes EXIF orientation to align with the displayed image.
- Evidence Passport presents match status, field criteria, evidence classification, source locator, dates and digest. Inventory uses a searchable, labelled table. These are separate React components. Authentication and feature state are still managed by the original app shell.
- Approval rejects duplicated or missing extracted row locators before comparing fields. Source semantics and scope still depend on independent human review.
- The real-document probe records hashes, page and proposal counts, duplicate printed serials and numbering gaps. The two June 2025 PDFs produced 55 central and 130 state proposals, with no duplicate or skipped serials through the highest extracted serial in either file. This does not verify field accuracy or completeness against independent ground truth.
- The live local MongoDB 8.0.38 suite passed 23 backend tests, including concurrent claims, index selection, lease recovery and tenant queries. Four batch subtests also passed. TypeScript/Vite built successfully and four Edge workflows passed, including Evidence Passport assertions. The hosted Mol* response and OCR results in browser tests used fixtures.

## Validation still required

Actual CPU inference ran on one synthetic fixture per language. All three models proposed `001-0A` for the printed `O01-0A`, with batch-line confidence of approximately 95.6% (English), 97.6% (Hindi) and 95.7% (Tamil). Exact batch accuracy was 0/3 on this deliberately confusable fixture. The scan form now leaves OCR suggestions containing O/0 or I/1/l out of the batch input, while retaining the visible source lines. This guard does not guarantee accurate transcription or detect all OCR errors.

Official PP-OCRv5 detector and English, Devanagari and Tamil recognizer files were downloaded. Their local SHA-256 fingerprints are in `OCR_SHA256.txt`. Install the optional pinned runtime and point the four OCR environment variables to the corresponding model directories. Set `PADDLE_PDX_CACHE_HOME` to a writable directory if the user profile is restricted. `tests/ocr_smoke.py LANGUAGE FONT_FILE` generates a synthetic label and checks the exact batch output. This does not estimate performance on real packaging.

Atlas failover under load, high-volume paginated review endpoints, OIDC/MFA and assigned pharmacist permissions, external delivery, independent CDSCO annotations, representative English/Hindi/Tamil pack photos, an OCR model comparison, independent clinical and translation review, and a pharmacist molecular evidence queue remain open. See the clinical release gate for the required rule inputs. The three demonstration rules remain the clinical coverage.

[Official PaddleOCR recognition documentation](https://www.paddleocr.ai/main/en/version3.x/module_usage/text_recognition.html) · [docTR model documentation](https://mindee.github.io/doctr/latest/using_doctr/using_models.html)
