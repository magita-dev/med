# Regulatory ingestion, review and stock impacts

The watcher discovers direct notice PDFs under the CDSCO alert and Gazette upload directories from a configured official archive page. It also accepts configured official PDF URLs directly. Each check follows up to 20 recognized links per configured archive, rejects redirects and bounds response size. Captures store original encrypted bytes, source URL and digest. A recognized NSQ table produces candidate product, manufacturer and lot values with page and printed row. Other layouts enter manual review. Scanned documents and FDC legal scope require human extraction and review.

Publisher uploads are drafts. A draft can be publisher-attested or source-observed. A second publisher reviews the exact revision and can activate it only after the official fetch recorded a matching digest for the draft URL and stored bytes pass integrity verification. Existing self-attested records are excluded from active matching. To migrate an immutable legacy revision, submit the official document under the next revision number and use independent approval. Historical and synthetic fixtures remain limited to demo mode.

Publication creates revision-specific stock impacts. Replay is idempotent and periodic reconciliation repairs missed work. Alerts appear in the authenticated stock review queue. External notification delivery remains open.

## Gates for later phases

- Validate live official source fetches, revisions and extraction on a held-out set of actual PDFs. Include split tables, scanned pages, revised notices, spurious label claims and conflicting lots. The first 20 linked documents limit means the watcher does not guarantee full archive coverage.
- Build a versioned identity catalog with official or otherwise licensed sources and pharmacist adjudication. Exact aliases include the product and manufacturer pair. Fuzzy discovery only returns candidates. Verify against independently held-out spelling, strength and lot cases before rollout.
- Run the real MongoDB CI job and Atlas integration with concurrent publishing, restart/reconciliation, indexes and recovery. Validate S3 integrity and retention independently.
- Freeze an image evaluation corpus of authorized non-patient medicine packs and score exact product, manufacturer and batch extraction by script and image condition.
- For clinical rules, obtain redistribution and execution rights before importing any licensed interaction dataset. Record jurisdiction, formulation, route, rule version, cited section, review date and independent clinical approval per rule. Test contraindications and exclusions against an independently adjudicated reference set. The current UI reports that selected US label rules leave other interactions unassessed.
- For facility closure, add a tenant-scoped quantity ledger, authorized corrections, reconciliation with external inventory and explicit verification records. The current outcome records a staff statement about physical activity.
- Production security, browser accessibility, embedded molecular visualization and pharmacist hypothesis review remain later phases.

## Verification

The full in-process backend run passed 15 tests and four batch-identity subtests. The MongoDB test skipped without a test URI. The ingestion suite then passed all four cases, including the added encrypted capture and replay case. These runs used a socket-free test event loop in the restricted Windows environment. Python compilation and the TypeScript/Vite production build passed. The matching benchmark reproduced 10,000 expected synthetic outcomes. The source monitor was exercised with mocked HTTP responses and synthetic parser inputs. The direct historical CDSCO PDF timed out during source re-check. Live capture-to-publication, real MongoDB, field OCR, and updated browser automation remain unverified.

[CDSCO official alerts archive](https://www.cdsco.gov.in/opencms/opencms/en/Notifications/Alerts)
