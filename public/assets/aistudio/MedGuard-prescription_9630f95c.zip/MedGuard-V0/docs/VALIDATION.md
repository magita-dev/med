# Phased validation and release gates

| Phase | Verification |
|---|---|
| 1. Synthetic engineering | Deterministic decision table, API authorization, revision and retry tests, evidence digest and encryption round trip, Playwright flow. |
| 2. Retrospective evidence | Archive versioned primary source documents. Have two independent reviewers annotate page/row, manufacturer role, exact batch, revisions and FDC scope. Adjudicate disagreements and test all unresolved cases as abstentions. License each extract before redistribution. |
| 3. OCR field evaluation | Start with non-patient agreed-use packaging and generated prescriptions. Hold out pack families and stratify by script and image defects. Retain only consented source material. Report field error, reviewer corrections and false exact matches after confirmation. Test local runtime resource limits. |
| 4. Shadow-mode pilot | Obtain institutional review as applicable. Test Atlas, external blob storage, traceability, key rotation, backup/restore, concurrency, authorization, document isolation and WCAG checks. Independently review label mappings and Tamil/Hindi copy. Validate triage latency and reviewer workload against preregistered targets. |
| 5. Operational readiness | Add ongoing regulatory feed monitoring, freshness metrics, expiry/retraction handling, two-person publication controls, access lifecycle, operational alerts and approved communications. Verify legal/clinical scope and consent before collecting patient data. |

Candidate gates for phase 2 include zero false exact matches on the held-out wrong-batch and wrong-manufacturer corpus and 100% traceability to the cited row. Report confidence intervals and adjudication policy. Select recall and reviewer-burden thresholds with participating institutions. Targets from the infographic include pack p95 below 1 s and regimen p95 below 3 s. Run full-stack load tests separately from the microbenchmark and include OCR separately.

## Known coverage gaps

- The supplied historical NSQ row and FDC prohibition are source-derived fixtures. The January NSQ archive also lists revisions. The synthetic FDC fixture exercises strength and form. No comprehensive live feed, Gazette exception processing, durable delivery, stock disposal workflow, or externally licensed interaction coverage is supplied.
- Pack matching requires the same recorded product name after conservative normalization. Brand synonyms, manufacturer aliases/address variants, uncertain product OCR, and catalog linking need adjudicated data. Case is preserved for batch. Never upgrade a fuzzy guess into exact identity.
- Image OCR is optional. Explicitly labeled high-confidence lines can populate editable proposals. Conflicting candidates require manual entry. The project has no evaluated handwriting recognizer and rejects PDFs at the image endpoint. Admin PDF extraction is separately scoped.
- Clinical examples use US labels. Ingredient entry is manual, and age, formulation, and other clinical context may be incomplete. A duplicate ingredient is a review cue. Translation and clinical utility still require independent review.
- Local installed speech voices vary. The app uses local service voices only. Navigation and administration are in English. Mechanism Lens uses external hosted visuals.
- The persistent adapters require separately provisioned Atlas and S3. Demo uses in-memory metadata and locally encrypted evidence. HTTP Basic plus Argon2id is a development/controlled environment path. Before production add TLS termination, throttling, credential revocation and preferably short-lived OIDC sessions. Limit request sizes at the edge before multipart parsing and isolate file processing in sandboxed workers. Add service health/queue freshness checks, role lifecycle, key rotation, and external audit retention before handling patient data.
