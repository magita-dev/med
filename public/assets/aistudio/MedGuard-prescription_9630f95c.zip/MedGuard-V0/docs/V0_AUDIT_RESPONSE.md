# MedGuard V0

V0 is the release name for development revision nine. The v8 package is preserved.

## Regulatory evaluation

The benchmark scores exact rows including the regulatory finding, reports field discrepancies and missing locators, and uses the same 80-page extraction limit as ingestion. Run against a SHA-256-locked manifest with source_page, locator, product, manufacturer, batch and finding per annotated row. Run again with --baseline for page-local heading detection.

On the original June 2025 CDSCO documents, the isolated page-header baseline found 8 central and 9 state proposals, compared with 55 and 130 using continuation-aware parsing. Independent ground truth was unavailable, so field precision and recall remain unmeasured.

New approvals record source-byte comparison, transcription validation and reviewer-attested scope separately. The Evidence Passport displays these distinctions. Scope remains a regulatory interpretation requiring qualified human review.

## OCR and interface

The image benchmark counts raw exact/wrong/missing proposals, guarded abstentions, wrong proposals blocked and wrong autofills. No representative real-pack corpus was available. The prior English/Hindi/Tamil stress result remains 0/3 on one deliberately confusable batch fixture. No model replacement or fine-tuning was performed.

The scan view links a focused field to its single detected image line when available, offers zoom and includes image-quality guidance. Inventory supports sorting and twenty-row pages on locally loaded records. The Evidence Passport labels notice types and displays follow-up guidance.

## Reproduction and open gates

CI retains backend and MongoDB JUnit results and the browser report. Fixture-backed browser coverage does not validate externally hosted Mol* or field OCR.

Local test run: 23 backend tests and four batch subtests passed against a suite with local MongoDB 8.0.38 enabled. This verifies local integration and lease behavior within the covered tests. It does not measure Atlas failover or deployment performance.

Independent regulatory annotations and real pack photos, alternative OCR-model comparison, licensed clinical rules, Atlas failover, server-side pagination, external delivery, physical stock reconciliation, OIDC/MFA, accessibility and multilingual usability studies, and the pharmacist mechanism workflow remain open.

[CDSCO alert archive](https://www.cdsco.gov.in/opencms/opencms/en/Notifications/Alerts)
