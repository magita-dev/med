# MedGuard v4 audit response

## Evidence and surveillance

New approvals require a numbered PDF page and the existing precise row or scope locator. When an active NSQ notice has extracted rows, the cited page, locator, product, manufacturer and batch must agree with one row in the captured document. The approved evidence records `extracted_row_matched` or `manual_scope_review` and retains submitter, approver and timestamps. The automated comparison checks transcription against extraction. Independent reviewers remain responsible for checking the original PDF and interpreting scope. Drafts from v3 without a page need resubmission under a new revision. Older captures are re-extracted on the next successful source check.

MongoDB surveillance streams stock through a batched cursor rather than materializing the entire inventory. The in-memory product and composition candidate index is still used. The opt-in Mongo test now covers cursor iteration after reopening a client. The worker still performs a full stock scan and lacks distributed checkpoints or a durable notification outbox.

## Held-out regulatory evaluation

Prepare a JSON array of official documents. Give each entry `source` (official URL), `file` (relative local PDF path), `sha256` (lowercase digest), and `rows` (independently annotated rows, each with `source_page`, `locator`, `product`, `manufacturer` and `batch`). Include documents with no expected NSQ rows. Keep PDFs and annotations outside the application fixtures. Run from the root with `PYTHONPATH=backend` using `python tests/benchmark_regulatory.py path/to/manifest.json`. The benchmark reports exact row precision, recall and unavailable documents. An unavailable document counts against recall for its annotated rows. Compare discovered links separately to an independently frozen archive inventory.

The harness is supplied. No held-out regulatory corpus, field OCR corpus, independently labelled Indian identity catalog or professionally reviewed new clinical data was available for this release. Regulatory, OCR, identity and clinical field accuracy remain unmeasured. Atlas recovery and concurrent publication, distributed surveillance, stronger reviewer authentication and browser accessibility remain open.

## Mechanism Lens

The React component embeds the hosted Mol* viewer on demand. It switches between the experimental CYP3A4 PDB record and the AlphaFold prediction, labels their methods and limitations, and provides a separate-tab fallback. Only public accession identifiers go to the viewer. Live rendering requires network access and a compatible browser. There is no embedded hypothesis review workflow or clinical rule derived from the viewer.

[Mol* viewer parameters](https://molstar.org/viewer-docs/query-parameters/) · [RCSB 1TQN](https://www.rcsb.org/structure/1TQN) · [AlphaFold P08684](https://alphafold.ebi.ac.uk/entry/P08684)
