# Clinical rule release gate

The three included rules are explicitly limited to demonstration coverage and remain linked to their cited US labels. Continue showing unassessed pairs and missing ingredients. Molecular evidence stays outside this ruleset.

Each proposed rule needs a stable ID and revision, source version and locator, redistribution and execution rights, jurisdiction, canonical ingredients and formulation, route, dose, age or population constraints where applicable, a structured decision table and expiry or re-review date. An independent pharmacist must approve the interpretation and test positive cases, exclusions, missing inputs, and boundary values before a production knowledge release.

Vendor data, Indian formulation mappings and adjudicated test cases were unavailable for v8. No new interactions were added.
