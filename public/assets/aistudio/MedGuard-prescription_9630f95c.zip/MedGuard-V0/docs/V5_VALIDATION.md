# v5 validation and release gates

v4 is the preserved baseline. v5 advances the five workstreams in the requested order. Current results are engineering evidence from controlled inputs.

| Scope | Implemented in v5 | Required independent acceptance test |
|---|---|---|
| M1 + M5 | Manual evidence requires a real, readable PDF page, a bounded normalized rectangle and two attestations. If the rectangle has a text layer and a batch is claimed, the exact printed batch must appear. Human-reviewed extraction carries its own evidence status and can only trigger follow-up, including when pack criteria otherwise agree exactly. Old manual approvals are excluded without reviving superseded versions. | Download and hash a stratified corpus including central and state NSQ, revisions, scans and Gazette notifications. Have two annotators review scopes and page locations. Run `tests/benchmark_regulatory.py` and measure missing documents, row precision and recall. |
| M2 | Added Hindi, Tamil and abbreviated batch labels while preserving confusable characters. Added field-level benchmark tooling. | Use independently annotated Indian pack photos without patient data. Include different brands, multiline manufacturers, glare, blur, rotations and each supported script. Measure exact field accuracy, missing and wrong values, and downstream false or missed batch matches. |
| M4 + M8 | Added revision-scoped jobs, worker leases, persisted checkpoints, idempotent impacts and a tenant-scoped in-app notification count. Acknowledgement clears an unread notification and recorded facility responses remain auditable. | Run on MongoDB against concurrent workers and interruptions around impact creation and checkpointing. Measure throughput and backlog. Verify external delivery retries in a test channel and reconcile physical inventory with independent confirmation. |
| M3 | Report entered ingredient pairs with no loaded interaction rule and products with missing ingredients. | Acquire licensed data with documented jurisdiction, formulation and dosing context. Independent clinical reviewers adjudicate result and coverage on reference cases. Current coverage remains three demonstration rules. |
| M6 + M7 | Added a cited educational clarithromycin–CYP3A4–simvastatin relationship alongside the embedded structures. | Review the educational interpretation independently, validate viewer and local speech across browsers, test keyboard and screen-reader tasks in the supported languages, and evaluate a pharmacist hypothesis workflow once implemented. |

## Evidence review and job behavior

Submit `evidence_span` as normalized PDF coordinates `[left, top, right, bottom]` with top-left origin and `submitter_attests_span: true`. A second publisher approves with `reviewer_attests_span: true`. The structured NSQ route still verifies the cited parser row and page. An image-only span relies on both humans for visual transcription; approval records this explicitly. Manual notices can surface possible impacts for follow-up. They cannot produce an exact pack finding.

An active revision creates a job keyed by notice revision. Claims use an atomic MongoDB update and renew a two-minute lease with each saved checkpoint. Impacts are written before the checkpoint so interruption can replay safely. Each new stock insert also has a recovery marker for missed inline matching. Expired workers cannot advance another worker's checkpoint. Reconciliation still scans stock by indexed document ID, without a medicine candidate index. A periodic worker resumes jobs in the app process. No email or SMS delivery is configured. No claim of physical recall closure follows from a recorded response.

For OCR, the manifest is an array of entries with `file` relative to the manifest, `language` (`en`, `hi`, or `ta`), `condition`, and `fields` mapping field names to exact expected strings or null. Run `python tests/benchmark_ocr.py manifest.json` with `PYTHONPATH=backend` and local OCR models configured. Review failures and confusions separately.

## Source leads for the held-out corpus

The CDSCO archive lists central and state files, spurious notices and revised alerts. The June 2025 central PDF is a candidate, with a text-layer table in the indexed copy. The direct PDF download failed DNS resolution in the workspace and the automatic permission policy rejected escalation. No local bytes, real-data extraction metrics or independent reviewer annotations are claimed.

[CDSCO Alerts archive](https://www.cdsco.gov.in/opencms/opencms/en/Notifications/Alerts) · [June 2025 central NSQ PDF](https://cdsco.gov.in/opencms/resources/UploadCDSCOWeb/2018/UploadAlertsFiles/CDSCO%20NSQ%20june25.pdf)

[DailyMed mechanism evidence](https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=5047246b-310f-5ae0-e054-00144ff8d46c)
