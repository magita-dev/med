# Engineering test report

## v6 checks

- Backend: 21 passed, four subtests passed, one live MongoDB test skipped without a test URI. In-process Windows event-loop workaround was used.
- TypeScript/Vite production build and Python compilation passed. Current browser E2E and live Mol* rendering were not verified.
- Synthetic candidate benchmark returned identical impacts for indexed and full matching at 1,000, 10,000 and 100,000 records. The index selected 2, 20 and 200 candidates respectively. This fixture uses evenly distributed product names. It excludes index construction, encryption, MongoDB, concurrency and network overhead.

## v5 checks

- 19 backend tests and four batch subtests passed using the in-process Windows test runner. The opt-in MongoDB test skipped because no test URI was provided. Python compilation passed.
- TypeScript and Vite production build passed. Playwright discovered four workflows. Browser execution and live rendering remain unverified.
- The 10,000-case synthetic matching benchmark reproduced all expected outcomes. No live source, OCR or clinically reviewed evaluation was performed.

## v4 release checks

- Backend: 16 passed, four batch subtests passed, one MongoDB integration test skipped without a test URI. Python compilation passed. In-process testing used a socket-free Windows test event loop.
- Frontend: TypeScript and Vite production build passed. Playwright discovered four workflows, including on-demand Mol* switching. Browser execution and live WebGL rendering were not verified.
- Real regulatory PDFs, Atlas, real-image OCR, clinical validation and external notification delivery remain open. See [the v4 audit response](V4_VALIDATION.md).

## Original prototype run

Run on 14 November 2026 using synthetic accounts and inventory, historical CDSCO fixtures, Python 3.13, Node 24, and installed Microsoft Edge.

| Check | Result |
|---|---|
| pytest unit and API integration | 8 passed, including 4 passing batch-identity subtests. Covered active revisions, exact/uncertain criteria, strength order, geriatrics, stock retries, role restrictions, tenant isolation, cross-tenant acknowledgement denial, SHA-256, encrypted object storage round trip and tamper handling. |
| React TypeScript and Vite build | Passed, Vite 7.3.8. |
| Playwright on Edge | 2 passed. Confirmed pack → CDSCO source → Tamil result → stock → acknowledgement, and pharmacy sign-in → curated regimen finding → label citation → isolated inventory. |
| npm install advisory check | 0 vulnerabilities reported at installation time. This is limited to the npm advisory database. |
| Synthetic benchmark | 10,000 deterministic comparisons. Product-only baseline gave 4,000 false exact exclusions and 2,000 false exact uncertain cases. Criterion matching produced 2,000 correct exact, 6,000 correct exclusions, and 2,000 correct uncertain results. Median comparison time 0.70 µs baseline and 1.90 µs criterion matching. |

The benchmark encodes five equally represented synthetic scenarios. It measures decision semantics against a simple baseline, with no estimate of field precision, OCR accuracy, clinical utility, or application latency. The browser suite uses the in-memory demo. Atlas and S3 were not connected. Paddle weights, PyMuPDF, local voices, translations with independent reviewers, live source changes, and external molecular services were not validated by the suite.

## Failure log

| Observation | Disposition |
|---|---|
| Restricted environment prevented package DNS and blocked the Windows event loop's loopback socket. | Dependency install and local test runs succeeded with network access enabled. |
| TypeScript rejected a form event target cast. | Used DOM type narrowing and rebuilt successfully. |
| Initial generated PDF stream length was hardcoded incorrectly and extracted empty text. | Derived the byte length from the actual stream. The parser test then extracted the expected text and passed. |
| Starlette reports an HTTPX test client deprecation on the resolved versions. | Tests run successfully. Track the test transport migration when locking the Python toolchain. |
| CDSCO public NSQ portal timed out during source review. | Used the official archive and direct Gazette documents. Live portal ingestion remains untested. |
