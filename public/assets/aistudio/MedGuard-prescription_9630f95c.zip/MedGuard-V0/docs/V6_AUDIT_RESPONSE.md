# v6 validation-focused upgrade

v5 is the baseline. This release implements selected findings from both audits. Completion still depends on the external datasets, services and independent reviews below.

| Area | Delivered | Open |
|---|---|---|
| Regulatory and evidence | Header-mapped NSQ columns, 80-page capture limit, last successful fetch and failure status, text-span checks for product, manufacturer and exact batch. Image-only manual evidence remains uncertain. | Independently annotated CDSCO/Gazette corpus, scanned-document OCR, broader archive coverage, field-specific geometry and reviewer disagreement workflow. |
| Pack OCR and identity | Retained conservative confirmation and version-scoped candidate indexing. Catalog changes cause inventory reindexing and new surveillance checkpoints. | Indian pack corpus, model comparison, catalog adjudication and measured missed/false matches. |
| Surveillance | MongoDB compound candidate index, encrypted payloads, lease/checkpoint reuse and optional separate worker process. | Real MongoDB execution, query plans, multi-worker throughput and restart tests, external delivery and provider acknowledgements. |
| Security | Database ping and worker heartbeat. Optional previous Fernet keys enable old ciphertext reads during staged key rotation. | OIDC/MFA, finer permissions, managed key integration and verified backup/restoration and re-encryption. |
| Facility | Existing tenant-scoped acknowledgement, in-app notification and recorded responses. | Verified physical movement and quantity ledger. |
| Regimen, language and molecular evidence | Existing coverage disclosure and educational structure boundary. | Licensed evidence, pharmacist rule review, validated translations, accessibility tests and mechanism hypothesis queue. |

## Operation

Set `MEDGUARD_WORKER_MODE=external` for persistent API serving and run `python -m medguard.worker` separately with `PYTHONPATH=backend`. Use the same MongoDB, evidence storage, source URLs, account configuration, encryption and catalog settings on both processes. Keep coordinated index settings across workers during rollout. Optional `MEDGUARD_INDEX_KEY` must be at least 32 bytes. Otherwise the index uses the primary encryption-key material with a purpose-specific HMAC input prefix. Candidate tokens reveal equality within a deployment. They narrow retrieval by canonical product or FDC composition. Manufacturer/batch remain exact verification criteria on decrypted data so missing manufacturer cannot hide a possible impact. Older stock is included as a fallback until reindexed. There is no claim that MongoDB selected a particular query plan.

`MEDGUARD_PREVIOUS_ENCRYPTION_KEYS` accepts space-separated old Fernet keys. New data is encrypted with the primary key; reads try the remaining keys. Keep old keys until encrypted inventory, notes and evidence have been migrated or retired. Key rotation and restoration are operational gates, not measured outcomes.

Source freshness is a fetch signal for the configured archive or document. It does not certify completeness or publication review. Screening includes the last successful fetch and errors, stale status at two hours, and whether discovery exceeded the 20-document limit. Approval remains a separate step.

## Source-code references

The release builds on pdfplumber table output and PyMongo compound indexes, async cursors and atomic claims. The audit references Temporal, Keycloak, RapidFuzz, PaddleOCR, Mol*, CDS Hooks and OHDSI for further development. No new upstream model, clinical dataset or workflow engine is bundled.

[pdfplumber](https://github.com/jsvine/pdfplumber) · [PyMongo](https://github.com/mongodb/mongo-python-driver) · [CDSCO archive](https://www.cdsco.gov.in/opencms/opencms/en/Notifications/Alerts)

## Failure log

The workspace could not resolve the official CDSCO PDF host, and automatic approval rejected downloading outside the restriction. The official PDF benchmark therefore could not run. The first backend test run also exposed an incorrectly placed async assertion in a new ingestion test. It was moved back into its async test.
