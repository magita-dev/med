# MongoDB and CDSCO reliability update

## What blocked live verification

- MongoDB integration had no configured `MEDGUARD_TEST_MONGO_URI`. Windows had a MongoDB 8.2 directory containing data and logs, with no server executable found in that installation or on PATH. No running MongoDB process was observed. No host packages or database files were changed.
- Both CDSCO hostname forms failed DNS resolution in the workspace. Automatic approval rejected an unrestricted download retry. The official archive and indexed PDF text are useful for selecting fixtures, but cannot supply original bytes or a SHA-256 digest for the extraction benchmark.

## MongoDB changes

The indexed candidate query explicitly uses the compound index. Legacy inventory remains eligible through a separate cursor, merged in stock ID order so resume checkpoints stay monotonic. Reindexing and stock registration remain idempotent. The external worker and API can use a shared absolute `MEDGUARD_EVIDENCE_DIR` or the existing S3 bucket setting.

Configure a dedicated MongoDB deployment through `MEDGUARD_TEST_MONGO_URI`, then run `python tests/mongo_preflight.py` and `python -m pytest -q tests/test_mongo.py` with `PYTHONPATH=backend`. CI provisions MongoDB and runs both. The test creates an isolated temporary database and checks candidate order, migration, index selection, concurrent claiming and lease recovery. The live test remains unexecuted locally.

## CDSCO PDF changes

Capture reports HTTP status, timeout, connection failure or unsupported response. The parser tries text-aligned tables on text pages without detected ruling-line tables. It distinguishes image-only evidence and parse failure for manual review. Two-person approval and exact batch safeguards still apply.

Run `python tests/fetch_cdsco.py corpus` with `PYTHONPATH=backend` from a host that can reach CDSCO. It saves the original central and state June 2025 PDFs beside a capture log with hashes or errors. Have reviewers annotate the fetched documents using the v4 manifest format, then run `tests/benchmark_regulatory.py`. No real-PDF accuracy is claimed for this release.

[Central June 2025 NSQ PDF](https://www.cdsco.gov.in/opencms/resources/UploadCDSCOWeb/2018/UploadAlertsFiles/CDSCO%20NSQ%20june25.pdf) · [State June 2025 NSQ PDF](https://www.cdsco.gov.in/opencms/resources/UploadCDSCOWeb/2018/UploadAlertsFiles/STATE%20NSQ%20%20June%20-2025.pdf)
