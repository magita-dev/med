# Audit upgrade

| Audit area | Changes and scope |
|---|---|
| Pack contract | Product and manufacturer agreement with two distinct known batches returns `different_batch`. Manufacturer conflicts, unknown manufacturer with a batch conflict, and unrelated products do not create affected-stock alerts. |
| OCR | Anchored multilingual label proposals, candidate provenance, confidence floor, ambiguity handling, editable fields and required confirmation. Real pack inference, handwriting and manufacturer alias validation remain open. |
| Regulatory/evidence | Configured official endpoints are digest-polled with bounded size, no redirects, error visibility and revision history. A digest match establishes byte provenance for that captured source. Human scope review, comprehensive source discovery and live monitoring verification remain open. |
| Regimen | Added source-linked clarithromycin–lovastatin example and acetaminophen/paracetamol normalization for duplicate screening. Broad licensed data and independent clinical review remain open. |
| Inventory/facility | Materialized impact records with idempotent inserts, periodic repair, in-process candidate selection, quantities, locations and encrypted response notes. External delivery, stock adjustment and durable scalable worker coordination remain open. |
| Database | Opt-in persistent integration test and CI MongoDB service. Atlas connection, operational transactions, load and recovery validation remain open. |
| Accessibility/lens | Localized different-batch explanation, original educational links. Full localization, voice/accessibility validation, embedded Mol* and pharmacist mechanism review remain open. |
| Deployment | Added a multi-stage demo Dockerfile. Docker build and operational deployment remain unverified. |

[DailyMed clarithromycin label](https://www.dailymed.nlm.nih.gov/dailymed/fda/fdaDrugXsl.cfm?setid=b1bdf526-4f16-4130-b614-4cb678f060d7&type=display)

## Verification of this upgrade

- Backend: 11 passed, 1 MongoDB test skipped, 4 passing batch subtests. API and mocked HTTP tests ran in process using a socket-free event loop workaround for the restricted Windows environment. The existing Starlette TestClient deprecation warning remains.
- Frontend: TypeScript and Vite production build passed. New Playwright cases cover OCR proposal confirmation and a facility response. Current browser execution could not be verified because loopback services did not become available. Automatic approval rejected the request to run outside the restriction. The original test report remains historical.
- Synthetic benchmark: 10,000 comparisons, all expected criterion-based outcomes. The product-only baseline returned 6,000 incorrect exact matches. Median comparison times were 0.60 µs and 2.10 µs respectively. This says nothing about OCR, clinical performance, or full-stack latency.
- No live MongoDB, Atlas, S3, PaddleOCR inference, official-source polling, or Docker run was verified in this environment.
