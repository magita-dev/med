"""Standalone persistent source and surveillance worker."""
import asyncio
import os

from .api import create_app


async def run():
    if not os.getenv("MEDGUARD_MONGO_URI") or os.getenv("MEDGUARD_DEMO") == "1":
        raise RuntimeError("A dedicated worker requires persistent MongoDB")
    app = create_app(worker_only=True)
    async with app.router.lifespan_context(app):
        await asyncio.Event().wait()


if __name__ == "__main__":
    asyncio.run(run())
