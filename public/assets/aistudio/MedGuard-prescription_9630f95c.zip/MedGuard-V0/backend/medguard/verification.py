"""Regulatory action verification (P0).

Represents NSQ findings, recalls, spurious-product notices and prohibitions as distinct
action concepts and checks that a notice's claimed finding, action type, scope and
authority are supported by its kind. The approval workflow still requires independent
human review; this module reports unsupported claims so they can be rejected rather than
silently accepted. It does not establish that a notice's legal meaning is correct.
"""
ACTION_BY_KIND = {
    "nsq": {"quality_defect", "withdrawal", "recall"},
    "recall": {"recall", "withdrawal"},
    "spurious": {"spurious_product"},
    "prohibition": {"prohibition"},
}

SCOPE_REQUIRED = {"nsq", "recall", "prohibition"}


def verify_action_scope(notice: dict) -> dict:
    kind = notice.get("kind", "")
    action_type = (notice.get("action_type") or "").strip()
    finding = (notice.get("finding") or "").strip()
    scope = (notice.get("scope") or "").strip()
    authority = (notice.get("authority") or "").strip()
    allowed = ACTION_BY_KIND.get(kind, set())
    issues = []
    if action_type and action_type not in allowed:
        issues.append(f"action_type '{action_type}' is not supported for kind '{kind}'")
    if kind in SCOPE_REQUIRED and not scope:
        issues.append("a scope is required for this notice kind")
    if kind in {"spurious"} and not finding:
        issues.append("a finding is required for a spurious-product notice")
    if not authority:
        issues.append("an authority is required")
    return {"supported": not issues, "issues": issues, "kind": kind,
            "action_type": action_type, "finding": finding, "scope": scope, "authority": authority}
