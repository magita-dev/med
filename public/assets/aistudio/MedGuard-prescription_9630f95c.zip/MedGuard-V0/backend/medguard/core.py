"""Decision engine. OCR and structure predictions are outside this module."""
from collections import Counter
from unicodedata import normalize


def name(value: str) -> str:
    return " ".join(normalize("NFKC", value).casefold().split())


def batch(value: str) -> str:
    # Preserve punctuation and leading zeroes. Never infer O/0 or I/1.
    return value.strip()


def composition(values: list[str]) -> tuple[str, ...]:
    return tuple(sorted(name(value) for value in values))


def trace(pack: dict, notice: dict, checks: dict) -> list[dict]:
    """Per-criterion audit trail: what was entered, what the notice records, and the outcome."""
    def shown(source: dict, field: str) -> str:
        value = source.get(field, "")
        return ", ".join(value) if isinstance(value, list) else str(value or "")
    return [{"field": field, "entered": shown(pack, field), "notice": shown(notice, field),
             "outcome": outcome} for field, outcome in checks.items()]


def assess(pack: dict, notice: dict) -> dict | None:
    if notice["kind"] == "prohibition":
        actual = composition(pack["ingredients"])
        expected = composition(notice["ingredients"])
        if actual != expected:
            return None
        fields = {
            field: name for field in ("form", "strength")
            if not notice.get("all_formulations", False) or notice[field]
        }
    else:
        if name(pack["product"]) != name(notice["product"]):
            return None
        fields = {"manufacturer": name, "batch": batch}
    checks = {"ingredients": "equal"} if notice["kind"] == "prohibition" else {"product": "equal"}
    for field, canonical in fields.items():
        observed, expected = canonical(pack[field]), canonical(notice[field])
        checks[field] = ("missing" if not observed or not expected else
                         "equal" if observed == expected else "conflict")
    if notice["kind"] == "prohibition" and notice["strength"] and checks["strength"] == "equal":
        expected_order = [name(value) for value in notice["ingredients"]]
        observed_order = [name(value) for value in pack["ingredients"]]
        if expected_order != observed_order:
            checks["strength"] = "unmapped ingredient order"
    criteria = trace(pack, notice, checks)
    if checks.get("batch") == "conflict" and checks.get("manufacturer") == "equal":
        return {"status": "different_batch", "checks": checks, "criteria": criteria, "notice": notice}
    if "conflict" in checks.values():
        return None
    return {
        "status": "exact" if all(result == "equal" for result in checks.values()) else "uncertain",
        "checks": checks,
        "criteria": criteria,
        "notice": notice,
    }


def ingredient(value: str) -> str:
    canonical = name(value)
    return {"acetaminophen": "paracetamol"}.get(canonical, canonical)


def screen(regimen: list[dict], age: int | None, rules: list[dict]) -> list[dict]:
    counts = Counter(item for pack in regimen for item in {ingredient(v) for v in pack["ingredients"]})
    findings = [
        {"kind": "duplicate", "ingredients": [ingredient], "count": count, "tier": "curated"}
        for ingredient, count in sorted(counts.items()) if count > 1
    ]
    for rule in rules:
        # A structure-based (predicted) claim can explain a finding but never create one.
        if rule.get("tier", "curated") == "predicted":
            continue
        if not set(rule["ingredients"]).issubset(counts):
            continue
        if rule["kind"] == "geriatric":
            if age is None or age < rule["min_age"]:
                continue
            if not any(rule["ingredients"][0] in composition(pack["ingredients"])
                       and name(pack["form"]) == rule["form"] for pack in regimen):
                continue
        findings.append({**rule, "tier": rule.get("tier", "curated")})
    return findings


def latest(notices: list[dict], today: str) -> list[dict]:
    current = {}
    for notice in sorted(notices, key=lambda item: item["version"]):
        if notice["effective"] <= today:
            current[notice["key"]] = notice
    return [notice for notice in current.values() if notice["active"]]
