"""Notification outbox (Module 5 / P1 closed-loop notifications).

A durable record of notifications with ``pending | delivered | failed | retried |
acknowledged`` states, retry accounting and a pluggable delivery-provider interface.
A click on "acknowledge" is a UI acknowledgement, never proof of physical recall
completion; that distinction is enforced by the ledger module. The default provider
records delivery without side effects; real providers (SMS/email/push) are adapters
that implement ``DeliveryProvider`` and are configured out of band."""
import asyncio
from datetime import datetime, timezone
from typing import Protocol

from pydantic import BaseModel, ConfigDict, Field

STATES = ("pending", "delivered", "failed", "retried", "acknowledged")


class Notification(BaseModel):
    model_config = ConfigDict(extra="forbid")
    id: str
    tenant: str
    channel: str = "in_app"
    recipient: str
    subject: str = ""
    body: str = ""
    review_id: str | None = None
    status: str = "pending"
    attempts: int = 0
    last_error: str | None = None
    created_at: str = ""
    last_attempt_at: str = ""
    delivered_at: str = ""


class DeliveryProvider(Protocol):
    async def send(self, message: Notification) -> str | None:
        """Return None on success, an error string on failure."""


class InAppProvider:
    """Default provider: records delivery without an external side effect."""

    async def send(self, message: Notification) -> str | None:
        await asyncio.sleep(0)  # cooperative
        return None


class Outbox:
    def __init__(self, provider: DeliveryProvider | None = None, max_attempts: int = 5):
        self._messages: dict[str, Notification] = {}
        self.provider = provider or InAppProvider()
        self.max_attempts = max_attempts

    def enqueue(self, message: Notification) -> Notification:
        message.created_at = message.created_at or self._now()
        message.status = "pending"
        self._messages[message.id] = message
        return message

    def entries(self, tenant: str | None = None) -> list[Notification]:
        return [m for m in self._messages.values() if tenant is None or m.tenant == tenant]

    def pending(self, tenant: str | None = None) -> list[Notification]:
        return [m for m in self.entries(tenant) if m.status in {"pending", "retried"}]

    async def deliver_pending(self, tenant: str | None = None) -> int:
        delivered = 0
        for message in self.pending(tenant):
            await self._attempt(message)
            if message.status == "delivered":
                delivered += 1
        return delivered

    async def _attempt(self, message: Notification) -> None:
        message.attempts += 1
        message.last_attempt_at = self._now()
        error = await self.provider.send(message)
        if error is None:
            message.status = "delivered"
            message.delivered_at = self._now()
            message.last_error = None
        else:
            message.last_error = error
            message.status = "failed" if message.attempts >= self.max_attempts else "retried"

    def acknowledge(self, message_id: str, tenant: str) -> Notification | None:
        message = self._messages.get(message_id)
        if message is None or message.tenant != tenant:
            return None
        if message.status not in {"delivered", "pending", "retried"}:
            return message
        message.status = "acknowledged"
        return message

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()
