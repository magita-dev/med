"""OCR evaluation and model registry (Module 3).

Records externally provisioned model weights (with hashes, source, licence and inference
configuration) and evaluates them against independently annotated packs. No MedGuard-trained
or fine-tuned model is shipped here; success on synthetic cases is never evidence of
real-pack accuracy. The recogniser adapter (``ocr.recognize``) is unchanged.
"""
import re

from pydantic import BaseModel, ConfigDict, Field, field_validator

KINDS = {"detector", "recognizer"}
SHA256 = re.compile(r"^[0-9a-f]{64}$")


class ModelRecord(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
    name: str = Field(min_length=1, max_length=200)
    kind: str
    language: str | None = None
    version: str = Field(min_length=1, max_length=80)
    sha256: str
    source: str = Field(max_length=1600)
    license: str = ""
    inference_config: dict = Field(default_factory=dict)

    @field_validator("kind")
    @classmethod
    def _kind(cls, value):
        if value not in KINDS:
            raise ValueError(f"kind must be one of {sorted(KINDS)}")
        return value

    @field_validator("sha256")
    @classmethod
    def _sha(cls, value):
        if not SHA256.fullmatch(value):
            raise ValueError("sha256 must be 64 hex characters")
        return value


class FieldMetric(BaseModel):
    model_config = ConfigDict(extra="forbid")
    field: str
    precision: float = Field(ge=0, le=1)
    recall: float = Field(ge=0, le=1)
    ambiguous_char_errors: int = 0
    abstentions: int = 0
    corrections: int = 0


class EvaluationResult(BaseModel):
    model_config = ConfigDict(extra="forbid")
    model_name: str
    split: str = "held_out"
    image_count: int = Field(ge=0)
    metrics: list[FieldMetric] = Field(default_factory=list)


class ModelRegistry:
    def __init__(self):
        self._models: dict[str, ModelRecord] = {}

    def add(self, raw: dict) -> dict:
        record = ModelRecord(**raw)
        existing = self._models.get(record.name)
        if existing and existing.sha256 != record.sha256:
            raise ValueError("A model with this name is already registered with a different weight")
        self._models[record.name] = record
        return record.model_dump(mode="json")

    def entries(self) -> list[dict]:
        return [m.model_dump(mode="json") for m in self._models.values()]


def compare_baselines(results: list[dict]) -> dict:
    """Rank models by macro-averaged F1 across fields, reporting ambiguous-character
    errors, abstentions and corrections per model."""
    ranked = []
    for raw in results:
        r = EvaluationResult(**raw)
        f1s = []
        for m in r.metrics:
            denom = m.precision + m.recall
            f1s.append(2 * m.precision * m.recall / denom if denom else 0.0)
        macro = sum(f1s) / len(f1s) if f1s else 0.0
        ranked.append({
            "model_name": r.model_name, "split": r.split, "macro_f1": round(macro, 4),
            "ambiguous_char_errors": sum(m.ambiguous_char_errors for m in r.metrics),
            "abstentions": sum(m.abstentions for m in r.metrics),
            "corrections": sum(m.corrections for m in r.metrics),
        })
    ranked.sort(key=lambda item: item["macro_f1"], reverse=True)
    return {"ranking": ranked}
