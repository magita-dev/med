"""Optional locally provisioned recognizer. Results remain unconfirmed."""
import os
import re
from pathlib import Path
from threading import Lock

_engine_lock = Lock()
_engines = {}
LANGUAGES = {"en": "en_PP-OCRv5_mobile_rec", "hi": "devanagari_PP-OCRv5_mobile_rec",
             "ta": "ta_PP-OCRv5_mobile_rec"}

FIELD_LABELS = {
    "product": r"product(?: name)?|brand(?: name)?|medicine(?: name)?|दवा का नाम|மருந்தின் பெயர்",
    "manufacturer": r"manufactur(?:er|ed by)|mfg\.?\s*by|निर्माता|உற்பத்தியாளர்",
    "batch": r"(?:batch|lot|b\.?)(?:\s*(?:no\.?|number|#))?|बैच(?:\s*(?:संख्या|नं\.?))?|தொகுதி(?:\s*எண்)?",
    "strength": r"strength|शक्ति|வலிமை",
    "ingredients": r"ingredients?|active ingredients?|composition|संघटन|மூலப்பொருட்கள்",
    "form": r"dosage form|form",
}


def propose_fields(lines: list[dict]) -> dict:
    """Suggest explicit label values only, retaining all provenance and ambiguity."""
    proposals = {}
    for field, labels in FIELD_LABELS.items():
        pattern = re.compile(rf"^\s*(?:{labels})(?:\s*[:：]\s*|\s+)(.+?)\s*$", re.IGNORECASE)
        candidates = []
        for index, line in enumerate(lines):
            match = pattern.fullmatch(line["text"])
            if not match or line["confidence"] < 0.65:
                continue
            value = match.group(1).strip()
            if re.match(r"^(?:name|no\.?|number|by|#)\b", value, re.IGNORECASE):
                continue
            if field == "batch" and not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9./-]{0,39}", value):
                continue
            if value:
                candidates.append({"value": value, "line": index, "confidence": line["confidence"]})
        if candidates:
            values = {candidate["value"] for candidate in candidates}
            value = candidates[0]["value"] if len(values) == 1 else None
            proposals[field] = {"value": value, "candidates": candidates,
                                "requires_manual_entry": field == "batch" and bool(value and re.search("[O0I1l]", value))}
    return proposals


def recognize(data: bytes, language: str) -> list[dict]:
    import numpy as np
    from paddleocr import PaddleOCR
    from PIL import Image, ImageOps
    from io import BytesIO

    with Image.open(BytesIO(data)) as metadata:
        if metadata.format not in {"PNG", "JPEG"} or metadata.width * metadata.height > 12_000_000:
            raise ValueError("Use a JPEG or PNG under 12 megapixels")
        # Align OCR coordinates with browsers, which display the EXIF orientation.
        rgb = ImageOps.exif_transpose(metadata).convert("RGB")
        image = np.ascontiguousarray(np.asarray(rgb)[:, :, ::-1])
    with _engine_lock:
        if language not in _engines:
            detector = Path(os.environ["MEDGUARD_OCR_DETECTOR"])
            recognizer = Path(os.environ[f"MEDGUARD_OCR_{language.upper()}"])
            if not detector.is_dir() or not recognizer.is_dir():
                raise FileNotFoundError("Local OCR model directory missing")
            _engines[language] = PaddleOCR(
                text_detection_model_dir=str(detector),
                text_recognition_model_dir=str(recognizer),
                text_detection_model_name="PP-OCRv5_mobile_det",
                text_recognition_model_name=LANGUAGES[language],
                use_doc_orientation_classify=False, use_doc_unwarping=False,
                use_textline_orientation=False, device="cpu", enable_mkldnn=False,
            )
        pages = _engines[language].predict(image)
    return [
        {"text": text, "confidence": float(score), "polygon": points.tolist()}
        for page in pages
        for text, score, points in zip(page["rec_texts"], page["rec_scores"], page["rec_polys"], strict=True)
    ]
