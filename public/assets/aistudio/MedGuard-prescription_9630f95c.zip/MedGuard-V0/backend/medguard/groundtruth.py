"""Regulatory ground-truth library (Module 1).

A versioned library of official PDFs with adjudicated document- and row-level
labels, source locations, findings and reviewer-disagreement records. The library is
a *format and validation* layer: real annotated official PDFs and their adjudicated
labels are supplied out of band. This module validates a manifest, stores entries and
records reviewer disagreement so adjudication is auditable rather than implicit."""
import re
from datetime import date

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from .sources import official_url


SHA256 = re.compile(r"^[0-9a-f]{64}$")
KINDS = {"nsq", "recall", "spurious", "prohibition"}
FINDINGS = {"quality_defect", "withdrawal", "recall", "spurious_product", "prohibition", "other"}


class RowLabel(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
    page: int = Field(ge=1, le=10000)
    locator: str = Field(min_length=1, max_length=200)
    product: str = ""
    manufacturer: str = ""
    batch: str = ""
    finding: str
    adjudication: str = Field(default="agreed")  # agreed | disagreed | unresolved


class ReviewerRecord(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
    reviewer: str = Field(min_length=1)
    agreed: bool
    note: str = ""
    at: date


class GroundTruthEntry(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
    doc_id: str = Field(min_length=1, max_length=200)
    source: str = Field(max_length=1600)
    sha256: str
    version: int = Field(default=1, ge=1)
    pages: int = Field(ge=1, le=10000)
    kind: str
    finding: str
    authority: str = Field(default="CDSCO")
    scope: str = Field(default="")
    rows: list[RowLabel] = Field(default_factory=list)
    reviewers: list[ReviewerRecord] = Field(default_factory=list)

    @field_validator("source")
    @classmethod
    def _official(cls, value):
        if not official_url(value):
            raise ValueError("Source must be an official HTTPS URL")
        return value

    @field_validator("sha256")
    @classmethod
    def _sha(cls, value):
        if not SHA256.fullmatch(value):
            raise ValueError("sha256 must be 64 hex characters")
        return value

    @field_validator("kind")
    @classmethod
    def _kind(cls, value):
        if value not in KINDS:
            raise ValueError(f"kind must be one of {sorted(KINDS)}")
        return value

    @field_validator("finding")
    @classmethod
    def _finding(cls, value):
        if value not in FINDINGS:
            raise ValueError(f"finding must be one of {sorted(FINDINGS)}")
        return value

    @model_validator(mode="after")
    def _disagreement(self):
        if self.reviewers and len({r.reviewer for r in self.reviewers}) >= 2 and not all(r.agreed for r in self.reviewers):
            # Disagreement is recorded, not rejected. Adjudication on rows must reflect it.
            if any(row.adjudication == "agreed" for row in self.rows) and any(r.agreed is False for r in self.reviewers):
                # Allow it: the disagreement is itself the ground-truth signal.
                pass
        return self


class GroundTruthLibrary:
    """In-memory versioned library with validation and disagreement accounting."""

    def __init__(self):
        self._entries: dict[str, GroundTruthEntry] = {}

    def add(self, raw: dict) -> dict:
        entry = GroundTruthEntry(**raw)
        key = f"{entry.doc_id}:{entry.version}"
        if key in self._entries:
            existing = self._entries[key]
            if existing.sha256 != entry.sha256:
                raise ValueError("Ground-truth version is immutable once published")
            return existing.model_dump(mode="json")
        self._entries[key] = entry
        return entry.model_dump(mode="json")

    def entries(self) -> list[dict]:
        return [entry.model_dump(mode="json") for entry in self._entries.values()]

    def get(self, doc_id: str, version: int) -> dict | None:
        entry = self._entries.get(f"{doc_id}:{version}")
        return entry.model_dump(mode="json") if entry else None

    def disagreements(self) -> list[dict]:
        out = []
        for key, entry in self._entries.items():
            reviewers = entry.reviewers
            if len(reviewers) >= 2 and any(not r.agreed for r in reviewers):
                out.append({"doc_id": entry.doc_id, "version": entry.version,
                             "disagreement": True,
                             "reviewers": [r.model_dump(mode="json") for r in reviewers]})
        return out


def validate_manifest(manifest: list[dict]) -> list[str]:
    """Validate a whole manifest and return human-readable errors per entry."""
    errors = []
    seen = set()
    for index, raw in enumerate(manifest):
        key = f"{raw.get('doc_id')}:{raw.get('version')}"
        if key in seen:
            errors.append(f"entry {index}: duplicate ground-truth version {key}")
            continue
        seen.add(key)
        try:
            GroundTruthEntry(**raw)
        except Exception as error:  # ValidationError subclasses
            errors.append(f"entry {index}: {error}")
    return errors
