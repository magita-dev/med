"""Prescription review: parse proposals, translate instructions, and check dose and indication.

Everything here is deterministic and rule-driven. A check only *runs* when a reviewed, cited rule
is loaded for that medicine; otherwise it is reported as not assessed. The result is never
"safe": it is either "issues found" or "nothing found in the checks that could run".
"""
import re
from datetime import date

from .core import ingredient, name, screen

# abbreviation -> (times per day or None, English, Tamil)
SIG = {
    "od": (1, "once a day", "தினமும் ஒரு முறை"), "qd": (1, "once a day", "தினமும் ஒரு முறை"),
    "bd": (2, "twice a day", "தினமும் இரண்டு முறை"), "bid": (2, "twice a day", "தினமும் இரண்டு முறை"),
    "tds": (3, "three times a day", "தினமும் மூன்று முறை"), "tid": (3, "three times a day", "தினமும் மூன்று முறை"),
    "qid": (4, "four times a day", "தினமும் நான்கு முறை"),
    "hs": (1, "at bedtime", "இரவு படுக்கும் முன்"),
    "sos": (None, "only when needed", "தேவைப்படும்போது மட்டும்"), "prn": (None, "only when needed", "தேவைப்படும்போது மட்டும்"),
    "stat": (1, "one dose now", "இப்போது ஒரு முறை"),
}
MODIFIERS = {"ac": ("before food", "உணவுக்கு முன்"), "pc": ("after food", "உணவுக்குப் பின்")}
SLOTS = [("morning", "காலை"), ("afternoon", "மதியம்"), ("night", "இரவு"), ("bedtime", "படுக்கும் முன்")]
FORMS = {"tab": "tablet", "tablet": "tablet", "cap": "capsule", "capsule": "capsule", "syp": "syrup",
         "syr": "syrup", "syrup": "syrup", "inj": "injection", "injection": "injection"}
TO_MG = {"mg": 1.0, "g": 1000.0, "mcg": 0.001, "µg": 0.001}

_STRENGTH = re.compile(r"(\d+(?:\.\d+)?)\s*(mg|mcg|µg|g|ml|iu)\b", re.I)
_PATTERN = re.compile(r"(?<![\d.])(\d)\s*-\s*(\d)\s*-\s*(\d)(?:\s*-\s*(\d))?(?![\d.])")
_DURATION = re.compile(r"(?:x|×|for)\s*(\d{1,3})\s*(days?|d|weeks?|wks?)\b", re.I)


def parse_line(text: str) -> dict | None:
    """Turn one prescription line into a *proposal*. The user must confirm every field."""
    raw = text.strip()
    words = raw.split()
    if not words:
        return None
    form = FORMS.get(words[0].strip(".").lower(), "")
    start = 1 if form else 0
    head = re.split(r"\d", " ".join(words[start:]), maxsplit=1)[0]
    drug = re.sub(r"[^A-Za-z \-]", " ", head).strip().lower()
    strength = _STRENGTH.search(raw)
    pattern = _PATTERN.search(raw)
    tokens = {t.strip(".,").lower() for t in raw.split()}
    abbr = next((a for a in SIG if a in tokens), None)
    modifiers = [m for m in MODIFIERS if m in tokens]
    units = None
    slots: list[int] = []
    if pattern:
        slots = [int(d) for d in pattern.groups() if d is not None]
        units = sum(slots)
    elif abbr and SIG[abbr][0] is not None:
        units = SIG[abbr][0]
    duration = _DURATION.search(raw)
    days = None
    if duration:
        days = int(duration.group(1)) * (7 if duration.group(2).lower().startswith(("w", "wk")) else 1)
    if not drug or not (strength or pattern or abbr):
        return None
    return {"raw": raw, "drug": drug, "form": form,
            "strength_value": float(strength.group(1)) if strength else None,
            "strength_unit": strength.group(2).lower() if strength else None,
            "frequency": abbr or (pattern.group(0) if pattern else None), "slots": slots,
            "as_needed": abbr in {"sos", "prn"}, "units_per_day": units, "modifiers": modifiers,
            "duration_days": days}


def instruction(item: dict) -> dict:
    """Plain-language instruction in English and Tamil. Medicine names stay as entered (generic)."""
    en, ta = [], []
    if item.get("slots"):
        for count, (slot_en, slot_ta) in zip(item["slots"], SLOTS):
            if count:
                en.append(f"{count} in the {slot_en}" if slot_en != "bedtime" else f"{count} at bedtime")
                ta.append(f"{slot_ta} {count}")
    elif item.get("frequency") in SIG:
        en.append(SIG[item["frequency"]][1]); ta.append(SIG[item["frequency"]][2])
    for modifier in item.get("modifiers", []):
        en.append(MODIFIERS[modifier][0]); ta.append(MODIFIERS[modifier][1])
    if item.get("duration_days"):
        en.append(f"for {item['duration_days']} days"); ta.append(f"{item['duration_days']} நாட்களுக்கு")
    label = f"{item['drug']} {item['strength_value']:g} {item['strength_unit']}" if item.get("strength_value") else item["drug"]
    return {"en": f"{label}: " + ", ".join(en), "ta": f"{label}: " + ", ".join(ta)}


def daily_mg(item: dict) -> float | None:
    if item.get("as_needed") or not item.get("units_per_day") or not item.get("strength_value"):
        return None
    factor = TO_MG.get(item.get("strength_unit") or "")
    return None if factor is None else item["strength_value"] * factor * item["units_per_day"]


def check_dose(item: dict, rules: list[dict], age: int | None) -> dict:
    ing = ingredient(item["drug"])
    candidates = [r for r in rules if r["ingredient"] == ing]
    if not candidates:
        return {"outcome": "unassessed", "reason": "no_reviewed_rule"}
    total = daily_mg(item)
    if total is None:
        return {"outcome": "unassessed", "reason": "dose_unknown_or_as_needed"}
    for rule in candidates:
        low, high = rule.get("min_age"), rule.get("max_age")
        if (low is not None or high is not None) and age is None:
            continue
        if (low is not None and age < low) or (high is not None and age > high):
            continue
        outcome = "exceeds_cited_maximum" if total > rule["max_daily_mg"] else "at_or_below_cited_maximum"
        return {"outcome": outcome, "daily_mg": total, "max_daily_mg": rule["max_daily_mg"],
                "rule": {k: rule.get(k) for k in ("source", "locator", "jurisdiction", "synthetic")},
                "assumption": "One unit per dose unless the pattern states otherwise."}
    return {"outcome": "unassessed", "reason": "no_rule_for_this_age"}


def check_indication(item: dict, condition: str | None, rules: list[dict]) -> dict:
    ing = ingredient(item["drug"])
    rule = next((r for r in rules if r["ingredient"] == ing), None)
    if not condition or not condition.strip():
        return {"outcome": "unassessed", "reason": "no_condition_entered"}
    if rule is None:
        return {"outcome": "unassessed", "reason": "no_reviewed_rule"}
    wanted = name(condition)
    listed = any(term in wanted or wanted in term for term in map(name, rule["indications"]))
    return {"outcome": "listed_in_cited_label" if listed else "not_listed_in_cited_label",
            "rule": {k: rule.get(k) for k in ("source", "locator", "jurisdiction", "synthetic")}}


SUMMARY = {
    "issues_found": {
        "en": "Possible issues were found. Show this to your doctor or pharmacist. Do not stop or change medicines on your own.",
        "ta": "சாத்தியமான சிக்கல்கள் கண்டறியப்பட்டன. இதை உங்கள் மருத்துவரிடம் அல்லது மருந்தாளரிடம் காட்டவும். நீங்களாகவே மருந்துகளை நிறுத்தவோ மாற்றவோ வேண்டாம்.",
    },
    "nothing_found": {
        "en": "No issues found as of {date} in the {ran} checks that could run. {not_run} checks could not run. This does not mean the prescription is safe.",
        "ta": "{date} வரை, செய்ய முடிந்த {ran} சோதனைகளில் எந்தச் சிக்கலும் கண்டறியப்படவில்லை. {not_run} சோதனைகளைச் செய்ய இயலவில்லை. இது மருந்துச்சீட்டு பாதுகாப்பானது என்று பொருள்படாது.",
    },
}


def review(items: list[dict], condition: str | None, age: int | None,
           dose_rules: list[dict], indication_rules: list[dict], clinical_rules: list[dict]) -> dict:
    rows, ran, not_run, issue = [], 0, 0, False
    for item in items:
        dose = check_dose(item, dose_rules, age)
        indication = check_indication(item, condition, indication_rules)
        for result in (dose, indication):
            if result["outcome"] == "unassessed":
                not_run += 1
            else:
                ran += 1
        issue |= dose["outcome"] == "exceeds_cited_maximum" or indication["outcome"] == "not_listed_in_cited_label"
        rows.append({**item, "instruction": instruction(item), "dose": dose, "indication": indication})
    packs = [{"ingredients": [item["drug"]], "form": item.get("form", "")} for item in items]
    findings = screen(packs, age, clinical_rules)
    ran += 1  # the regimen screen always runs, within its loaded rules
    issue |= bool(findings)
    outcome = "issues_found" if issue else "nothing_found"
    today = date.today().isoformat()
    summary = {lang: text.format(date=today, ran=ran, not_run=not_run) for lang, text in SUMMARY[outcome].items()}
    return {"outcome": outcome, "summary": summary, "as_of": today, "checks_ran": ran,
            "checks_not_run": not_run, "items": rows, "findings": findings, "limited_coverage": True}
