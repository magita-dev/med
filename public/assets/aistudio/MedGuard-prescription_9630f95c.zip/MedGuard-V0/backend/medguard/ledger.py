"""Inventory transaction ledger (Module 6 / P1 closed-loop inventory actions).

An append-only ledger of stock movements: stock_in, stock_out, quarantine, return and
record correction. Each movement records the actor, a timestamp and whether the
outcome was *reported* by a user or *verified* against a source. Recorded quantity is
reconciled against expected quantity so a reported action is never silently treated as
a verified physical movement. This complements the encrypted stock store; it does not
replace the pack check or surveillance workflow."""
from datetime import datetime, timezone

from pydantic import BaseModel, ConfigDict, Field, field_validator

KINDS = {"stock_in", "stock_out", "quarantine", "return", "record_correction"}
# stock_in increases quantity; stock_out/quarantine reduce available quantity; return restores.
DELTA = {"stock_in": 1, "stock_out": -1, "quarantine": -1, "return": 1, "record_correction": 0}


class Transaction(BaseModel):
    model_config = ConfigDict(extra="forbid")
    id: str
    stock_id: str
    tenant: str
    kind: str
    quantity_delta: int = 0
    actor: str
    at: str = ""
    note: str = ""
    reported: bool = True     # a user recorded this action
    verified: bool = False    # an independent check confirmed the physical movement

    @field_validator("kind")
    @classmethod
    def _kind(cls, value):
        if value not in KINDS:
            raise ValueError(f"kind must be one of {sorted(KINDS)}")
        return value


class Ledger:
    def __init__(self):
        self._rows: dict[str, Transaction] = {}

    def append(self, raw: dict) -> Transaction:
        txn = Transaction(**raw)
        txn.at = txn.at or self._now()
        key = (txn.tenant, txn.stock_id, txn.id)
        if key in self._rows:
            existing = self._rows[key]
            if existing.at != txn.at or existing.kind != txn.kind:
                raise ValueError("Transaction is immutable once appended")
            return existing
        self._rows[key] = txn
        return txn

    def for_stock(self, stock_id: str, tenant: str) -> list[Transaction]:
        return [txn for (t, sid, _), txn in self._rows.items()
                if t == tenant and sid == stock_id]

    def reconcile(self, stock_id: str, tenant: str, expected_quantity: int) -> dict:
        """Reconcile reported ledger movements against an expected recorded quantity."""
        movements = self.for_stock(stock_id, tenant)
        ledger_quantity = sum(DELTA[txn.kind] * (txn.quantity_delta or 0) for txn in movements)
        verified = [txn for txn in movements if txn.verified]
        reported_only = [txn for txn in movements if txn.reported and not txn.verified]
        return {
            "stock_id": stock_id,
            "expected_quantity": expected_quantity,
            "ledger_quantity": ledger_quantity,
            "matches_record": ledger_quantity == expected_quantity,
            "verified_movements": len(verified),
            "reported_unverified_movements": len(reported_only),
            "all_verified": len(reported_only) == 0 and bool(movements),
        }

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()
