"""Opaque candidate keys. The decision engine still verifies decrypted fields."""
import hmac
import json

from .core import composition, name


class CandidateKeys:
    def __init__(self, secret, catalog_revision):
        self.secret = secret
        self.version = self.token(["catalog", catalog_revision])

    def token(self, value):
        data = json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode()
        return hmac.digest(self.secret, b"medguard-index-v1:" + data, "sha256").hex()

    def notice(self, notice):
        if notice["kind"] == "prohibition":
            return self.token(["fdc", composition(notice["ingredients"])])
        return self.token(["product", name(notice["product"])])

    def stock(self, pack):
        return [self.token(["product", name(pack["product"])]),
                self.token(["fdc", composition(pack["ingredients"])])]
