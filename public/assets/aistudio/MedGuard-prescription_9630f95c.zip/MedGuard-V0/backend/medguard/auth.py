"""Production identity and privacy scaffolding (Module 7 / P1).

This is an *additive* layer alongside the development HTTP-Basic flow. It provides:

* Opaque, HMAC-signed session tokens so a client can avoid sending credentials on
  every request and so sessions can be revoked. A real deployment would back this with
  an OIDC provider (e.g. Keycloak); the token format here is the local fallback.
* A small permission model so roles are checked against named actions, not hard-coded
  strings scattered through route handlers.
* Sensitive-log redaction so batch-like strings, tokens and long hex digests are masked
  before they reach logs. Existing routes continue to accept HTTP-Basic unchanged.
"""
import hmac
import re
import secrets
from datetime import datetime, timedelta, timezone

PERMISSIONS = {
    "member": {"check", "regimen", "read_stock", "save_stock", "ack_review",
               "resolve_review", "view_audit", "view_notifications", "use_ocr"},
    "publisher": {"check", "regimen", "read_stock", "save_stock", "ack_review",
                  "resolve_review", "view_audit", "view_notifications", "use_ocr",
                  "publish_notice", "approve_notice", "extract_evidence", "view_sources",
                  "manage_ground_truth", "review_molecular"},
}


def can(actor: dict, action: str) -> bool:
    return action in PERMISSIONS.get(actor.get("role", ""), set())


class SessionStore:
    """In-memory opaque session tokens. Revocation drops the token."""

    def __init__(self, secret: bytes, ttl_minutes: int = 480):
        self.secret = secret
        self.ttl = timedelta(minutes=ttl_minutes)
        self._sessions: dict[str, dict] = {}

    def issue(self, actor: dict) -> str:
        raw = secrets.token_urlsafe(32)
        signature = hmac.new(self.secret, raw.encode(), "sha256").hexdigest()
        token = f"{raw}.{signature}"
        expires = (datetime.now(timezone.utc) + self.ttl).isoformat()
        self._sessions[token] = {**actor, "expires_at": expires}
        return token

    def verify(self, token: str) -> dict | None:
        if "." not in token:
            return None
        raw, signature = token.rsplit(".", 1)
        expected = hmac.new(self.secret, raw.encode(), "sha256").hexdigest()
        if not hmac.compare_digest(signature, expected):
            return None
        session = self._sessions.get(token)
        if session is None:
            return None
        if session["expires_at"] < datetime.now(timezone.utc).isoformat():
            self._sessions.pop(token, None)
            return None
        return {key: session[key] for key in ("user", "role", "tenant", "demo")}

    def revoke(self, token: str) -> bool:
        return self._sessions.pop(token, None) is not None


_SENSITIVE = re.compile(r"(?<![A-Za-z0-9])([A-Za-z0-9][A-Za-z0-9./-]{14,})(?![A-Za-z0-9])")
_HEX64 = re.compile(r"\b[0-9a-f]{64}\b")
_TOKEN = re.compile(r"(?i) bearer\s+\S+")
_BASIC = re.compile(r"(?i) basic\s+[A-Za-z0-9+/=]+")


def redact(text: str) -> str:
    """Mask values that look like batches, hashes, tokens or credentials."""
    text = _TOKEN.sub("Bearer ***", text)
    text = _BASIC.sub("Basic ***", text)
    text = _HEX64.sub("<sha256>", text)
    return _SENSITIVE.sub(lambda match: match.group(1)[:3] + "…" + match.group(1)[-2:], text)
