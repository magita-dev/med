from difflib import SequenceMatcher

from .core import name


def pair(item):
    return name(item["product"]), name(item["manufacturer"])


class IdentityCatalog:
    def __init__(self, records):
        self.aliases = {}
        for record in records:
            canonical = {key: record["canonical"][key] for key in ("product", "manufacturer")}
            if not all(pair(canonical)) or not record["source"] or not record["reviewer"]:
                raise ValueError("Canonical identity requires source and reviewer")
            for variant in [canonical, *record["aliases"]]:
                key = pair(variant)
                if not all(key) or (key in self.aliases and self.aliases[key] != canonical):
                    raise ValueError("Incomplete or ambiguous identity alias")
                self.aliases[key] = canonical

    def resolve(self, item):
        if item.get("kind") == "prohibition":
            return item
        return {**item, **self.aliases.get(pair(item), {})}

    def candidates(self, item):
        product, manufacturer = pair(item)
        scored = {}
        for (alias_product, alias_manufacturer), canonical in self.aliases.items():
            if manufacturer and manufacturer != alias_manufacturer:
                continue
            score = SequenceMatcher(None, product, alias_product, autojunk=False).ratio()
            key = (canonical["product"], canonical["manufacturer"])
            if score >= 0.7:
                scored[key] = max(score, scored.get(key, 0))
        return [{"product": key[0], "manufacturer": key[1]}
                for key in sorted(scored, key=lambda key: (-scored[key], key))[:5]]
