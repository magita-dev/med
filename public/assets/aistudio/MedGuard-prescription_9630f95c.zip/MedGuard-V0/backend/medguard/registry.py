"""Reviewed medicine identity registry (Module 2).

Canonical product/manufacturer entries with aliases, composition, provenance and release
versions. Validates that each canonical identity carries a source and reviewer, that an
alias differs from its canonical, and that an alias resolves to exactly one canonical. The
decision engine's ``IdentityCatalog`` is unchanged; this registry governs admission of
reviewed identities and can feed a catalog into it.
"""
from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator

from .core import name


class IdentityVariant(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
    product: str = Field(min_length=1, max_length=200)
    manufacturer: str = Field(default="", max_length=200)


class ReviewedIdentity(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
    canonical: IdentityVariant
    aliases: list[IdentityVariant] = Field(default_factory=list, max_length=40)
    composition: list[str] = Field(default_factory=list, max_length=40)
    source: str = Field(min_length=1, max_length=1600)
    reviewer: str = Field(min_length=1, max_length=200)
    version: int = Field(default=1, ge=1)

    @field_validator("aliases")
    @classmethod
    def _no_self_alias(cls, value, info):
        canonical = info.data.get("canonical")
        for alias in value:
            if canonical and name(alias.product) == name(canonical.product) \
                    and name(alias.manufacturer) == name(canonical.manufacturer):
                raise ValueError("An alias must differ from the canonical identity")
        return value


class ReviewedIdentityRegistry:
    def __init__(self, records: list[dict]):
        self.entries: list[ReviewedIdentity] = []
        self.errors: list[str] = []
        self._by_pair: dict[tuple[str, str], ReviewedIdentity] = {}
        for index, raw in enumerate(records):
            try:
                entry = ReviewedIdentity(**raw)
            except ValidationError as error:
                self.errors.append(f"record {index}: invalid identity")
                continue
            key = (name(entry.canonical.product), name(entry.canonical.manufacturer))
            if key in self._by_pair:
                self.errors.append(f"record {index}: duplicate canonical identity")
                continue
            self._by_pair[key] = entry
            conflict = False
            for alias in entry.aliases:
                akey = (name(alias.product), name(alias.manufacturer))
                if akey in self._by_pair and self._by_pair[akey] is not entry:
                    self.errors.append(f"record {index}: alias resolves to a different canonical")
                    conflict = True
                    break
                self._by_pair.setdefault(akey, entry)
            if conflict:
                continue
            self.entries.append(entry)

    @property
    def valid(self) -> bool:
        return not self.errors

    def to_catalog_records(self) -> list[dict]:
        """Produce records compatible with ``IdentityCatalog``."""
        return [{"canonical": e.canonical.model_dump(), "aliases": [a.model_dump() for a in e.aliases],
                 "source": e.source, "reviewer": e.reviewer} for e in self.entries]

    def report(self) -> list[dict]:
        return [{"canonical": e.canonical.model_dump(), "composition": e.composition,
                 "source": e.source, "reviewer": e.reviewer, "version": e.version,
                 "alias_count": len(e.aliases)} for e in self.entries]
