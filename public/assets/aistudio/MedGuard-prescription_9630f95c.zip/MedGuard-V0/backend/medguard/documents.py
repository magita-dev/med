"""Extract review material by page. Extraction never publishes a notice."""
from io import BytesIO


def inspect_page(data, number, span=None):
    import pdfplumber

    with pdfplumber.open(BytesIO(data)) as pdf:
        if not 1 <= number <= len(pdf.pages):
            raise ValueError("Source page does not exist")
        if span is None:
            return ""
        page = pdf.pages[number - 1]
        left, top, right, bottom = page.bbox
        x0, y0, x1, y1 = span
        bbox = (left + x0 * (right - left), top + y0 * (bottom - top),
                left + x1 * (right - left), top + y1 * (bottom - top))
        return page.crop(bbox).extract_text() or ""


def extract(data: bytes, engine: str, page_limit: int = 20, *, text_tables: bool = False):
    if engine == "pymupdf":
        import pymupdf

        with pymupdf.open(stream=data, filetype="pdf") as pdf:
            return [{"page": index, "text": page.get_text()[:8000]}
                    for index, page in enumerate(pdf, 1) if index <= page_limit]

    import pdfplumber

    with pdfplumber.open(BytesIO(data)) as pdf:
        pages = []
        for index, page in enumerate(pdf.pages[:page_limit], 1):
            text = (page.extract_text() or "")[:8000]
            tables = page.extract_tables()[:8]
            if text_tables and not tables and text:
                tables = page.extract_tables({"vertical_strategy": "text", "horizontal_strategy": "text"})[:8]
            pages.append({"page": index, "text": text, "tables": tables})
        return pages
