"""Observe configured official sources. Changed bytes always require human review."""
import asyncio
import re
from hashlib import sha256
from html.parser import HTMLParser
from urllib.parse import urljoin, urlsplit

import httpx

from .documents import extract

OFFICIAL_HOSTS = {
    "www.cdsco.gov.in", "cdsco.gov.in", "cdscoonline.gov.in",
    "egazette.gov.in", "www.egazette.gov.in",
}
MAX_SOURCE_BYTES = 8 * 1024 * 1024


def official_url(value):
    url = urlsplit(value)
    return url.scheme == "https" and url.netloc in OFFICIAL_HOSTS and not url.fragment


async def capture(client, url):
    if not official_url(url):
        raise ValueError("Expected an official HTTPS URL")
    async with client.stream("GET", url, follow_redirects=False) as response:
        response.raise_for_status()
        data = bytearray()
        async for chunk in response.aiter_bytes(chunk_size=65536):
            if len(data) + len(chunk) > MAX_SOURCE_BYTES:
                raise ValueError("Source exceeds the capture limit")
            data.extend(chunk)
    if not data:
        raise ValueError("Source is empty")
    return bytes(data)


class NoticeLinks(HTMLParser):
    def __init__(self, source):
        super().__init__()
        self.source = source
        self.links = []

    def handle_starttag(self, tag, attrs):
        href = dict(attrs).get("href")
        if tag != "a" or not href:
            return
        url = urljoin(self.source, href)
        path = urlsplit(url).path.lower()
        if (official_url(url) and path.endswith(".pdf") and
                any(folder in path for folder in ("/uploadalertsfiles/", "/uploadgazette_notificationsfiles/"))):
            self.links.append(url)


def nsq_rows(pages):
    """Map columns by explicit headings. Unknown layouts go to manual review."""
    patterns = {
        "serial": r"(?:s\s*\.?\s*no\.?|serial\s*(?:no\.?)?|no\.?)",
        "product": r"(?:product\s*/\s*drug name|drug name|product(?: name)?)",
        "batch": r"(?:batch|lot)(?:\s*(?:no\.?|number))?",
        "manufacturer": r"(?:manufactured by|manufacturer(?: name)?)",
        "finding": r"nsq\s*(?:result[s]?|reason)",
    }
    rows = []
    previous_mapping = {}
    previous_width = 0
    previous_page = 0
    previous_serial = None
    for page in pages:
        for table in page.get("tables", []):
            mapping = {}
            header = 0
            for header, cells in enumerate(table[:3]):
                labels = [" ".join((cell or "").lower().split()) for cell in cells]
                matches = {field: [i for i, label in enumerate(labels) if re.fullmatch(pattern, label)]
                           for field, pattern in patterns.items()}
                if all(len(indices) == 1 for indices in matches.values()):
                    mapping = {field: indices[0] for field, indices in matches.items()}
                    break
            if mapping:
                previous_mapping = mapping
                previous_width = len(table[header])
            else:
                if not previous_mapping or page["page"] != previous_page + 1 or not table:
                    continue
                mapping = previous_mapping
                if any(len(cells) != previous_width for cells in table):
                    continue
                serial_column = mapping["serial"]
                first_serial = next(((cells[serial_column] or "").strip().rstrip(".")
                                     for cells in table if (cells[serial_column] or "").strip()), "")
                if not first_serial.isascii() or not first_serial.isdigit() or previous_serial is None or int(first_serial) != previous_serial + 1:
                    continue
                header = -1
            for cells in table[header + 1:]:
                values = [" ".join((cell or "").split()) for cell in cells]
                if len(values) <= max(mapping.values()):
                    continue
                serial, product, batch, manufacturer, finding = (values[mapping[field]] for field in patterns)
                printed = serial.rstrip(".")
                if printed.isascii() and printed.isdigit():
                    previous_serial = int(printed)
                    previous_page = page["page"]
                if printed.isascii() and printed.isdigit() and all((product, batch, manufacturer, finding)):
                    rows.append({"product": product, "batch": batch, "manufacturer": manufacturer,
                                 "finding": finding, "source_page": page["page"],
                                 "locator": f'Page {page["page"]}, row {serial}'})
    return rows


async def observe(store, urls, now, client, evidence=None):
    pending = list(dict.fromkeys(urls))
    parents = {}
    for url in pending:
        try:
            data = await capture(client, url)
        except httpx.HTTPStatusError as error:
            state = {"error": f"Official source returned HTTP {error.response.status_code}"}
        except httpx.TimeoutException:
            state = {"error": "Official source request timed out"}
        except httpx.ConnectError:
            state = {"error": "Official source connection failed (DNS, TCP or TLS)"}
        except (httpx.HTTPError, ValueError):
            state = {"error": "Official source response could not be captured"}
        else:
            digest = sha256(data).hexdigest()
            pdf = data.startswith(b"%PDF-")
            state = {"sha256": digest, "pdf": pdf}
            identifier = url + "|" + digest
            prior = await store.find("ingestion", _id=identifier) if pdf and evidence else []
            if pdf and evidence and (not prior or prior[0].get("parser_version") != 5):
                try:
                    pages = await asyncio.to_thread(extract, data, "pdfplumber", 80, text_tables=True)
                    rows = nsq_rows(pages)
                    status = ("rows_pending_review" if rows else "manual_review" if any(
                        page["text"].strip() for page in pages) else "image_only_manual_review")
                    extraction_error = None
                except Exception:
                    rows, status = [], "manual_review"
                    extraction_error = "PDF parsing failed"
                await evidence.put(digest, data)
                await store.replace("ingestion", {"_id": identifier, "source": url, "sha256": digest,
                                                  "status": status, "rows": rows, "parser_version": 5,
                                                  "extraction_error": extraction_error,
                                                  "page_limit": 80,
                                                  "observed_at": prior[0]["observed_at"] if prior else now()})
            if not pdf and url in urls:
                parser = NoticeLinks(url)
                parser.feed(data.decode("utf-8", errors="replace"))
                links = list(dict.fromkeys(parser.links))
                state["discovered_documents"] = len(links)
                state["document_limit_reached"] = len(links) > 20
                for link in links[:20]:
                    parents.setdefault(link, url)
                pending.extend(link for link in links[:20] if link not in pending)
        row = {"_id": now(), "source": url, **state}
        previous = await store.find("source_status", _id=url)
        success = row["_id"] if "sha256" in row else previous[0].get("last_success_at") if previous else None
        await store.replace("source_status", {**row, "_id": url, "checked_at": row["_id"], "last_success_at": success,
                                              "discovered_from": parents.get(url)})
        if "sha256" in row:
            await store.add("source_versions", {**row, "_id": url + "|" + row["sha256"],
                                                 "first_seen": row["_id"]})
