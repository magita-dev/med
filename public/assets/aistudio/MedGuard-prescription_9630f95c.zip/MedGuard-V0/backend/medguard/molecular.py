"""Molecular evidence catalog and pharmacist-only hypothesis workflow (P2).

A curated, reviewed catalog of drug-protein evidence keeps experimental and predicted
structures distinct. A *hypothesis* links a medicine to a target protein with cited
evidence and must pass pharmacist review before it is exposed. The catalog never infers a
clinical interaction from a 3D structure; a hypothesis is an evidence-linked proposal,
not a clinical warning. This is the data layer behind the Mechanism Lens view."""
from datetime import date

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

STRUCTURE_KINDS = {"experimental", "predicted"}

# Evidence tiers shown on every finding. "predicted" may EXPLAIN an alert but can never
# CREATE one: core.screen drops any rule or finding carrying this tier.
EVIDENCE_TIERS = ("verified", "curated", "predicted")

# Static protein library for the Mechanism Lens. Records identify existing public
# structures only; nothing here is a prediction about a drug or a patient. Accessions
# must be re-checked against RCSB / AlphaFold DB before any release (see docs).
PROTEINS: dict[str, dict] = {
    "CYP3A4": {"name": "Cytochrome P450 3A4", "uniprot": "P08684", "pdb": "1TQN",
               "method": "X-ray diffraction",
               "role": "Major drug-metabolising enzyme; inhibitors raise exposure to substrate medicines."},
    "CYP2D6": {"name": "Cytochrome P450 2D6", "uniprot": "P10635", "pdb": "2F9Q",
               "method": "X-ray diffraction",
               "role": "Metabolises many antidepressants, antipsychotics and opioids; activity varies between people."},
    "hERG": {"name": "hERG potassium channel (KCNH2)", "uniprot": "Q12809", "pdb": "5VA2",
             "method": "Cryo-EM",
             "role": "Cardiac potassium channel; block by some medicines is linked to QT prolongation."},
    "P-gp": {"name": "P-glycoprotein (ABCB1)", "uniprot": "P08183", "pdb": "6C0V",
             "method": "Cryo-EM",
             "role": "Efflux transporter that limits absorption and tissue entry of some medicines."},
}
PROTEIN_LIMITATION = ("A structure shows the protein, not binding, inhibition or interaction severity "
                      "for a specific medicine or patient. The cited label or regulator notice is the evidence.")


def protein_view(target: str) -> dict | None:
    """Return a protein with provenance-labelled structures, or None if not in the library."""
    key = next((name for name in PROTEINS if name.casefold() == target.casefold()), None)
    if key is None:
        return None
    entry = PROTEINS[key]
    return {
        "target": key, "name": entry["name"], "role": entry["role"],
        "limitation": PROTEIN_LIMITATION,
        "structures": [
            {"kind": "experimental", "accession": entry["pdb"], "method": entry["method"],
             "label": f"Experimental (PDB {entry['pdb']})",
             "source": f"https://www.rcsb.org/structure/{entry['pdb']}", "confidence": None,
             "trust": "Deposited experimental model; reflects the conditions it was solved under."},
            {"kind": "predicted", "accession": entry["uniprot"], "method": "AlphaFold DB",
             "label": f"AlphaFold-predicted ({entry['uniprot']})",
             "source": f"https://alphafold.ebi.ac.uk/entry/{entry['uniprot']}",
             "confidence": "Per-residue pLDDT shown in the viewer",
             "trust": "Computational prediction; treat low-confidence regions as unreliable."},
        ],
    }


class StructureRecord(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
    accession: str = Field(min_length=1, max_length=80)
    kind: str  # experimental | predicted
    method: str = ""
    source: str = Field(max_length=1600)
    confidence: str | None = None  # predicted structures only


class EvidenceEntry(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
    target: str = Field(min_length=1)          # e.g. CYP3A4
    drug: str
    relationship: str = Field(default="metabolism")  # metabolism | inhibition | induction | target | transport
    structures: list[StructureRecord] = Field(default_factory=list)
    evidence: list[dict] = Field(default_factory=list)
    limitation: str = ""
    reviewed_by: str = ""
    reviewed_at: date | None = None

    @field_validator("structures")
    @classmethod
    def _distinct(cls, value):
        for record in value:
            if record.kind not in STRUCTURE_KINDS:
                raise ValueError(f"structure kind must be one of {sorted(STRUCTURE_KINDS)}")
            if record.kind == "predicted" and record.confidence is None:
                raise ValueError("Predicted structures require a confidence estimate")
        return value


class Hypothesis(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
    id: str
    drug: str
    target: str
    mechanism: str
    evidence: list[dict] = Field(default_factory=list)
    status: str = "draft"  # draft | pharmacist_reviewed | rejected
    tier: str = "predicted"  # structure-based hypotheses are never verified or curated
    proposed_by: str = ""
    reviewer: str = ""
    reviewed_at: date | None = None

    @field_validator("tier")
    @classmethod
    def _always_predicted(cls, value):
        if value != "predicted":
            raise ValueError("Structure-based hypotheses are always the predicted tier")
        return value

    @model_validator(mode="after")
    def _review_required(self):
        if self.status == "pharmacist_reviewed" and not (self.reviewer and self.reviewed_at):
            raise ValueError("A reviewed hypothesis requires a reviewer and review date")
        return self


class MolecularCatalog:
    def __init__(self):
        self._evidence: dict[str, EvidenceEntry] = {}
        self._hypotheses: dict[str, Hypothesis] = {}

    def add_evidence(self, raw: dict) -> dict:
        entry = EvidenceEntry(**raw)
        key = f"{entry.target}|{entry.drug}|{entry.relationship}"
        self._evidence[key] = entry
        return entry.model_dump(mode="json")

    def evidence(self) -> list[dict]:
        return [entry.model_dump(mode="json") for entry in self._evidence.values()]

    def propose(self, raw: dict) -> dict:
        hypothesis = Hypothesis(**raw)
        if hypothesis.status != "draft":
            raise ValueError("New proposals start as drafts awaiting pharmacist review")
        self._hypotheses[hypothesis.id] = hypothesis
        return hypothesis.model_dump(mode="json")

    def review(self, hypothesis_id: str, reviewer: str, accept: bool, review_date: date | None = None) -> dict:
        hypothesis = self._hypotheses.get(hypothesis_id)
        if hypothesis is None:
            raise KeyError("Hypothesis not found")
        if hypothesis.proposed_by and hypothesis.proposed_by == reviewer:
            raise PermissionError("A hypothesis must be reviewed by someone other than its proposer")
        if not accept:
            hypothesis.status = "rejected"
        else:
            hypothesis.status = "pharmacist_reviewed"
            hypothesis.reviewer = reviewer
            hypothesis.reviewed_at = review_date or date.today()
        return hypothesis.model_dump(mode="json")

    def public_hypotheses(self) -> list[dict]:
        """Reviewed hypotheses. Reviewer-facing only: the API never exposes these to patients."""
        return [h.model_dump(mode="json") for h in self._hypotheses.values()
                if h.status == "pharmacist_reviewed"]

    def queue(self) -> list[dict]:
        """Pharmacist review queue: drafts awaiting review first, then decided items."""
        order = {"draft": 0, "pharmacist_reviewed": 1, "rejected": 2}
        return [h.model_dump(mode="json")
                for h in sorted(self._hypotheses.values(), key=lambda h: order[h.status])]
