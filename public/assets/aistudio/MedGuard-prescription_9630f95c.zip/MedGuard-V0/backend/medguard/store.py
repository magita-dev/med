import asyncio
import os
from pathlib import Path

from cryptography.fernet import Fernet
from pymongo import AsyncMongoClient, ReturnDocument
from pymongo.errors import DuplicateKeyError


class Memory:
    def __init__(self):
        self.rows = {}

    async def add(self, bucket, row):
        key = (bucket, row["_id"])
        if key in self.rows:
            return False
        self.rows[key] = row
        return True

    async def find(self, bucket, **query):
        return [
            row for (collection, _), row in self.rows.items()
            if collection == bucket and all(row.get(k) == v for k, v in query.items())
        ]

    async def replace(self, bucket, row):
        self.rows[(bucket, row["_id"])] = row

    async def scan_stock(self, after=""):
        for row in sorted(await self.find("stock"), key=lambda item: item["_id"]):
            if row["_id"] > after:
                yield row

    async def candidate_stock(self, after, version, token):
        async for row in self.scan_stock(after):
            if row.get("index_version") != version or token in row.get("candidate_keys", []):
                yield row

    async def claim_job(self, key, token, now, until):
        row = self.rows["surveillance_jobs", key]
        if row.get("completed") or row.get("lease_until", "") > now:
            return None
        updated = {**row, "token": token, "lease_until": until}
        self.rows["surveillance_jobs", key] = updated
        return updated

    async def pending_stock(self, version):
        return [row for row in await self.find("stock")
                if not row.get("checked") or row.get("index_version") != version]

    async def mark_stock_checked(self, key, **fields):
        self.rows["stock", key].update(checked=True, **fields)

    async def advance_job(self, key, token, **fields):
        row = self.rows["surveillance_jobs", key]
        if row["token"] != token:
            return False
        self.rows["surveillance_jobs", key] = {**row, **fields}
        return True


class Mongo:
    CANDIDATE_INDEX = "index_version_1_candidate_keys_1__id_1"

    def __init__(self, uri):
        self.client = AsyncMongoClient(uri, serverSelectionTimeoutMS=5000)
        self.db = self.client[os.getenv("MEDGUARD_DATABASE", "medguard")]

    async def start(self):
        await self.client.admin.command("ping")
        for bucket in ("stock", "reviews", "impacts", "resolutions"):
            await self.db[bucket].create_index("tenant")
        await self.db.notices.create_index("key")
        await self.db.stock.create_index([("index_version", 1), ("candidate_keys", 1), ("_id", 1)])
        await self.db.stock.create_index([("index_version", 1), ("_id", 1)])

    async def add(self, bucket, row):
        try:
            await self.db[bucket].insert_one(row)
        except DuplicateKeyError:
            return False
        return True

    async def find(self, bucket, **query):
        return [row async for row in self.db[bucket].find(query)]

    async def replace(self, bucket, row):
        await self.db[bucket].replace_one({"_id": row["_id"]}, row, upsert=True)

    async def scan_stock(self, after=""):
        async with self.db.stock.find({"_id": {"$gt": after}}).sort("_id").batch_size(200) as cursor:
            async for row in cursor:
                yield row

    async def candidate_stock(self, after, version, token):
        indexed_query = {"_id": {"$gt": after}, "index_version": version, "candidate_keys": token}
        legacy_query = {"_id": {"$gt": after}, "index_version": {"$ne": version}}
        # Keep checkpoint order while allowing the selective branch to use its compound index.
        # Migration is handled separately; skip the fallback cursor once all stock is indexed.
        async with self.db.stock.find(indexed_query).hint(self.CANDIDATE_INDEX).sort("_id").batch_size(200) as indexed:
            if not await self.db.stock.find_one(legacy_query, projection={"_id": 1}):
                async for row in indexed:
                    yield row
                return
            async with self.db.stock.find(legacy_query).sort("_id").batch_size(200) as legacy:
                left, right = await anext(indexed, None), await anext(legacy, None)
                while left is not None or right is not None:
                    if right is None or (left is not None and left["_id"] < right["_id"]):
                        yield left
                        left = await anext(indexed, None)
                    else:
                        if left is not None and left["_id"] == right["_id"]:
                            left = await anext(indexed, None)
                        yield right
                        right = await anext(legacy, None)

    async def claim_job(self, key, token, now, until):
        return await self.db.surveillance_jobs.find_one_and_update(
            {"_id": key, "completed": False, "lease_until": {"$lte": now}},
            {"$set": {"token": token, "lease_until": until}}, return_document=ReturnDocument.AFTER,
        )

    async def pending_stock(self, version):
        query = {"$or": [{"checked": {"$ne": True}}, {"index_version": {"$ne": version}}]}
        return await self.db.stock.find(query).limit(200).to_list(200)

    async def mark_stock_checked(self, key, **fields):
        await self.db.stock.update_one({"_id": key}, {"$set": {"checked": True, **fields}})

    async def advance_job(self, key, token, **fields):
        result = await self.db.surveillance_jobs.update_one({"_id": key, "token": token}, {"$set": fields})
        return bool(result.matched_count)


class Evidence:
    def __init__(self, cipher: Fernet, directory=None):
        self.cipher = cipher
        self.directory = Path(directory or ".evidence")
        self.bucket = os.getenv("MEDGUARD_S3_BUCKET")

    def _put(self, digest, data):
        encoded = self.cipher.encrypt(data)
        if self.bucket:
            import boto3

            boto3.client("s3").put_object(Bucket=self.bucket, Key=f"notices/{digest}",
                                          Body=encoded, ContentType="application/octet-stream")
        else:
            from tempfile import NamedTemporaryFile

            self.directory.mkdir(parents=True, exist_ok=True)
            with NamedTemporaryFile(dir=self.directory, delete=False) as temporary:
                temporary.write(encoded)
                path = Path(temporary.name)
            try:
                path.replace(self.directory / digest)
            finally:
                path.unlink(missing_ok=True)

    async def put(self, digest, data):
        await asyncio.to_thread(self._put, digest, data)

    def _get(self, digest):
        if self.bucket:
            import boto3

            with boto3.client("s3").get_object(Bucket=self.bucket, Key=f"notices/{digest}")["Body"] as body:
                encoded = body.read()
        else:
            encoded = (self.directory / digest).read_bytes()
        return self.cipher.decrypt(encoded)

    async def get(self, digest):
        return await asyncio.to_thread(self._get, digest)
