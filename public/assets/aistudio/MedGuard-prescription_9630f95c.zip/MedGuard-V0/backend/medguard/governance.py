"""Clinical rule governance: licensing, evidence citations, applicability
constraints, qualified sign-off and scheduled re-review.

The decision engine (``core.screen``) is unchanged. This module governs *admission*
of curated rules and reports which rules meet governance and which have expired or
are missing required provenance. It never performs clinical inference."""
from datetime import date

from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator

from .core import composition, ingredient, screen as _screen


class Applicability(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
    form: str | None = None
    route: str | None = None
    min_age: int | None = Field(default=None, ge=0, le=125)
    max_age: int | None = Field(default=None, ge=0, le=125)


class Mechanism(BaseModel):
    """Optional 'Why?' link from a curated rule to protein targets. Explanation only."""
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
    targets: list[str] = Field(min_length=1)
    explanation: dict[str, str] = Field(min_length=1)
    source: str
    locator: str


class ClinicalRule(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
    kind: str
    ingredients: list[str] = Field(min_length=1)
    severity: str | None = None
    tier: str = "curated"
    mechanism: Mechanism | None = None
    message: dict[str, str] | None = None
    form: str | None = None
    min_age: int | None = Field(default=None, ge=0, le=125)
    source: str
    locator: str
    jurisdiction: str
    license: str = Field(min_length=1)
    evidence: list[dict] = Field(min_length=1)
    applicability: Applicability = Field(default_factory=Applicability)
    reviewed_by: str = Field(min_length=1)
    reviewed_at: date
    re_review_at: date
    version: int = Field(default=1, ge=1)
    id: str | None = None

    @field_validator("tier")
    @classmethod
    def _no_predicted_rules(cls, value):
        if value not in {"verified", "curated"}:
            raise ValueError("A rule that raises an alert must be verified or curated, never predicted")
        return value

    @field_validator("re_review_at")
    @classmethod
    def _schedule_after_review(cls, value, info):
        reviewed = info.data.get("reviewed_at")
        if reviewed and value < reviewed:
            raise ValueError("re-review date must not precede the review date")
        return value


# Fields a rule must carry to be considered governed.
GOVERNANCE_FIELDS = ("license", "evidence", "reviewed_by", "reviewed_at", "re_review_at")


def assess_rule(raw: dict) -> dict:
    """Return a governance report for a raw rule without raising."""
    try:
        rule = ClinicalRule(**raw)
        return {"governed": True, "missing": [], "expired": rule.re_review_at < date.today(),
                "validated": rule.model_dump(mode="json")}
    except ValidationError as error:
        missing = sorted({str(err["loc"][0]) for err in error.errors() if err["loc"]})
        return {"governed": False, "missing": missing, "expired": None, "validated": None}


class ClinicalRegistry:
    """Holds curated rules, governs admission by reporting, and screens regimens."""

    def __init__(self, rules: list[dict]):
        self.rules = list(rules)
        self.reports = [assess_rule(rule) for rule in self.rules]

    @property
    def governed(self) -> list[dict]:
        return [rule for rule, report in zip(self.rules, self.reports) if report["governed"]]

    @property
    def not_governed(self) -> list[dict]:
        return [rule for rule, report in zip(self.rules, self.reports) if not report["governed"]]

    def screen(self, regimen: list[dict], age: int | None) -> list[dict]:
        """Delegate to the deterministic decision engine. Behaviour is unchanged."""
        return _screen(regimen, age, self.rules)

    def coverage(self, ingredients: set[str]) -> dict:
        canonical = {ingredient(value) for value in ingredients}
        known_pairs = {
            tuple(sorted(composition([rule["ingredients"][0]] + rule["ingredients"][1:])))
            for rule in self.rules if rule.get("kind") == "interaction"
        }
        pair_count = len(canonical) * (len(canonical) - 1) // 2
        covered = sum(set(pair).issubset(canonical) for pair in known_pairs)
        return {
            "jurisdiction": "US",
            "scope": "Selected label rules",
            "unassessed_interactions_possible": True,
            "unassessed_pair_count": max(0, pair_count - covered),
            "governed_rule_count": len(self.governed),
            "total_rule_count": len(self.rules),
        }

    def report(self, today: str | None = None) -> list[dict]:
        today = today or date.today().isoformat()
        out = []
        for rule, report in zip(self.rules, self.reports):
            out.append({
                "kind": rule.get("kind"),
                "ingredients": rule.get("ingredients", []),
                "jurisdiction": rule.get("jurisdiction"),
                "governed": report["governed"],
                "missing": report["missing"],
                "expired": report["expired"],
                "reviewed_by": rule.get("reviewed_by"),
                "re_review_at": str(rule.get("re_review_at", "")),
                "source": rule.get("source"),
            })
        return out
