import hashlib
import json
from uuid import uuid4

import pytest
from fastapi.testclient import TestClient

from medguard.api import PASSWORDS, create_app
from medguard.store import Memory

PACK = {"product": "Demo 10 mg", "manufacturer": "Example Labs", "batch": "001-A",
        "confirmed": True}
NOTICE = {"key": "demo", "version": 1, "kind": "nsq", **{k: v for k, v in PACK.items() if k != "confirmed"},
          "source": "https://www.cdsco.gov.in/example.pdf", "locator": "Synthetic test, page 1",
          "published": "2025-01-01", "effective": "2025-01-01", "source_page": 1}


def synthetic_pdf():
    stream = b"BT /F1 12 Tf 72 720 Td (Demo 10 mg Example Labs Synthetic) Tj ET"
    objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R "
        b"/Resources << /Font << /F1 5 0 R >> >> >>",
        f"<< /Length {len(stream)} >>\nstream\n".encode() + stream + b"\nendstream",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
    ]
    content = b"%PDF-1.4\n"
    offsets = [0]
    for index, body in enumerate(objects, 1):
        offsets.append(len(content))
        content += f"{index} 0 obj\n".encode() + body + b"\nendobj\n"
    xref = len(content)
    content += b"xref\n0 6\n0000000000 65535 f \n"
    content += b"".join(f"{offset:010} 00000 n \n".encode() for offset in offsets[1:])
    return content + f"trailer\n<< /Root 1 0 R /Size 6 >>\nstartxref\n{xref}\n%%EOF\n".encode()


PDF = synthetic_pdf()


@pytest.fixture
def environment(tmp_path, monkeypatch):
    monkeypatch.delenv("MEDGUARD_DEMO", raising=False)
    monkeypatch.delenv("MEDGUARD_S3_BUCKET", raising=False)
    hashed = PASSWORDS.hash("test-password")
    accounts = {
        "publisher": {"hash": hashed, "tenant": "one", "role": "publisher"},
        "second": {"hash": hashed, "tenant": "one", "role": "publisher"},
        "member": {"hash": hashed, "tenant": "one", "role": "member"},
        "outsider": {"hash": hashed, "tenant": "two", "role": "member"},
    }
    store = Memory()
    digest = hashlib.sha256(PDF).hexdigest()
    store.rows["source_versions", NOTICE["source"] + "|" + digest] = {
        "_id": NOTICE["source"] + "|" + digest, "pdf": True,
    }
    row = {key: NOTICE[key] for key in ("source_page", "locator", "product", "manufacturer", "batch")}
    capture_id = NOTICE["source"] + "|" + digest
    store.rows["ingestion", capture_id] = {"_id": capture_id, "rows": [row]}
    with TestClient(create_app(store, accounts, tmp_path)) as client:
        yield client, store, tmp_path


def auth(user="member"):
    return user, "test-password"


def publish(client, metadata=NOTICE, user="publisher", verified="true", approve=True):
    response = client.post("/api/notices", auth=auth(user),
                       data={"metadata": json.dumps(metadata), "verified": verified},
                       files={"file": ("test.pdf", PDF, "application/pdf")})
    if approve and response.is_success:
        return client.put(f'/api/notice-drafts/{response.json()["_id"]}/approve', auth=auth("second"))
    return response


def test_provenance_and_independent_approval(environment):
    client, _, _ = environment
    draft = publish(client, approve=False).json()
    assert draft["evidence_status"] == "source_observed"
    assert client.get("/api/notices", auth=auth()).json() == []
    assert client.get("/api/notice-drafts", auth=auth()).status_code == 403
    url = "/api/notice-drafts/demo:1/approve"
    assert client.put(url, auth=auth("publisher")).status_code == 403
    unknown = {**NOTICE, "key": "unobserved", "source": "https://www.cdsco.gov.in/other.pdf"}
    assert publish(client, unknown, approve=False).json()["evidence_status"] == "publisher_attested"
    assert client.put("/api/notice-drafts/unobserved:1/approve", auth=auth("second")).status_code == 409
    assert client.put(url, auth=auth("second")).json()["evidence_status"] == "independently_verified"


def test_manual_scope_requires_span_attestation_and_checks_page(environment):
    client, store, _ = environment
    digest = hashlib.sha256(PDF).hexdigest()
    del store.rows["ingestion", NOTICE["source"] + "|" + digest]
    body = {"reviewer_attests_span": True}
    for key, changes in [
        ("missing-span", {}),
        ("invalid-page", {"source_page": 4, "evidence_span": [0, 0, 1, 1], "submitter_attests_span": True}),
        ("wrong-batch", {"evidence_span": [0, 0, 1, 1], "submitter_attests_span": True}),
    ]:
        assert publish(client, {**NOTICE, "key": key, **changes}, approve=False).is_success
        assert client.put(f"/api/notice-drafts/{key}:1/approve", auth=auth("second"), json=body).status_code == 409
    manual = {**NOTICE, "key": "manual", "batch": "Synthetic", "evidence_span": [0, 0, 1, 1],
              "submitter_attests_span": True}
    assert publish(client, manual, approve=False).is_success
    url = "/api/notice-drafts/manual:1/approve"
    assert client.put(url, auth=auth("second")).status_code == 409
    assert client.put(url, auth=auth("second"), json=body).json()["evidence_status"] == "human_reviewed_unverified_extraction"
    result = client.post("/api/check", auth=auth(), json={**PACK, "batch": "Synthetic"}).json()
    assert result["matches"][0]["status"] == "uncertain"


def test_captured_document_draft_creates_impact_only_after_approval(environment):
    client, store, directory = environment
    assert publish(client, approve=False).is_success  # Writes encrypted bytes for this fixture.
    digest = hashlib.sha256(PDF).hexdigest()
    identifier = NOTICE["source"] + "|" + digest
    row = {key: NOTICE[key] for key in ("locator", "product", "manufacturer", "batch")}
    store.rows["ingestion", identifier] = {"_id": identifier, "sha256": digest, "rows": [
        {**row, "source_page": 1},
    ]}
    draft = {**NOTICE, "key": "captured", "source_page": 1}
    url = f"/api/ingestion/{digest}"
    assert client.get(url + "/document", auth=auth("publisher")).content == PDF
    assert client.post(url + "/draft", auth=auth("publisher"), json=draft).status_code == 200
    assert client.post(url + "/draft", auth=auth("publisher"), json={
        **draft, "key": "wrong-batch", "batch": "001-B",
    }).status_code == 200
    assert client.put("/api/notice-drafts/wrong-batch:1/approve", auth=auth("second")).status_code == 409
    assert client.put("/api/stock/" + str(uuid4()), auth=auth(), json=PACK).status_code == 200
    assert client.get("/api/reviews", auth=auth()).json() == []
    assert client.put("/api/notice-drafts/captured:1/approve", auth=auth("second")).status_code == 200
    impact, = client.get("/api/reviews", auth=auth()).json()
    assert impact["notice"]["_id"] == "captured:1"
    assert impact["notice"]["row_validation"] == "extracted_row_verified"
    assert client.get("/api/notifications", auth=auth()).json()[0]["id"] == impact["id"]
    assert client.get("/api/notifications", auth=auth("outsider")).json() == []
    assert client.put(f'/api/reviews/{impact["id"]}/ack', auth=auth()).is_success
    assert client.get("/api/notifications", auth=auth()).json() == []
    assert client.put("/api/notice-drafts/captured:1/approve", auth=auth("second")).status_code == 200
    assert len(client.get("/api/reviews", auth=auth()).json()) == 1


def test_reverse_surveillance_revision_and_isolation(environment):
    client, store, _ = environment
    item = "/api/stock/" + str(uuid4())
    assert client.put(item, auth=auth(), json=PACK).status_code == 200
    assert client.put(item, auth=auth(), json=PACK).status_code == 200
    assert client.put(item, auth=auth(), json={**PACK, "batch": "other"}).status_code == 409
    assert client.get("/api/reviews", auth=auth()).json() == []
    assert client.get("/api/stock", auth=auth("outsider")).json() == []
    wrong_batch = {**PACK, "batch": "002-A"}
    assert client.put("/api/stock/" + str(uuid4()), auth=auth(), json=wrong_batch).status_code == 200
    assert "001-A" not in str([row for (collection, _), row in store.rows.items() if collection == "stock"])
    assert publish(client).status_code == 200
    assert publish(client).status_code == 200
    assert publish(client, {**NOTICE, "batch": "other"}).status_code == 409
    row, = client.get("/api/reviews", auth=auth()).json()
    assert row["status"] == "exact"
    assert client.post("/api/check", auth=auth(), json=wrong_batch).json()["matches"][0]["status"] == "different_batch"
    assert len([key for key in store.rows if key[0] == "impacts"]) == 1
    ack = f'/api/reviews/{row["id"]}/ack'
    assert client.put(ack, auth=auth("outsider")).status_code == 404
    first = client.put(ack, auth=auth()).json()
    assert first == client.put(ack, auth=auth()).json()
    assert client.get("/api/audit", auth=auth("outsider")).json() == []
    assert publish(client, {**NOTICE, "version": 2}).status_code == 200
    updated, = client.get("/api/reviews", auth=auth()).json()
    assert updated["id"] != row["id"] and updated["acknowledgement"] is None
    assert client.get("/api/audit", auth=auth()).json() == [first]
    response = {"outcome": "quarantined", "note": "Moved to hold shelf"}
    resolution = f'/api/reviews/{row["id"]}/resolution'
    assert client.put(resolution, auth=auth("outsider"), json=response).status_code == 404
    assert client.put(f'/api/reviews/{updated["id"]}/resolution', auth=auth(), json=response).status_code == 409
    first_response = client.put(resolution, auth=auth(), json=response)
    assert first_response.status_code == 404  # Superseded notices cannot acquire a new response.


def test_facility_response_retry_and_encryption(environment):
    client, store, _ = environment
    assert publish(client).status_code == 200
    item = {**PACK, "quantity": 42, "location": "Shelf A"}
    assert client.put("/api/stock/" + str(uuid4()), auth=auth(), json=item).status_code == 200
    assert client.get("/api/stock", auth=auth()).json()[0]["quantity"] == 42
    assert "Shelf A" not in str(store.rows)
    row, = client.get("/api/reviews", auth=auth()).json()
    url = f'/api/reviews/{row["id"]}'
    assert client.put(url + "/ack", auth=auth()).status_code == 200
    body = {"outcome": "quarantined", "note": "Moved to hold shelf"}
    first = client.put(url + "/resolution", auth=auth(), json=body)
    assert first.status_code == 200
    assert client.put(url + "/resolution", auth=auth(), json=body).json() == first.json()
    assert client.put(url + "/resolution", auth=auth(), json={**body, "outcome": "returned"}).status_code == 409
    assert "Moved to hold shelf" not in str(store.rows)


def test_authorization_evidence_and_confirmation(environment):
    client, _, directory = environment
    assert client.get("/api/stock").status_code == 401
    assert client.get("/api/stock", auth=("member", "wrong")).status_code == 401
    assert client.post("/api/check", json={**PACK, "confirmed": False}, auth=auth()).status_code == 422
    assert publish(client, user="member").status_code == 403
    assert publish(client, {**NOTICE, "source": "https://cdsco.gov.in.evil.example/a"}).status_code == 422
    assert publish(client, verified="false").status_code == 422
    preview = client.post("/api/evidence/extract", auth=auth("publisher"),
                          files={"file": ("test.pdf", PDF, "application/pdf")}).json()
    assert preview["confirmed"] is False
    assert "Synthetic" in preview["pages"][0]["text"]
    revision = publish(client).json()
    digest = hashlib.sha256(PDF).hexdigest()
    assert revision["sha256"] == preview["sha256"] == digest
    assert (directory / digest).read_bytes() != PDF
    response = client.get("/api/evidence/" + digest, auth=auth())
    assert response.content == PDF
    assert response.headers["cache-control"] == "no-store"
    (directory / digest).write_bytes(b"tampered")
    assert client.get("/api/evidence/" + digest, auth=auth()).status_code == 500


def test_regimen_verified_label_and_no_coverage_claim(environment):
    client, _, _ = environment
    packs = [{**PACK, "ingredients": [ingredient]} for ingredient in ["clarithromycin", "simvastatin"]]
    report = client.post("/api/regimen", auth=auth(), json={"packs": packs}).json()
    finding, = report["findings"]
    assert finding["severity"] == "contraindication" and "dailymed" in finding["source"]
    assert report["limited_coverage"] is True
