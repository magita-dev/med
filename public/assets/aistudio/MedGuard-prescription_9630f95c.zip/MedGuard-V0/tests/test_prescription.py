import json
from pathlib import Path

from medguard.prescription import check_dose, check_indication, parse_line, review

FIX = Path(__file__).resolve().parents[1] / "fixtures"
CLINICAL = json.loads((FIX / "clinical.json").read_text(encoding="utf-8"))
DOSE = [{"ingredient": "demoxin", "min_age": 18, "max_daily_mg": 1000, "synthetic": True,
         "source": "s", "locator": "l", "jurisdiction": "none"}]
IND = [{"ingredient": "demoxin", "indications": ["demo infection"], "synthetic": True,
        "source": "s", "locator": "l", "jurisdiction": "none"}]


def test_parse_pattern_and_duration():
    item = parse_line("Tab Demoxin 500 mg 1-0-1 x 5 days")
    assert item["drug"] == "demoxin" and item["form"] == "tablet"
    assert item["strength_value"] == 500 and item["units_per_day"] == 2 and item["duration_days"] == 5


def test_parse_abbreviation_and_modifier():
    item = parse_line("Cap Demoxin 250mg TDS pc for 1 week")
    assert item["units_per_day"] == 3 and item["modifiers"] == ["pc"] and item["duration_days"] == 7


def test_unparseable_lines_are_dropped():
    assert parse_line("Dr. A Kumar, MBBS") is None


def test_dose_over_cited_max_and_within():
    over = check_dose(parse_line("Tab Demoxin 500 mg 1-1-1"), DOSE, 30)
    assert over["outcome"] == "exceeds_cited_maximum" and over["daily_mg"] == 1500
    ok = check_dose(parse_line("Tab Demoxin 500 mg 1-0-1"), DOSE, 30)
    assert ok["outcome"] == "at_or_below_cited_maximum"


def test_dose_not_assessed_without_rule_age_or_quantity():
    assert check_dose(parse_line("Tab Paracetamol 500 mg 1-0-1"), DOSE, 30)["reason"] == "no_reviewed_rule"
    assert check_dose(parse_line("Tab Demoxin 500 mg 1-0-1"), DOSE, None)["reason"] == "no_rule_for_this_age"
    assert check_dose(parse_line("Tab Demoxin 500 mg SOS"), DOSE, 30)["reason"] == "dose_unknown_or_as_needed"


def test_indication_listed_not_listed_unassessed():
    item = parse_line("Tab Demoxin 500 mg BD")
    assert check_indication(item, "Demo infection", IND)["outcome"] == "listed_in_cited_label"
    assert check_indication(item, "migraine", IND)["outcome"] == "not_listed_in_cited_label"
    assert check_indication(item, "", IND)["reason"] == "no_condition_entered"


def test_review_never_says_safe_and_translates():
    items = [parse_line("Tab Demoxin 500 mg 1-0-1 x 5 days")]
    out = review(items, "demo infection", 30, DOSE, IND, CLINICAL)
    assert out["outcome"] == "nothing_found" and out["checks_not_run"] == 0
    assert "does not mean the prescription is safe" in out["summary"]["en"]
    assert "பாதுகாப்பானது என்று பொருள்படாது" in out["summary"]["ta"]
    assert out["items"][0]["instruction"]["ta"].startswith("demoxin 500 mg: காலை 1, இரவு 1")


def test_review_flags_interaction_with_mechanism():
    items = [parse_line("Tab Clarithromycin 250 mg BD"), parse_line("Tab Simvastatin 20 mg HS")]
    out = review(items, None, 70, DOSE, IND, CLINICAL)
    assert out["outcome"] == "issues_found"
    finding = next(f for f in out["findings"] if f["kind"] == "interaction")
    assert finding["mechanism"]["targets"] == ["CYP3A4"] and "ta" in finding["mechanism"]["explanation"]


def test_generic_names_in_localized_messages():
    for rule in CLINICAL:
        for lang in ("hi", "ta"):
            text = rule["message"][lang]
            for generic in rule["ingredients"]:
                if rule["kind"] == "interaction":
                    assert generic in text
