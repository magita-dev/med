import asyncio

import httpx

from medguard.ocr import propose_fields
from medguard.sources import NoticeLinks, nsq_rows, observe
from medguard.store import Memory
from medguard.store import Evidence
from cryptography.fernet import Fernet


def test_batch_labels_preserve_visually_confusable_characters():
    for text in ("B. No.: O01-0A", "बैच संख्या: O01-0A", "தொகுதி எண்: O01-0A"):
        fields = propose_fields([{"text": text, "confidence": 0.95}])
        assert fields["batch"]["value"] == "O01-0A"
        assert fields["batch"]["requires_manual_entry"] is True


def test_ocr_proposals_abstain_on_conflicting_batches():
    lines = [{"text": value, "confidence": score} for value, score in [
        ("Product: Example", .97), ("Mfg. by: Example Labs", .90), ("Batch No. A001", .94),
        ("Batch: A002", .95), ("Strength: 5 mg", .84), ("Composition: ingredient A, ingredient B", .89),
        ("Dosage form: tablet", .90), ("Lot: A003", .55),
    ]]
    result = propose_fields(lines)
    assert result["product"]["value"] == "Example"
    assert result["batch"]["value"] is None
    assert [candidate["line"] for candidate in result["batch"]["candidates"]] == [2, 3]
    assert result["manufacturer"]["value"] == "Example Labs"
    assert result["strength"]["value"] == "5 mg"
    assert result["ingredients"]["value"] == "ingredient A, ingredient B"
    assert result["form"]["value"] == "tablet"


async def exercise_source_monitor():
    source = "https://www.cdsco.gov.in/fixture.pdf"
    revisions = iter([b"%PDF-revision-a", b"%PDF-revision-a", b"%PDF-revision-b", None])
    timestamp = iter(["1", "2", "3", "4"]).__next__

    async def serve(request):
        assert str(request.url) == source
        payload = next(revisions)
        return httpx.Response(200, content=payload) if payload else httpx.Response(302, headers={"Location": "https://example.org"})

    store = Memory()
    async with httpx.AsyncClient(transport=httpx.MockTransport(serve)) as client:
        for _ in range(4):
            await observe(store, [source], timestamp, client)
    versions = await store.find("source_versions")
    assert [version["first_seen"] for version in versions] == ["1", "3"]
    status, = await store.find("source_status")
    assert status["checked_at"] == "4" and "error" in status
    assert status["last_success_at"] == "3"
    assert status["error"] == "Official source returned HTTP 302"
    assert not await store.find("notices")


def test_reordered_nsq_columns():
    page = {"page": 1, "tables": [[["Lot No.", "NSQ Reason", "Manufacturer", "Serial", "Drug Name"],
                                  ["O01", "Assay", "Example Labs", "1", "Example"]]]}
    row, = nsq_rows([page])
    assert (row["batch"], row["product"], row["manufacturer"]) == ("O01", "Example", "Example Labs")


def test_headerless_continuation_requires_consecutive_page_and_serial():
    headings = ["Lot No.", "NSQ Reason", "Manufacturer", "Serial", "Drug Name"]
    first = {"page": 1, "tables": [[headings, ["O01", "Assay", "Example Labs", "1.", "Example"]]]}
    continuation = {"page": 2, "tables": [[["", "", "Address continuation", "", ""],
                                            ["002", "Assay", "Maker", "2.", "Another"]]]}
    unrelated = {"page": 3, "tables": [[["003", "Assay", "Maker", "8.", "Unrelated"]]]}
    assert [row["batch"] for row in nsq_rows([first, continuation, unrelated])] == ["O01", "002"]


def test_source_monitor_keeps_versions_and_rejects_redirects():
    asyncio.run(exercise_source_monitor())


def test_archive_links_and_nsq_table_proposals_preserve_batch():
    parser = NoticeLinks("https://www.cdsco.gov.in/alerts")
    parser.feed('<a href="/UploadAlertsFiles/notice.pdf">notice</a>'
                '<a href="https://evil.example/UploadAlertsFiles/notice.pdf">other</a>')
    assert parser.links == ["https://www.cdsco.gov.in/UploadAlertsFiles/notice.pdf"]
    page = {"page": 2, "tables": [[["No.", "Product", "Batch No.", "Made", "Expiry",
                                   "Manufactured By", "NSQ Results", "Lab"],
                                  ["1.", "Example 10 mg", "001-A", "", "", "Example Labs", "Assay", "Lab"]]]}
    row, = nsq_rows([page])
    assert row["batch"] == "001-A" and row["locator"] == "Page 2, row 1."


def test_discovered_pdf_is_preserved_and_replayed_once(tmp_path):
    async def run():
        archive = "https://www.cdsco.gov.in/alerts"
        pdf = b"%PDF-unrecognized-layout"
        store = Memory()
        evidence = Evidence(Fernet(Fernet.generate_key()), tmp_path)
        evidence.bucket = None

        def respond(request):
            if str(request.url) == archive:
                return httpx.Response(200, text='<a href="/UploadAlertsFiles/test.pdf">notice</a>')
            return httpx.Response(200, content=pdf)

        async with httpx.AsyncClient(transport=httpx.MockTransport(respond)) as client:
            for _ in range(2):
                await observe(store, [archive], lambda: "2026-11-14", client, evidence)
        capture, = await store.find("ingestion")
        assert capture["status"] == "manual_review"
        assert await evidence.get(capture["sha256"]) == pdf
        assert not await store.find("notices")

    asyncio.run(run())
