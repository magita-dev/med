"""Generate clearly labelled synthetic packs and exercise actual local OCR models."""
import argparse
import json
from io import BytesIO
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from medguard.ocr import propose_fields, recognize

LABELS = {
    "en": "Batch No.: O01-0A",
    "hi": "बैच संख्या: O01-0A",
    "ta": "தொகுதி எண்: O01-0A",
}


def run(language, font_path):
    image = Image.new("RGB", (1000, 300), "white")
    font = ImageFont.truetype(str(font_path), 54)
    drawing = ImageDraw.Draw(image)
    drawing.text((35, 35), "Example Labs", font=font, fill="black")
    drawing.text((35, 130), LABELS[language], font=font, fill="black")
    with BytesIO() as buffer:
        image.save(buffer, format="PNG")
        lines = recognize(buffer.getvalue(), language)
    actual = propose_fields(lines).get("batch", {}).get("value")
    print(json.dumps({"language": language, "fixture": "synthetic", "batch_expected": "O01-0A",
                      "batch_proposed": actual, "lines": lines}, ensure_ascii=True))
    return actual != "O01-0A"


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("language", choices=LABELS)
    parser.add_argument("font", type=Path)
    args = parser.parse_args()
    raise SystemExit(run(args.language, args.font))
