"""Download original official PDFs for annotation, retaining hashes and failures."""
import argparse
import asyncio
import json
from hashlib import sha256
from pathlib import Path

import httpx

from medguard.sources import capture

SOURCES = {
    "central-june-2025.pdf": "https://www.cdsco.gov.in/opencms/resources/UploadCDSCOWeb/2018/UploadAlertsFiles/CDSCO%20NSQ%20june25.pdf",
    "state-june-2025.pdf": "https://www.cdsco.gov.in/opencms/resources/UploadCDSCOWeb/2018/UploadAlertsFiles/STATE%20NSQ%20%20June%20-2025.pdf",
}


async def download(directory):
    directory.mkdir(parents=True, exist_ok=True)
    records = []
    async with httpx.AsyncClient(timeout=30, trust_env=False) as client:
        for filename, url in SOURCES.items():
            record = {"source": url, "file": filename}
            try:
                data = await capture(client, url)
                if not data.startswith(b"%PDF-"):
                    raise ValueError("Expected PDF bytes")
                (directory / filename).write_bytes(data)
                record["sha256"] = sha256(data).hexdigest()
            except (httpx.HTTPError, ValueError) as error:
                record["error"] = type(error).__name__
            records.append(record)
    (directory / "capture-log.json").write_text(json.dumps(records, indent=2), encoding="utf-8")
    for record in records:
        print(record["file"], record.get("sha256", record.get("error")))
    return any("error" in record for record in records)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    raise SystemExit(asyncio.run(download(parser.parse_args().directory)))
