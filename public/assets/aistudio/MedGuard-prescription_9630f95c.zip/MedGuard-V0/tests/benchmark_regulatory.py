"""Evaluate held-out reviewer annotations against local copies of official PDFs."""
import argparse
import json
from collections import Counter
from hashlib import sha256
from pathlib import Path

from medguard.documents import extract
from medguard.sources import nsq_rows, official_url


FIELDS = ("product", "manufacturer", "batch", "finding")


def locator(row):
    return row["source_page"], row["locator"]


def identity(row):
    return (*locator(row), *(row[field] for field in FIELDS))


def evaluate(manifest, *, baseline=False):
    documents = json.loads(manifest.read_text(encoding="utf-8"))
    if not documents:
        raise ValueError("Provide at least one annotated document")
    totals = Counter()
    field_correct = Counter()
    for document in documents:
        if not official_url(document["source"]):
            raise ValueError("Benchmark requires an official document URL")
        annotated = document["rows"]
        expected = Counter(map(identity, annotated))
        by_locator = {locator(row): row for row in annotated}
        if len(by_locator) != len(annotated):
            raise ValueError("Annotation locators must be unique within each document")
        totals["expected"] += sum(expected.values())
        try:
            data = (manifest.parent / document["file"]).read_bytes()
            if sha256(data).hexdigest() != document["sha256"]:
                raise ValueError("Digest mismatch")
            pages = extract(data, "pdfplumber", 80, text_tables=not baseline)
            proposals = [row for page in pages for row in nsq_rows([page])] if baseline else nsq_rows(pages)
            found = Counter(map(identity, proposals))
        except Exception as error:
            totals["unavailable"] += 1
            print(document["source"], "unavailable:", type(error).__name__)
            continue
        true = sum((expected & found).values())
        proposal_locations = Counter(map(locator, proposals))
        for proposal in proposals:
            key = locator(proposal)
            if key not in by_locator or proposal_locations[key] != 1:
                continue
            for field in FIELDS:
                if proposal[field] == by_locator[key][field]:
                    field_correct[field] += 1
                else:
                    print(document["file"], key, "field mismatch:", field)
        for key in sorted(by_locator.keys() - proposal_locations.keys()):
            print(document["file"], key, "missing row")
        totals.update({"processed": 1, "proposed": sum(found.values()), "correct": true})
        print(document["source"], f"correct={true} proposed={sum(found.values())} expected={sum(expected.values())}")
    print(dict(totals))
    precision = totals["correct"] / totals["proposed"] if totals["proposed"] else None
    recall = totals["correct"] / totals["expected"] if totals["expected"] else None
    print(f"precision={precision} recall={recall}")
    print("Field exact counts against all annotated rows:", dict(field_correct), "denominator:", totals["expected"])
    return totals


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("--baseline", action="store_true", help="Require a new table header on each page")
    args = parser.parse_args()
    raise SystemExit(bool(evaluate(args.manifest, baseline=args.baseline)["unavailable"]))
