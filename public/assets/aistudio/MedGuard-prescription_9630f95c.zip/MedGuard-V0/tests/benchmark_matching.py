"""Deterministic engineering benchmark with labeled synthetic inputs."""
from collections import Counter
from random import Random
from statistics import median
from time import perf_counter

from medguard.core import assess, name


def cases():
    rng = Random(17)
    for index in range(10_000):
        lot = f"{rng.randrange(100_000):05d}-A"
        notice = {"kind": "nsq", "product": f"Fictional product {index % 50}",
                  "manufacturer": "Fictional Labs", "batch": lot}
        scenario = index % 5
        changes = ({}, {"batch": lot.replace("-", "")}, {"manufacturer": ""},
                   {"manufacturer": "Other Labs"}, {"product": "Unrelated"})[scenario]
        yield notice | changes, notice, ("exact", "different_batch", "uncertain", "none", "none")[scenario]


def product_only(pack, notice):
    return "exact" if name(pack["product"]) == name(notice["product"]) else "none"


def criterion_matching(pack, notice):
    result = assess(pack, notice)
    return result["status"] if result else "none"


def main():
    dataset = list(cases())
    for baseline in (product_only, criterion_matching):
        outcomes = Counter()
        timings = []
        for pack, notice, expected in dataset:
            start = perf_counter()
            result = baseline(pack, notice)
            timings.append((perf_counter() - start) * 1e6)
            outcomes[expected, result] += 1
        print(baseline.__name__, "expected/predicted", dict(sorted(outcomes.items())))
        print(f"Median {median(timings):.2f} us per comparison")
    print("Synthetic comparison only. Excludes persistence, OCR, and reviewed field samples.")


if __name__ == "__main__":
    main()
