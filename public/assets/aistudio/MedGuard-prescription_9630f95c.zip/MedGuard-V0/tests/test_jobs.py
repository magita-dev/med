import asyncio

from medguard.store import Memory


def test_expired_lease_replays_from_checkpoint_and_fences_old_worker():
    async def exercise():
        store = Memory()
        await store.add("surveillance_jobs", {"_id": "revision", "after": "", "lease_until": "", "completed": False})
        first, competitor = await asyncio.gather(
            store.claim_job("revision", "first", "01", "05"),
            store.claim_job("revision", "competitor", "01", "05"),
        )
        assert first and competitor is None
        assert await store.advance_job("revision", "first", after="stock-a")
        resumed = await store.claim_job("revision", "retry", "06", "10")
        assert resumed["after"] == "stock-a"
        assert not await store.advance_job("revision", "first", completed=True)
        assert await store.advance_job("revision", "retry", completed=True)
        assert await store.claim_job("revision", "later", "11", "15") is None

    asyncio.run(exercise())
