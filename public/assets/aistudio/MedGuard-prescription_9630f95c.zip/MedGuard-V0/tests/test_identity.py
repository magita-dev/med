import pytest

from medguard.identity import IdentityCatalog
from medguard.core import assess


def test_approved_alias_and_advisory_typo_have_different_effects():
    approved = {"product": "Example 10 mg", "manufacturer": "Example Laboratories"}
    variant = {"product": "Example 10mg", "manufacturer": "Example Labs"}
    catalog = IdentityCatalog([{"canonical": approved, "aliases": [variant],
                                "source": "synthetic catalog fixture", "reviewer": "fixture"}])
    notice = {**approved, "kind": "nsq", "batch": "001-A"}
    pack = {**variant, "batch": "001-A"}
    assert assess(catalog.resolve(pack), notice)["status"] == "exact"
    assert assess(catalog.resolve({**pack, "batch": "O01-A"}), notice)["status"] == "different_batch"
    typo = {**pack, "product": "Exampl 10mg"}
    assert catalog.candidates(typo) == [approved]
    assert assess(catalog.resolve(typo), notice) is None
    assert assess(catalog.resolve({**pack, "manufacturer": "Other Labs"}), notice) is None
    ambiguous = {"canonical": {**approved, "product": "Other 10 mg"}, "aliases": [variant],
                 "source": "synthetic catalog fixture", "reviewer": "fixture"}
    with pytest.raises(ValueError):
        IdentityCatalog([{"canonical": approved, "aliases": [variant],
                          "source": "fixture", "reviewer": "fixture"}, ambiguous])
