"""Check a dedicated MongoDB integration URI without printing credentials."""
import asyncio
import os

from pymongo import AsyncMongoClient
from pymongo.errors import ConfigurationError, InvalidURI, OperationFailure, ServerSelectionTimeoutError


async def ping(uri):
    try:
        async with AsyncMongoClient(uri, serverSelectionTimeoutMS=5000) as client:
            await client.admin.command("ping")
    except (ConfigurationError, InvalidURI):
        print("MongoDB URI or DNS configuration is invalid.")
    except ServerSelectionTimeoutError:
        print("MongoDB server selection timed out. Check DNS, TLS, network access and server availability.")
    except OperationFailure as error:
        print(f"MongoDB rejected the connection or ping (code {error.code}). Check credentials and permissions.")
    else:
        print("MongoDB ping passed. Run the integration suite to check indexes and write permissions.")
        return 0
    return 1


def main():
    uri = os.getenv("MEDGUARD_TEST_MONGO_URI")
    if not uri:
        print("MEDGUARD_TEST_MONGO_URI is missing. Configure a dedicated test deployment.")
        return 2
    return asyncio.run(ping(uri))


if __name__ == "__main__":
    raise SystemExit(main())
