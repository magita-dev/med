"""Report real PDF proposal counts and numbering gaps without assigning ground truth."""
import argparse
import json
from hashlib import sha256
from pathlib import Path

from medguard.documents import extract
from medguard.sources import nsq_rows


def probe(document):
    data = document.read_bytes()
    pages = extract(data, "pdfplumber", 80, text_tables=True)
    proposals = nsq_rows(pages)
    serials = [int(row["locator"].split()[-1].rstrip(".")) for row in proposals]
    return {"file": document.name, "sha256": sha256(data).hexdigest(), "pages_examined": len(pages),
            "proposed_rows": len(proposals), "duplicate_serials": len(serials) - len(set(serials)),
            "serial_gaps": sorted(set(range(1, max(serials, default=0) + 1)) - set(serials))}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pdf", nargs="+", type=Path)
    print(json.dumps([probe(path) for path in parser.parse_args().pdf], indent=2))
