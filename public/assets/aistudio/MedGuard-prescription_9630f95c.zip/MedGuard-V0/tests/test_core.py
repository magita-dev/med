import unittest

from medguard.core import assess, latest, screen


class DecisionTests(unittest.TestCase):
    def setUp(self):
        self.notice = {"kind": "nsq", "product": "Demo 10 mg", "batch": "001-A",
                       "manufacturer": "Example Labs"}
        self.pack = {**self.notice, "ingredients": ["ingredient a"], "form": "tablet"}

    def test_batch_identity_preserves_distinguishing_tokens(self):
        self.assertEqual(assess(self.pack, self.notice)["status"], "exact")
        for value in ("01-A", "001A", "O01-A", "001-a"):
            with self.subTest(value=value):
                self.assertEqual(assess({**self.pack, "batch": value}, self.notice)["status"], "different_batch")

    def test_uncertain_and_conflict(self):
        self.assertEqual(assess({**self.pack, "manufacturer": ""}, self.notice)["status"], "uncertain")
        self.assertIsNone(assess({**self.pack, "manufacturer": "", "batch": "other"}, self.notice))

    def test_fdc_matches_one_formulation(self):
        notice = {"kind": "prohibition", "ingredients": ["a", "b"], "form": "tablet",
                  "strength": "10 mg + 20 mg"}
        pack = {"ingredients": ["A", "B"], "form": "Tablet", "strength": "10 mg + 20 mg"}
        self.assertEqual(assess(pack, notice)["status"], "exact")
        self.assertEqual(assess({**pack, "ingredients": ["B", "A"]}, notice)["status"], "uncertain")
        self.assertEqual(assess({**pack, "strength": ""}, notice)["status"], "uncertain")
        self.assertIsNone(assess({**pack, "ingredients": ["a", "b", "c"]}, notice))
        self.assertIsNone(assess({**pack, "ingredients": ["a"]}, notice))
        self.assertIsNone(assess({**pack, "strength": "20 mg + 10 mg"}, notice))

    def test_versions_with_future_withdrawal(self):
        previous = {"key": "a", "version": 1, "effective": "2025-01-01", "active": True}
        withdrawal = {**previous, "version": 2, "active": False, "effective": "2025-02-01"}
        self.assertEqual(latest([withdrawal, previous], "2025-01-31"), [previous])
        self.assertEqual(latest([withdrawal, previous], "2025-02-01"), [])

    def test_duplicate_and_geriatric_context(self):
        rule = {"kind": "geriatric", "ingredients": ["a"], "min_age": 65, "form": "tablet"}
        pack = {"ingredients": ["A", "a"], "form": "tablet"}
        self.assertEqual(screen([pack], None, [rule]), [])
        self.assertEqual(screen([pack], 64, [rule]), [])
        self.assertEqual(screen([pack], 65, [rule]), [{**rule, "tier": "curated"}])
        self.assertEqual(screen([{**pack, "form": "liquid"}], 80, [rule]), [])
        self.assertEqual(screen([pack, pack], 65, [rule])[0]["kind"], "duplicate")


def test_predicted_tier_rule_can_never_create_a_finding():
    from medguard.core import screen
    rule = {"kind": "interaction", "ingredients": ["a", "b"], "tier": "predicted", "severity": "x"}
    pack = lambda i: {"ingredients": [i], "form": "tablet"}
    assert screen([pack("a"), pack("b")], None, [rule]) == []


def test_findings_are_stamped_with_a_tier():
    from medguard.core import screen
    rule = {"kind": "interaction", "ingredients": ["a", "b"], "severity": "x"}
    pack = lambda i: {"ingredients": [i], "form": "tablet"}
    assert screen([pack("a"), pack("b")], None, [rule])[0]["tier"] == "curated"


def test_assess_returns_per_criterion_trace():
    from medguard.core import assess
    pack = {"product": "Demo 10 mg", "manufacturer": "Example Labs", "batch": "001-B"}
    notice = {"kind": "nsq", "product": "demo 10 MG", "manufacturer": "Example Labs", "batch": "001-A"}
    result = assess(pack, notice)
    assert result["status"] == "different_batch"
    by_field = {row["field"]: row for row in result["criteria"]}
    assert by_field["batch"] == {"field": "batch", "entered": "001-B", "notice": "001-A", "outcome": "conflict"}
    assert by_field["manufacturer"]["outcome"] == "equal"
