import asyncio

from medguard.candidates import CandidateKeys
from medguard.core import assess
from medguard.store import Memory


def test_index_preserves_possible_and_exact_impacts_and_migrates_legacy():
    async def run():
        keys = CandidateKeys(b"synthetic secret", "catalog v1")
        target = {"kind": "nsq", "product": "Drug A", "manufacturer": "Maker", "batch": "O01"}
        store = Memory()
        packs = [
            {**target, "ingredients": []},
            {**target, "ingredients": [], "manufacturer": ""},
            {**target, "ingredients": [], "batch": "001"},
            {**target, "ingredients": [], "product": "Drug B"},
            {**target, "ingredients": []},
        ]
        for i, pack in enumerate(packs):
            row = {"_id": str(i)}
            if i != 4:
                row.update(index_version=keys.version, candidate_keys=keys.stock(pack))
            await store.add("stock", row)
        eligible = [row["_id"] async for row in store.candidate_stock("", keys.version, keys.notice(target))]
        assert eligible == ["0", "1", "2", "4"]
        def affected(pack):
            result = assess(pack, target)
            return result and result["status"] in {"exact", "uncertain"}
        assert [i for i in eligible if affected(packs[int(i)])] == [
            str(i) for i, pack in enumerate(packs) if affected(pack)
        ]
        assert [row["_id"] async for row in store.candidate_stock("1", keys.version, keys.notice(target))] == ["2", "4"]
        assert [item["_id"] for item in await store.pending_stock(keys.version)] == ["0", "1", "2", "3", "4"]
        await store.mark_stock_checked("4", index_version=keys.version, candidate_keys=keys.stock(packs[4]))
        assert [item["_id"] for item in await store.pending_stock(keys.version)] == ["0", "1", "2", "3"]

    asyncio.run(run())
