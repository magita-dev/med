"""Opt-in test against a real MongoDB server, using an isolated database."""
import asyncio
import os
from uuid import uuid4

import pytest

from medguard.store import Mongo


@pytest.mark.skipif(not os.getenv("MEDGUARD_TEST_MONGO_URI"), reason="No dedicated Mongo test URI")
def test_persistent_tenant_queries_and_idempotency(monkeypatch):
    database = "medguard_test_" + uuid4().hex
    monkeypatch.setenv("MEDGUARD_DATABASE", database)
    uri = os.environ["MEDGUARD_TEST_MONGO_URI"]

    async def exercise():
        original = Mongo(uri)
        restarted = Mongo(uri)
        try:
            await original.start()
            row = {"_id": "scoped-key", "tenant": "a", "ciphertext": "opaque fixture"}
            inserted = await asyncio.gather(*(original.add("stock", row) for _ in range(5)))
            assert inserted.count(True) == 1
            await restarted.start()
            assert await restarted.find("stock", tenant="a") == [row]
            assert await restarted.find("stock", tenant="b") == []
            assert [item async for item in restarted.scan_stock()] == [row]
            await original.add("stock", {"_id": "indexed-a", "tenant": "a",
                                         "index_version": "v1", "candidate_keys": ["match"]})
            await original.add("stock", {"_id": "indexed-b", "tenant": "b",
                                         "index_version": "v1", "candidate_keys": ["other"]})
            assert [item["_id"] async for item in restarted.candidate_stock("", "v1", "match")] == [
                "indexed-a", "scoped-key",
            ]
            assert [item["_id"] async for item in restarted.candidate_stock("indexed-a", "v1", "match")] == [
                "scoped-key",
            ]
            await restarted.mark_stock_checked("scoped-key", index_version="v1", candidate_keys=["other"])
            assert [item["_id"] async for item in restarted.candidate_stock("", "v1", "match")] == ["indexed-a"]
            plan = await restarted.db.stock.find({
                "index_version": "v1", "candidate_keys": "match", "_id": {"$gt": ""},
            }).hint(Mongo.CANDIDATE_INDEX).sort("_id").explain()
            assert Mongo.CANDIDATE_INDEX in str(plan["queryPlanner"]["winningPlan"])
            await original.add("surveillance_jobs", {"_id": "revision", "after": "",
                                                      "lease_until": "", "completed": False})
            claims = await asyncio.gather(
                original.claim_job("revision", "one", "01", "05"),
                restarted.claim_job("revision", "two", "01", "05"),
            )
            winner, = [job for job in claims if job]
            assert await original.advance_job("revision", winner["token"], after="scoped-key")
            resumed = await restarted.claim_job("revision", "replacement", "06", "10")
            assert resumed["after"] == "scoped-key"
            assert not await original.advance_job("revision", winner["token"], completed=True)
            assert await restarted.advance_job("revision", "replacement", completed=True)
        finally:
            await restarted.client.close()
            try:
                await original.client.drop_database(database)
            finally:
                await original.client.close()

    asyncio.run(exercise())
