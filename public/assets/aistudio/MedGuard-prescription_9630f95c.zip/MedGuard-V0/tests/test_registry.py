from medguard.identity import IdentityCatalog
from medguard.ocrlib import ModelRegistry, compare_baselines
from medguard.registry import ReviewedIdentityRegistry
from medguard.verification import verify_action_scope


def test_verify_action_scope_supports_and_rejects_unsupported_claims():
    supported = {"kind": "nsq", "action_type": "quality_defect", "scope": "Batch 001",
                 "authority": "CDSCO", "finding": "Assay failure"}
    assert verify_action_scope(supported)["supported"] is True
    unsupported = {"kind": "nsq", "action_type": "spurious_product"}  # wrong action, no scope, no authority
    result = verify_action_scope(unsupported)
    assert result["supported"] is False
    assert any("action_type" in issue for issue in result["issues"])
    assert any("scope" in issue for issue in result["issues"])
    assert any("authority" in issue for issue in result["issues"])
    spurious_ok = {"kind": "spurious", "action_type": "spurious_product", "scope": "Market",
                   "authority": "CDSCO", "finding": "spurious product"}
    assert verify_action_scope(spurious_ok)["supported"] is True
    spurious_no_finding = {"kind": "spurious", "action_type": "spurious_product",
                           "scope": "Market", "authority": "CDSCO"}
    assert verify_action_scope(spurious_no_finding)["supported"] is False


def test_reviewed_identity_registry_validates_and_feeds_catalog():
    records = [
        {"canonical": {"product": "Example 10 mg", "manufacturer": "Example Laboratories"},
         "aliases": [{"product": "Example 10mg", "manufacturer": "Example Labs"}],
         "composition": ["example 10 mg"], "source": "synthetic fixture", "reviewer": "fixture",
         "version": 1},
        {"canonical": {"product": "Other 10 mg", "manufacturer": "Other Labs"}, "aliases": [],
         "source": "synthetic fixture", "reviewer": "fixture"},
    ]
    registry = ReviewedIdentityRegistry(records)
    assert registry.valid
    assert len(registry.entries) == 2
    catalog = IdentityCatalog(registry.to_catalog_records())
    assert catalog.resolve({"product": "Example 10mg", "manufacturer": "Example Labs"})["product"] == "Example 10 mg"


def test_reviewed_identity_registry_rejects_self_alias_and_duplicate():
    records = [
        {"canonical": {"product": "Example 10 mg", "manufacturer": "Example Laboratories"},
         "aliases": [{"product": "Example 10 mg", "manufacturer": "Example Laboratories"}],
         "source": "x", "reviewer": "y"},
    ]
    assert not ReviewedIdentityRegistry(records).valid
    dup = [
        {"canonical": {"product": "Same", "manufacturer": "M"}, "source": "x", "reviewer": "y"},
        {"canonical": {"product": "Same", "manufacturer": "M"}, "source": "x", "reviewer": "y"},
    ]
    assert not ReviewedIdentityRegistry(dup).valid


def test_model_registry_records_weights_with_hash():
    registry = ModelRegistry()
    record = registry.add({"name": "ppocr-en", "kind": "recognizer", "language": "en",
                            "version": "v5", "sha256": "0" * 64, "source": "https://paddlepaddle",
                            "license": "Apache-2.0", "inference_config": {"device": "cpu"}})
    assert record["sha256"] == "0" * 64
    assert registry.entries()[0]["name"] == "ppocr-en"
    # same name, different weight is rejected
    import pytest
    with pytest.raises(ValueError):
        registry.add({"name": "ppocr-en", "kind": "recognizer", "version": "v5",
                      "sha256": "1" * 64, "source": "https://x"})
    # bad hash rejected
    with pytest.raises(Exception):
        registry.add({"name": "bad", "kind": "detector", "version": "v5",
                       "sha256": "nothex", "source": "https://x"})


def test_compare_baselines_ranks_by_macro_f1():
    results = [
        {"model_name": "a", "image_count": 50, "metrics": [
            {"field": "product", "precision": 0.9, "recall": 0.8},
            {"field": "batch", "precision": 0.7, "recall": 0.6, "ambiguous_char_errors": 5}]},
        {"model_name": "b", "image_count": 50, "metrics": [
            {"field": "product", "precision": 0.95, "recall": 0.9},
            {"field": "batch", "precision": 0.8, "recall": 0.75, "abstentions": 3}]},
    ]
    ranking = compare_baselines(results)["ranking"]
    assert ranking[0]["model_name"] == "b" and ranking[0]["macro_f1"] > ranking[1]["macro_f1"]
    assert ranking[1]["ambiguous_char_errors"] == 5
