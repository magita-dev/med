"""Measure synthetic candidate reduction, preserving decisions against a full scan."""
from time import perf_counter

from medguard.candidates import CandidateKeys
from medguard.core import assess


def run(size):
    keys = CandidateKeys(b"synthetic benchmark secret", "fixture")
    notice = {"product": "Drug 1", "manufacturer": "Maker", "batch": "001", "kind": "nsq"}
    stock = [{"product": f"Drug {i % 500}", "manufacturer": "Maker" if i % 3 else "",
              "batch": "001" if i % 2 else "O01", "ingredients": []} for i in range(size)]
    index = {}
    for i, pack in enumerate(stock):
        for candidate in keys.stock(pack):
            index.setdefault(candidate, []).append(i)

    def affected(indices):
        return [i for i in indices if (result := assess(stock[i], notice)) and result["status"] != "different_batch"]

    start = perf_counter()
    full = affected(range(size))
    scan_time = perf_counter() - start
    start = perf_counter()
    candidates = index.get(keys.notice(notice), [])
    indexed = affected(candidates)
    lookup_time = perf_counter() - start
    assert full == indexed
    print(f"stock={size} candidates={len(candidates)} impacts={len(indexed)} "
          f"full_ms={scan_time * 1000:.3f} indexed_ms={lookup_time * 1000:.3f}")


if __name__ == "__main__":
    for size in (1000, 10_000, 100_000):
        run(size)
