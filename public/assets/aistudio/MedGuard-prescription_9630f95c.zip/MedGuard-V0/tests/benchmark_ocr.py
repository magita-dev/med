"""Score local PaddleOCR proposals on a held-out image manifest."""
import argparse
import json
from collections import Counter
from pathlib import Path

from medguard.ocr import propose_fields, recognize


def benchmark(manifest):
    corpus = json.loads(manifest.read_text(encoding="utf-8"))
    if not corpus:
        raise ValueError("An independently annotated image set is required")
    results = {}
    failures = 0
    for item in corpus:
        strata = item["language"], item["condition"]
        try:
            proposals = propose_fields(recognize((manifest.parent / item["file"]).read_bytes(), strata[0]))
        except Exception as error:
            print(item["file"], type(error).__name__)
            failures += 1
            proposals = {}
        for field, expected in item["fields"].items():
            tally = results.setdefault((*strata, field), Counter())
            proposal = proposals.get(field, {})
            actual = proposal.get("value")
            tally["total"] += 1
            tally["exact" if actual == expected else "missing" if actual is None else "wrong"] += 1
            if actual is None or proposal.get("requires_manual_entry"):
                tally["abstained"] += 1
                tally["wrong_blocked"] += int(actual is not None and actual != expected)
            elif actual != expected:
                tally["wrong_autofill"] += 1
    for key, result in sorted(results.items()):
        print(*key, dict(result), f'exact={result["exact"] / result["total"]:.1%}')
    print("Inference failures:", failures)
    return failures


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path)
    raise SystemExit(bool(benchmark(parser.parse_args().manifest)))
